#!/usr/bin/env python3
"""CineStory AI v10 Cinematic Procedural Motion Engine.

Transforms approved still images into genuinely alive vertical 9:16 video clips
using frame-accurate OpenCV + NumPy compositing piped directly to FFmpeg H.264:

1. Quality-verified multi-plane parallax (background, midground/subject, optional
   foreground prop plane) with independent depth speeds and background DoF shift.
   If layer quality fails, preserves the complete original image (never uses a
   damaged inpainted plate!).
2. Scene-specific environmental animation driven by scene description & image analysis:
   - `lamp_glow`: localized warm radial glow pulsing softly + nearby surface bounce
     (NEVER flashes the whole screen).
   - `candle_flicker`: multi-frequency organic flame flicker & warm halo micro-sway.
   - `dust_particles`: true 3D-depth-layered drifting dust/bokeh motes moving across frames.
   - `atmospheric_rays`: gentle volumetric light shafts with soft phase drift.
   - `steam`: curling, rising translucent steam wisps above hot tea/kettle/drinks.
   - `clock_motion`: subtle ticking specular highlight pulse around clocks/watches.
   - `gentle_sway`: localized soft horizontal sway on edge foliage/curtains (safe-masked).
3. Safe character micro-movement (ultra-subtle breathing expansion/sway on validated
   foreground cutouts without distorting faces or hands).
4. Truthful `motion_manifest.json` recording exact effects used, layer quality scores,
   mean frame-to-frame pixel delta (motion proof), and any fallback reasons.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import shutil
import subprocess
import sys
from pathlib import Path

INTENSITY = {"subtle": 0.030, "cinematic": 0.052, "expressive": 0.075}


def run(cmd: list[str]) -> None:
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, check=True)


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def infer_move(scene: dict, index: int) -> str:
    camera = scene.get("camera") or {}
    direct = camera.get("move") or scene.get("camera_move") or scene.get("move")
    allowed = {"push_in", "pull_out", "pan_left", "pan_right", "tilt_up", "tilt_down", "drift", "hold"}
    if isinstance(direct, str) and direct.lower() in allowed:
        return direct.lower()
    prompt = " ".join(str(scene.get(k, "")) for k in ("motion_prompt", "shot", "action")).lower()
    if any(x in prompt for x in ("lateral", "sideways", "across", "pan")):
        return "pan_left" if index % 2 == 0 else "pan_right"
    if any(x in prompt for x in ("pull back", "pull-out", "widen", "reveal")):
        return "pull_out"
    if any(x in prompt for x in ("tilt up", "tilt toward", "rise to", "up to")):
        return "tilt_up"
    if any(x in prompt for x in ("tilt down", "floor level", "down to")):
        return "tilt_down"
    if any(x in prompt for x in ("drift", "alongside", "tracking")):
        return "drift"
    return ["push_in", "pan_right", "pull_out", "drift", "push_in", "pan_left", "tilt_up", "push_in"][index % 8]


def light_point(scene: dict):
    value = scene.get("light_source") or (scene.get("camera") or {}).get("light_source")
    if isinstance(value, dict) and "x" in value and "y" in value:
        return clamp(float(value["x"])), clamp(float(value["y"])), clamp(float(value.get("intensity", 0.72)), 0.0, 1.5)
    if isinstance(value, (list, tuple)) and len(value) >= 2:
        return clamp(float(value[0])), clamp(float(value[1])), 0.72
    return None


def detect_warm_light(image_path: Path):
    """Find a compact bright warm practical light (lantern, lamp, candle) in the scene."""
    try:
        import cv2
        import numpy as np
        bgr = cv2.imread(str(image_path))
        if bgr is None:
            return None
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        mask = ((hsv[:, :, 0] <= 34) & (hsv[:, :, 1] >= 85) & (hsv[:, :, 2] >= 185)).astype("uint8")
        if mask.sum() < max(10, int(mask.size * 0.00002)):
            return None
        values = hsv[:, :, 2][mask > 0]
        cutoff = max(215, int(np.percentile(values, 85)))
        ys, xs = np.where((mask > 0) & (hsv[:, :, 2] >= cutoff))
        if len(xs) < 5:
            return None
        weights = hsv[ys, xs, 2].astype("float64") * (hsv[ys, xs, 1].astype("float64") / 255.0)
        x = float(np.average(xs, weights=weights)) / max(1, bgr.shape[1] - 1)
        y = float(np.average(ys, weights=weights)) / max(1, bgr.shape[0] - 1)
        return (round(x, 4), round(y, 4), 0.72)
    except Exception:
        return None


def infer_scene_effects(scene: dict, has_detected_light: bool) -> dict:
    """Select scene-specific environmental animations strictly from scene description & cues."""
    explicit = scene.get("effects")
    if isinstance(explicit, list) and explicit:
        explicit_set = {str(e).strip().lower() for e in explicit}
    elif isinstance(explicit, dict):
        explicit_set = {k.lower() for k, v in explicit.items() if v}
    else:
        explicit_set = set()

    text = " ".join(
        str(scene.get(k, "")) for k in ("motion_prompt", "image_prompt", "action", "shot", "narration", "sfx")
    ).lower()

    candle = ("candle_flicker" in explicit_set) or any(w in text for w in ("candle", "मोमबत्ती", "flame", "diya", "दिया"))
    lamp = ("lamp_glow" in explicit_set) or (
        not candle and (
            any(w in text for w in ("lantern", "lamp", "लालटेन", "streetlamp", "streetlight", "bulb", "warm light", "night school"))
            or has_detected_light
        )
    )
    steam = ("steam" in explicit_set) or any(w in text for w in ("tea", "chai", "kettle", "चाय", "steam", "भाप", "hot drink", "stall"))
    clock = ("clock_motion" in explicit_set) or any(w in text for w in ("clock", "watch", "gear", "घड़ी", "टिक"))
    sway = ("gentle_sway" in explicit_set) or any(w in text for w in ("curtain", "leaves", "tree", "foliage", "breeze", "wind", "पत्ते", "परदा", "हवा"))
    rays = ("atmospheric_rays" in explicit_set) or any(w in text for w in ("sunlight", "morning", "lantern", "lamp", "rays", "night", "रात", "रोशनी"))
    dust = ("dust_particles" in explicit_set) or any(w in text for w in ("night", "room", "lantern", "lamp", "workshop", "school", "street", "रात", "कमरा", "फुटपाथ", "पाठशाला")) or rays

    return {
        "lamp_glow": bool(lamp),
        "candle_flicker": bool(candle),
        "dust_particles": bool(dust),
        "atmospheric_rays": bool(rays),
        "steam": bool(steam),
        "clock_motion": bool(clock),
        "gentle_sway": bool(sway),
    }


def ensure_parallax_runtime(model: str = "u2net"):
    try:
        import cv2  # noqa: F401
        from rembg import new_session
        return new_session(model)
    except Exception as first_error:
        if os.getenv("CINESTORY_AUTO_INSTALL_MOTION", "1").lower() not in {"1", "true", "yes", "on"}:
            raise RuntimeError(f"Parallax runtime/model is not ready and automatic setup is disabled: {first_error}") from first_error
        setup = Path(__file__).resolve().with_name("setup_motion.py")
        if not setup.exists():
            raise RuntimeError("setup_motion.py is missing; cannot prepare the 2.5D runtime.") from first_error
        result = subprocess.run([sys.executable, str(setup), "--install"], check=False)
        if result.returncode != 0:
            raise RuntimeError("Automatic installation of CPU segmentation dependencies failed.") from result.returncode
        from rembg import new_session
        return new_session(model)


def _crop_zoom_frame(img, out_w: int, out_h: int, zoom: float, fx: float, fy: float, dx: float = 0.0, dy: float = 0.0):
    import cv2
    ih, iw = img.shape[:2]
    crop_w = max(8.0, iw / max(1.0, zoom))
    crop_h = max(8.0, ih / max(1.0, zoom))
    x0 = (iw - crop_w) * clamp(fx) + dx
    y0 = (ih - crop_h) * clamp(fy) + dy
    x0 = max(0.0, min(iw - crop_w, x0))
    y0 = max(0.0, min(ih - crop_h, y0))
    M = cv2.getAffineTransform(
        _tri(x0, y0, crop_w, crop_h),
        _tri(0.0, 0.0, float(out_w), float(out_h)),
    )
    return cv2.warpAffine(img, M, (out_w, out_h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT101)


def _tri(x: float, y: float, w: float, h: float):
    import numpy as np
    return np.float32([[x, y], [x + w, y], [x, y + h]])


def _camera_params(move: str, strength: float, progress: float, focus: tuple[float, float], t: float) -> tuple[float, float, float, float, float]:
    ease = 0.5 - 0.5 * math.cos(math.pi * clamp(progress))
    fx0, fy0 = focus
    if move == "push_in":
        z = 1.0 + strength * ease
        fx, fy = fx0, fy0
    elif move == "pull_out":
        z = 1.0 + strength * (1.0 - ease)
        fx, fy = fx0, fy0
    elif move == "pan_left":
        z = 1.0 + strength * 0.85
        fx, fy = 0.78 - 0.56 * ease, fy0
    elif move == "pan_right":
        z = 1.0 + strength * 0.85
        fx, fy = 0.22 + 0.56 * ease, fy0
    elif move == "tilt_up":
        z = 1.0 + strength * 0.80
        fx, fy = fx0, 0.78 - 0.56 * ease
    elif move == "tilt_down":
        z = 1.0 + strength * 0.80
        fx, fy = fx0, 0.22 + 0.56 * ease
    elif move == "drift":
        z = 1.0 + strength * 0.90 * ease
        fx, fy = 0.34 + 0.32 * ease, 0.56 - 0.12 * ease
    else:
        z = 1.0 + strength * 0.28 * ease
        fx, fy = fx0, fy0
    # Gentle organic handheld cinema micro-drift
    dx = 2.4 * math.sin(2.0 * math.pi * t / 4.7)
    dy = 1.8 * math.cos(2.0 * math.pi * t / 5.3)
    return z, fx, fy, dx, dy


def render_cinematic_clip(
    image: Path,
    output: Path,
    duration: float,
    width: int,
    height: int,
    fps: int,
    crf: int,
    move: str,
    strength: float,
    style: str,
    effects: dict,
    light_coords: tuple[float, float, float] | None,
    background: Path | None = None,
    foreground: Path | None = None,
    focus=None,
    seed: int = 42,
) -> dict:
    """Render a genuinely animated scene clip using OpenCV + NumPy piped to FFmpeg H.264."""
    import cv2
    import numpy as np

    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg not found on PATH.")

    frames = max(1, int(round(duration * fps)))
    use_parallax = bool(background and background.is_file() and foreground and foreground.is_file())
    focus_xy = (
        (clamp(float(focus[0])), clamp(float(focus[1])))
        if isinstance(focus, (list, tuple)) and len(focus) >= 2
        else (0.50, 0.48)
    )

    # Load and cover-fit base assets at slight overscan (1.10x) for clean sub-pixel camera moves.
    sw, sh = (int(width * 1.10) // 2) * 2, (int(height * 1.10) // 2) * 2

    def load_cover_bgr(p: Path):
        im = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if im is None:
            raise RuntimeError(f"Could not read image: {p}")
        ih, iw = im.shape[:2]
        scale = max(sw / iw, sh / ih)
        rw, rh = max(sw, int(round(iw * scale))), max(sh, int(round(ih * scale)))
        resized = cv2.resize(im, (rw, rh), interpolation=cv2.INTER_LANCZOS4)
        x0, y0 = (rw - sw) // 2, (rh - sh) // 2
        return resized[y0: y0 + sh, x0: x0 + sw]

    def load_cover_bgra(p: Path):
        im = cv2.imread(str(p), cv2.IMREAD_UNCHANGED)
        if im is None:
            raise RuntimeError(f"Could not read foreground layer: {p}")
        if im.shape[2] == 3:
            im = cv2.cvtColor(im, cv2.COLOR_BGR2BGRA)
        ih, iw = im.shape[:2]
        scale = max(sw / iw, sh / ih)
        rw, rh = max(sw, int(round(iw * scale))), max(sh, int(round(ih * scale)))
        resized = cv2.resize(im, (rw, rh), interpolation=cv2.INTER_LANCZOS4)
        x0, y0 = (rw - sw) // 2, (rh - sh) // 2
        return resized[y0: y0 + sh, x0: x0 + sw]

    if use_parallax:
        bg_img = load_cover_bgr(background)
        fg_img = load_cover_bgra(foreground)
        base_img = None
    else:
        base_img = load_cover_bgr(image)
        bg_img = None
        fg_img = None

    # Precompute spatial coordinate grids for fast localized lighting & atmospheric effects.
    yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
    xn = xx / float(width)
    yn = yy / float(height)

    # Precompute localized warm light radial falloff mask (lamp or candle).
    light_mask = None
    light_cx, light_cy, light_power = (0.5, 0.35, 0.7)
    if (effects["lamp_glow"] or effects["candle_flicker"]) and light_coords:
        light_cx, light_cy, light_power = light_coords
    elif effects["lamp_glow"] or effects["candle_flicker"]:
        light_cx, light_cy, light_power = (0.28, 0.36, 0.65)
    if effects["lamp_glow"] or effects["candle_flicker"]:
        r_core = 0.22 if effects["lamp_glow"] else 0.17
        r_bounce = 0.44 if effects["lamp_glow"] else 0.34
        dist2 = ((xn - light_cx) * (width / height)) ** 2 + (yn - light_cy) ** 2
        core = np.exp(-dist2 / (2.0 * (r_core ** 2)))
        bounce = np.exp(-dist2 / (2.0 * (r_bounce ** 2)))
        light_mask = (core * 0.70 + bounce * 0.30).astype(np.float32)

    # Precompute subtle volumetric diagonal light shafts.
    ray_field = None
    if effects["atmospheric_rays"]:
        angle_coord = (xn - light_cx) * 0.85 - (yn - light_cy) * 0.42
        ray_mask = np.clip(1.0 - np.hypot(xn - light_cx, yn - light_cy) * 0.95, 0.0, 1.0)
        ray_field = (angle_coord, ray_mask.astype(np.float32))

    # Precompute 3-depth-layer dust/bokeh particles (independent velocities & radii).
    rng = random.Random(seed)
    particles = []
    if effects["dust_particles"]:
        for _ in range(38):
            depth = rng.choice([0.45, 0.85, 1.35])  # far / mid / near
            particles.append({
                "x": rng.uniform(0.04, 0.96),
                "y": rng.uniform(0.05, 0.95),
                "vx": rng.uniform(-0.012, 0.016) * depth,
                "vy": rng.uniform(-0.022, -0.005) * depth,
                "r": max(2, int(round(rng.uniform(2.0, 5.5) * depth))),
                "phase": rng.uniform(0, 6.28),
                "alpha": rng.uniform(0.18, 0.48) * min(1.0, depth),
            })

    # Precompute rising steam wisps (positioned in lower-mid / warm region).
    steam_wisps = []
    if effects["steam"]:
        sx_base = clamp(light_cx + 0.08, 0.25, 0.75)
        sy_base = 0.68
        for idx_s in range(10):
            steam_wisps.append({
                "x0": sx_base + rng.uniform(-0.09, 0.09),
                "y0": sy_base + rng.uniform(-0.05, 0.05),
                "phase": idx_s * 0.62,
                "speed": rng.uniform(0.055, 0.095),
                "radius": int(width * rng.uniform(0.028, 0.055)),
            })

    # Precompute vignette mask once.
    vig = np.clip(1.0 - 0.24 * (((xn - 0.5) * 1.4) ** 2 + ((yn - 0.5) * 1.2) ** 2), 0.72, 1.0).astype(np.float32)

    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
        "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{width}x{height}", "-r", str(fps), "-i", "pipe:0",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p",
        "-movflags", "+faststart", str(output),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    assert proc.stdin is not None

    prev_sample_frame = None
    frame_diffs: list[float] = []
    character_micro = "subtle_breathing_and_sway" if use_parallax else "none_safe_environment_only"

    try:
        for f_idx in range(frames):
            t = f_idx / float(fps)
            prog = f_idx / float(max(1, frames - 1))

            if use_parallax:
                # Background plane moves slower + gentle depth-of-field blur variation
                z_bg, fx_bg, fy_bg, dx_bg, dy_bg = _camera_params(move, strength * 0.78, prog, focus_xy, t)
                bg_frame = _crop_zoom_frame(bg_img, width, height, z_bg, fx_bg, fy_bg, dx_bg * 0.7, dy_bg * 0.7)
                dof_sigma = 0.55 + 0.35 * math.sin(math.pi * prog)
                bg_frame = cv2.GaussianBlur(bg_frame, (0, 0), sigmaX=dof_sigma)

                # Subject midground plane moves slightly faster + subtle breathing micro-motion
                z_fg, fx_fg, fy_fg, dx_fg, dy_fg = _camera_params(move, min(0.11, strength * 1.28), prog, focus_xy, t)
                breath = 1.0 + 0.0045 * math.sin(2.0 * math.pi * t / 3.4)
                fg_sway_x = 5.5 * math.sin(2.0 * math.pi * t / 4.2)
                fg_sway_y = 3.2 * math.sin(2.0 * math.pi * t / 3.4)
                fg_frame = _crop_zoom_frame(fg_img, width, height, z_fg * breath, fx_fg, fy_fg, dx_fg + fg_sway_x, dy_fg + fg_sway_y)

                alpha_f = (fg_frame[:, :, 3:4].astype(np.float32)) / 255.0
                frame = (bg_frame.astype(np.float32) * (1.0 - alpha_f) + fg_frame[:, :, :3].astype(np.float32) * alpha_f)
            else:
                z, fx, fy, dx, dy = _camera_params(move, strength, prog, focus_xy, t)
                frame = _crop_zoom_frame(base_img, width, height, z, fx, fy, dx, dy).astype(np.float32)

            # Gentle edge sway for curtains/leaves (strictly masked to outer left/right edges away from faces)
            if effects["gentle_sway"]:
                sway_px = 4.5 * math.sin(2.0 * math.pi * t / 3.2)
                edge_weight = np.clip((np.abs(xn - 0.5) - 0.30) / 0.20, 0.0, 1.0)
                if abs(sway_px) > 0.2:
                    map_x = (xx + sway_px * edge_weight * np.sin(yn * 4.5 + t * 1.6)).astype(np.float32)
                    map_y = yy
                    frame = cv2.remap(frame, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT101)

            # Localized lamp/lantern glow or candle flame flicker (NEVER whole-screen flash!)
            if light_mask is not None:
                if effects["candle_flicker"]:
                    pulse = 0.55 + 0.25 * math.sin(2 * math.pi * t * 3.1) + 0.14 * math.sin(2 * math.pi * t * 7.3) + 0.06 * math.cos(2 * math.pi * t * 11.7)
                    gain = 26.0 * light_power * pulse
                else:
                    pulse = 0.62 + 0.38 * math.sin(2 * math.pi * t / 2.8)
                    gain = 22.0 * light_power * pulse
                # Warm golden-amber tint in BGR order: B, G, R
                frame[:, :, 0] += light_mask * (gain * 0.22)
                frame[:, :, 1] += light_mask * (gain * 0.68)
                frame[:, :, 2] += light_mask * (gain * 1.15)

            # Atmospheric volumetric light shafts
            if ray_field is not None:
                ang, rmask = ray_field
                ray_wave = 0.5 + 0.5 * np.sin(ang * 14.0 + t * 0.65)
                ray_intensity = (ray_wave ** 2) * rmask * (8.5 + 3.5 * math.sin(t * 0.9))
                frame[:, :, 0] += ray_intensity * 0.30
                frame[:, :, 1] += ray_intensity * 0.72
                frame[:, :, 2] += ray_intensity * 1.05

            # Clock / watch subtle ticking specular pulse
            if effects["clock_motion"]:
                tick_phase = (t * 1.0) % 1.0
                tick_pulse = math.exp(-tick_phase * 14.0)
                if tick_pulse > 0.05:
                    c_dist2 = ((xn - 0.50) * (width / height)) ** 2 + (yn - 0.62) ** 2
                    c_mask = np.exp(-c_dist2 / (2.0 * 0.12 ** 2)).astype(np.float32) * (14.0 * tick_pulse)
                    frame[:, :, 1] += c_mask * 0.85
                    frame[:, :, 2] += c_mask * 1.10

            # Rising translucent steam wisps
            if steam_wisps:
                steam_layer = np.zeros((height, width), dtype=np.float32)
                for wisp in steam_wisps:
                    cycle = (t * wisp["speed"] + wisp["phase"]) % 1.0
                    cy = int((wisp["y0"] - cycle * 0.24) * height)
                    cx = int((wisp["x0"] + 0.025 * math.sin(cycle * 6.28 + wisp["phase"])) * width)
                    rad = int(wisp["radius"] * (0.7 + 0.8 * cycle))
                    op = math.sin(math.pi * cycle) * 0.16
                    if 0 <= cy < height and 0 <= cx < width and op > 0.01:
                        cv2.circle(steam_layer, (cx, cy), rad, float(op * 255.0), -1)
                steam_layer = cv2.GaussianBlur(steam_layer, (0, 0), sigmaX=18.0)
                frame[:, :, 0] += steam_layer * 0.72
                frame[:, :, 1] += steam_layer * 0.78
                frame[:, :, 2] += steam_layer * 0.82

            # True 3D-depth drifting dust / warm bokeh particles
            if particles:
                p_layer = np.zeros((height, width, 3), dtype=np.float32)
                for pt in particles:
                    px = int(((pt["x"] + pt["vx"] * t) % 1.0) * width)
                    py = int(((pt["y"] + pt["vy"] * t) % 1.0) * height)
                    twinkle = 0.55 + 0.45 * math.sin(2.0 * math.pi * t * 0.9 + pt["phase"])
                    val = pt["alpha"] * twinkle * 155.0
                    cv2.circle(p_layer, (px, py), pt["r"], (val * 0.52, val * 0.84, val * 1.0), -1)
                p_layer = cv2.GaussianBlur(p_layer, (0, 0), sigmaX=2.2)
                frame += p_layer

            # Subtle cinematic vignette & warm grade
            frame *= vig[:, :, None]
            if style == "moody_cinematic_3d":
                frame[:, :, 0] *= 1.03
                frame[:, :, 2] *= 0.98
            elif style == "golden_fairytale_3d":
                frame[:, :, 2] *= 1.03
                frame[:, :, 1] *= 1.01

            out_u8 = np.clip(frame, 0, 255).astype(np.uint8)
            if f_idx % max(1, fps // 4) == 0:
                small = cv2.resize(out_u8, (135, 240))
                if prev_sample_frame is not None:
                    frame_diffs.append(float(np.mean(np.abs(small.astype(np.float32) - prev_sample_frame.astype(np.float32)))))
                prev_sample_frame = small

            proc.stdin.write(out_u8.tobytes())
    finally:
        proc.stdin.close()
        rc = proc.wait()
        if rc != 0:
            raise RuntimeError(f"FFmpeg clip encoding failed for {output} with exit code {rc}.")

    mean_diff = round(sum(frame_diffs) / max(1, len(frame_diffs)), 3) if frame_diffs else 0.0
    return {
        "mean_frame_diff": mean_diff,
        "character_micro_movement": character_micro,
        "parallax_layers_used": use_parallax,
    }


def require_parallax_results(parallax_results: dict, scenes: list[dict], mode: str) -> None:
    """Fail before clip/audio work when strict 2.5D parallax was requested."""
    if mode != "on":
        return
    missing = []
    for scene in scenes:
        scene_id = str(scene.get("id", "unknown"))
        result = parallax_results.get(scene_id, {})
        if not result.get("ok"):
            missing.append(f"{scene_id}: {result.get('reason', 'no valid foreground/background layers')}")
    if missing:
        details = "; ".join(missing)
        raise RuntimeError(
            "Strict 2.5D parallax could not be prepared for every scene. "
            "Final production is stopped before audio generation. "
            f"Repair/re-segment these scenes or explicitly choose --parallax auto: {details}"
        )


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("plan")
    ap.add_argument("--images", default="assets/images")
    ap.add_argument("--out", default="assets/video")
    ap.add_argument("--layers", default="assets/layers")
    ap.add_argument("--width", type=int, default=1080)
    ap.add_argument("--height", type=int, default=1920)
    ap.add_argument("--fps", type=int)
    ap.add_argument("--crf", type=int, default=19)
    ap.add_argument("--intensity", choices=INTENSITY, default="cinematic")
    ap.add_argument("--style", default="warm_cinematic_3d")
    ap.add_argument("--no-dust", action="store_true")
    ap.add_argument("--parallax", choices=["on", "auto", "off"], default="auto",
                    help="Quality-verified 2.5D parallax. 'auto' rejects damaged layers and uses safe full-image environmental animation.")
    ap.add_argument("--mode", choices=["code", "provider"], default="code")
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--command", default=None)
    a = ap.parse_args()

    if a.mode == "provider" and a.parallax == "on":
        ap.error("--mode provider cannot guarantee the internal 2.5D layer compositor; use --mode code for parallax, or explicitly set --parallax off/auto.")
    if a.width <= 0 or a.height <= 0:
        ap.error("width and height must be positive")
    if a.fps is not None and a.fps <= 0:
        ap.error("fps must be positive")

    plan_path = Path(a.plan).resolve()
    project_root = plan_path.parent
    data = json.loads(plan_path.read_text(encoding="utf-8"))
    fps = a.fps or int(data.get("fps", 24))
    images = Path(a.images)
    images = images if images.is_absolute() else project_root / images
    layers_dir = Path(a.layers)
    layers_dir = layers_dir if layers_dir.is_absolute() else project_root / layers_dir
    out = Path(a.out)
    out = out if out.is_absolute() else project_root / out
    out.mkdir(parents=True, exist_ok=True)

    parallax_results = {}
    if a.parallax != "off" and a.mode == "code":
        try:
            from prepare_parallax_layers import prepare_project
            try:
                parallax_results = prepare_project(plan_path, images, layers_dir, os.getenv("CINESTORY_REMBG_MODEL", "u2net"))
            except RuntimeError:
                model = os.getenv("CINESTORY_REMBG_MODEL", "u2net")
                session = ensure_parallax_runtime(model)
                parallax_results = prepare_project(plan_path, images, layers_dir, model, session=session)
            data = json.loads(plan_path.read_text(encoding="utf-8"))
            good = sum(1 for item in parallax_results.values() if item.get("ok"))
            print(f"PARALLAX: {good}/{len(parallax_results)} scene(s) passed quality-verified 2.5D layer gate.")
        except Exception as error:
            message = f"PARALLAX PREP UNAVAILABLE: {error}"
            if a.parallax == "on":
                print(message + " Strict mode refuses a camera-only downgrade.", file=sys.stderr)
                raise SystemExit(2)
            print(message + " Using full-image cinematic camera + environmental animation.", file=sys.stderr)
        if a.parallax == "on":
            try:
                require_parallax_results(parallax_results, data.get("scenes", []), a.parallax)
            except RuntimeError as error:
                print(f"PARALLAX BLOCKED: {error}", file=sys.stderr)
                raise SystemExit(2)

    strength = INTENSITY[a.intensity]
    manifest = []
    for index, scene in enumerate(data.get("scenes", [])):
        scene_id = str(scene["id"])
        image_value = scene.get("image_file") or f"{scene_id}.png"
        image = Path(image_value)
        image = image if image.is_absolute() else images / image.name
        if not image.exists():
            if scene.get("image") and Path(scene["image"]).exists():
                image = Path(scene["image"])
            else:
                sys.exit(f"Missing approved scene image: {image}")
        duration = float(scene["end"]) - float(scene["start"])
        if duration <= 0:
            sys.exit(f"Invalid duration for {scene_id}: {duration}")

        move = infer_move(scene, index)
        camera = scene.get("camera") or {}
        scene_strength = clamp(float(camera.get("strength", scene.get("motion_strength", strength))), 0.008, 0.10)
        clip = out / (scene.get("video_file") or f"{scene_id}.mp4")

        lp = light_point(scene)
        if lp is None:
            detected_light = detect_warm_light(image)
            if detected_light:
                lp = detected_light
                scene["light_source"] = {"x": lp[0], "y": lp[1], "intensity": lp[2], "detected": True}

        effects = infer_scene_effects(scene, has_detected_light=lp is not None)
        if a.no_dust:
            effects["dust_particles"] = False

        layers = scene.get("layers") or {}
        bg = Path(layers["background"]) if layers.get("background") else None
        fg = Path(layers["foreground"]) if layers.get("foreground") else None
        if bg and not bg.is_absolute():
            bg = project_root / bg
        if fg and not fg.is_absolute():
            fg = project_root / fg
        layer_info = parallax_results.get(scene_id, {})
        layer_ok = bool(bg and fg and bg.exists() and fg.exists() and a.parallax != "off" and layer_info.get("ok", True))
        if not layer_ok:
            bg = fg = None

        if a.mode == "provider":
            if not a.adapter and not a.command:
                sys.exit("Provider mode requires --adapter or --command.")
            item = {"scene": scene_id, "image": str(image), "duration": round(duration, 3),
                    "aspect_ratio": data.get("aspect_ratio", "9:16"), "prompt": scene.get("motion_prompt", ""), "output": str(clip)}
            if a.adapter:
                import importlib.util
                spec = importlib.util.spec_from_file_location("cinestory_video_adapter", a.adapter)
                if not spec or not spec.loader:
                    sys.exit(f"Cannot load adapter: {a.adapter}")
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                mod.generate(str(image), item["prompt"], str(clip), duration, item["aspect_ratio"])
            else:
                import shlex
                promptfile = out / f"{scene_id}.prompt.txt"
                promptfile.write_text(item["prompt"], encoding="utf-8")
                mapping = {"image": str(image), "prompt_file": str(promptfile), "output": str(clip), "duration": str(duration)}
                run([token.format(**mapping) for token in shlex.split(a.command)])
            stats = {"mean_frame_diff": None, "character_micro_movement": "provider_video", "parallax_layers_used": False}
        else:
            stats = render_cinematic_clip(
                image=image, output=clip, duration=duration, width=a.width, height=a.height,
                fps=fps, crf=a.crf, move=move, strength=scene_strength, style=a.style,
                effects=effects, light_coords=lp, background=bg, foreground=fg,
                focus=camera.get("focus"), seed=index + 271,
            )

        if not clip.exists() or clip.stat().st_size == 0:
            sys.exit(f"Animation did not create a valid scene clip: {clip}")

        used_parallax = bool(stats["parallax_layers_used"])
        fallback_reason = None if used_parallax else (layer_info.get("reason") or scene.get("parallax_fallback_reason") or ("parallax disabled" if a.parallax == "off" else "safe full-image environmental animation"))
        animated_props = [k for k in ("clock_motion", "gentle_sway") if effects[k]]

        manifest.append({
            "scene": scene_id,
            "image": str(image),
            "duration": round(duration, 3),
            "camera_move": move,
            "camera_movement": {"move": move, "strength": scene_strength, "focus": camera.get("focus") or [0.5, 0.48]},
            "motion_strength": scene_strength,
            "code_motion": a.mode == "code",
            "motion_type": "multi_plane_parallax_cinematic" if used_parallax else "full_image_cinematic_environment",
            "foreground_background_layers": used_parallax,
            "parallax_layers_used": ["background", "subject_midground"] if used_parallax else [],
            "layer_quality_score": layer_info.get("quality_score") if used_parallax else None,
            "local_light_animation": "candle_flicker" if effects["candle_flicker"] else ("lamp_glow" if effects["lamp_glow"] else None),
            "particles": effects["dust_particles"],
            "atmospheric_rays": effects["atmospheric_rays"],
            "steam": effects["steam"],
            "animated_props": animated_props,
            "character_micro_movement": stats["character_micro_movement"],
            "mean_frame_diff": stats["mean_frame_diff"],
            "fallback_used": not used_parallax,
            "fallback_reason": fallback_reason,
            "output": str(clip),
        })
        fx_summary = ", ".join(k for k, v in effects.items() if v) or "camera_only"
        print(f"ANIMATED: {scene_id} | {move} | {'2.5D parallax' if used_parallax else 'safe full-image'} | fx=[{fx_summary}] | diff={stats['mean_frame_diff']} | {duration:.2f}s")

    (out / "motion_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    plan_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    parallax_count = sum(1 for item in manifest if item.get("foreground_background_layers"))
    print(f"MOTION COMPLETE: {len(manifest)} clip(s), {parallax_count} with quality-verified 2.5D parallax.")


if __name__ == "__main__":
    main()
