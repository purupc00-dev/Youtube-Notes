#!/usr/bin/env python3
"""Generate scene stills with the optional, billable OpenAI Images API.

This script is deliberately opt-in. It never calls the API unless the user
explicitly supplies --allow-billable-api and approves a maximum image count.
"""
import argparse
import base64
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", help="Story plan JSON")
    parser.add_argument("--out", default="assets/images")
    parser.add_argument("--model", default=os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1"))
    parser.add_argument("--size", default=os.getenv("OPENAI_IMAGE_SIZE", "1024x1536"))
    parser.add_argument(
        "--quality",
        default=os.getenv("OPENAI_IMAGE_QUALITY", "medium"),
        help="Image quality; defaults to medium to avoid an unrequested high-quality setting.",
    )
    parser.add_argument(
        "--allow-billable-api",
        action="store_true",
        help="Required explicit opt-in; verify current provider pricing before use.",
    )
    parser.add_argument(
        "--max-images",
        type=int,
        default=1,
        help="Maximum number of new API generations permitted in this run (default: 1).",
    )
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()

    if not args.allow_billable_api:
        sys.exit(
            "ERROR: this provider is billable. Review current OpenAI image pricing and obtain "
            "explicit approval, then rerun with --allow-billable-api."
        )
    if args.max_images < 1:
        sys.exit("ERROR: --max-images must be at least 1.")
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        sys.exit("ERROR: set OPENAI_API_KEY in your environment; never put it in story_plan.json.")

    plan_path = Path(args.plan)
    data = json.loads(plan_path.read_text(encoding="utf-8"))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    scenes = data.get("scenes")
    if not isinstance(scenes, list):
        sys.exit("ERROR: story plan must contain a scenes list.")

    pending = []
    manifest = []
    for scene in scenes:
        name = scene.get("image_file") or f"{scene['id']}.png"
        dest = out / name
        if dest.exists() and not args.overwrite:
            print(f"SKIP existing {dest}")
            manifest.append({"scene": scene["id"], "image": str(dest)})
        else:
            pending.append((scene, dest))

    if len(pending) > args.max_images:
        sys.exit(
            f"PRE-FLIGHT STOP: {len(pending)} new image(s) are needed, but --max-images is "
            f"{args.max_images}. Review the provider's current price and obtain approval for "
            "a higher cap before rerunning. No API request was sent."
        )

    print(
        f"PRE-FLIGHT: {len(pending)} billable image request(s); model={args.model}, "
        f"size={args.size}, quality={args.quality}. No API requests will exceed this count.",
        flush=True,
    )

    for index, (scene, dest) in enumerate(pending, 1):
        prompt = scene["image_prompt"]
        payload = {
            "model": args.model,
            "prompt": prompt,
            "size": args.size,
            "quality": args.quality,
            "n": 1,
        }
        request = urllib.request.Request(
            "https://api.openai.com/v1/images/generations",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        print(f"Generating {index}/{len(pending)}: {scene['id']} ...", flush=True)
        try:
            with urllib.request.urlopen(request, timeout=240) as response:
                result = json.loads(response.read())
            item = result["data"][0]
            if item.get("b64_json"):
                raw = base64.b64decode(item["b64_json"])
            elif item.get("url"):
                with urllib.request.urlopen(item["url"], timeout=120) as response:
                    raw = response.read()
            else:
                raise RuntimeError("API response had neither b64_json nor url")
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(raw)
            manifest.append({"scene": scene["id"], "image": str(dest)})
        except urllib.error.HTTPError as error:
            body = error.read().decode(errors="replace")
            sys.exit(f"OpenAI image API error {error.code}: {body}")
        except Exception as error:
            sys.exit(f"Image generation failed for {scene['id']}: {error}")

    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"DONE: {len(manifest)} scene image(s) listed in {out}/manifest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
