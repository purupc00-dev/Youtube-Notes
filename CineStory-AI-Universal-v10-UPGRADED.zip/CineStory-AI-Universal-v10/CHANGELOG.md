# CineStory AI v10 Changelog (Upgraded from v9)

## 1. Master Narration Timeline & Word-Level Alignment (`scripts/align_narration.py`, `scripts/voice_generation.py`)
- **Voice is now the master timeline**: `build_approved_short.py` runs `align_narration.py` before motion, subtitles, and rendering so every scene cut and subtitle card is driven by the actual spoken narration duration rather than fixed 4–5s storyboard estimates.
- **Official ElevenLabs Timestamp & Alignment Support**:
  - `voice_generation.py` now defaults to `/v1/text-to-dialogue/with-timestamps` (for `eleven_v4`/`eleven_v3`) and `/v1/text-to-speech/{voice_id}/with-timestamps` (for `eleven_multilingual_v2`), saving `audio/voice_alignment_raw.json`.
  - `align_narration.py` supports uploaded narration via ElevenLabs `POST /v1/forced-alignment`, optional local Hindi-capable `faster-whisper` / `whisperx` (`requirements-alignment.txt`), and an explicit, honestly flagged `vad_speech_envelope_fallback` when neither is available.
- **Structured `audio_alignment.json`**: Records transcript, ordered word timestamps, confidence scores, 2–3 word phrase boundaries, scene-to-narration mapping, actual voice duration, and explicit `is_fallback` status.

## 2. Redesigned Devanagari-Safe Hindi Subtitle Cards (`scripts/generate_styled_subtitles.py`, `scripts/render_video.py`)
- **Fixed broken Hindi matra rendering**: Replaced FFmpeg/libass-only rendering (which corrupted `ि` matras such as `जसिका`/`दनि-रात` on hosts without HarfBuzz libass) with Pillow + `libraqm` (HarfBuzz + FriBidi) rendering using bundled `NotoSansDevanagari-Bold.ttf`.
- **CineStory Subtitle Card design**: Warm soft-cream rounded rectangle (`#FAF6EE`), subtle parchment border, soft multi-pass drop shadow, dark charcoal Devanagari text (`#1C1917`), and selective single-word amber emphasis (`#B8660E`), centered in the lower-third safe zone.
- **Short 2–3 word animated cards**: Smooth 130ms cubic ease-out entrance (fade in + 94%→100% scale + 14px upward lift) and 80ms fade-out composited via transparent RGBA overlay (`captions_overlay.mov`), with companion `.ass` export preserved.

## 3. Upgraded Music Engine & Three Genuinely Distinct Scores (`scripts/generate_audio_assets.py`, `assets/audio-library/music/`)
- **Fixed identical fallback music bug**: Replaced v9's single-melody `make_music()` (which only differed by a volume scalar erased by normalization) with three genuinely distinct multi-instrument compositions in different keys, tempos, hooks, and rhythms:
  1. `light_cinematic_motivation` (`hopeful.mp3`): D major, 108 BPM, bright plucked/piano hook, brushed percussion, rising strings.
  2. `warm_acoustic_storytelling` (`warm_emotional.mp3`): G major, 96 BPM, fingerpicked acoustic guitar/mandolin, felt piano, organic pulse, warm cello/strings.
  3. `emotional_uplifting_score` (`moody.mp3`): A minor → C major, 88 BPM, lyrical piano, deep bass, lush restrained strings swelling to a hopeful resolution.
- **Music Auditions & Duplicate Guard**: Added `--auditions` mode, SHA-256 + 16-band spectral/energy fingerprint verification (`verify_distinct_tracks`), and honest provenance logging in `music_manifest.json` (`ai` vs `library_fallback`).

## 4. Cinematic Procedural Motion & Layer Quality Gate (`scripts/prepare_parallax_layers.py`, `scripts/animate_scenes.py`)
- **Automated Layer Quality Gate**: Evaluates foreground coverage (3%–62%), max contiguous hole radius, mask fragmentation, inpainted Laplacian sharpness continuity, and seam color jump. Damaged/smeared backgrounds are rejected automatically so the complete original image is preserved.
- **Live Frame-Accurate Environmental Animation**: Replaced static 13% PNG overlays with OpenCV + NumPy frame-accurate compositing: localized pulsing `lamp_glow`, organic `candle_flicker`, 3-depth-layer `dust_particles`, `atmospheric_rays`, curling `steam`, ticking `clock_motion`, safe-masked `gentle_sway`, and subtle safe foreground breathing micro-motion.
- **Real Motion Proof**: `motion_manifest.json` records exact layers, effects, mean inter-frame pixel delta (`mean_frame_diff`), and honest fallback reasons.

## 5. Automated QA & New Kabir Sample Story (`scripts/verify_qa.py`, `examples/kabir_night_school/`)
- Added `verify_qa.py` generating `review/sync_report.json` and visual `review/qa-contact-sheet.png` covering narration sync, subtitle card integrity, music audibility/distinctness, and motion delta proof.
- Added the 8-beat Hindi test story **Kabir & the Old Tea Seller** (`examples/kabir_night_school/story_plan.json`).
- Preserved all v9 working features, workflow checkpoints, Warm Cinematic 3D default style, and Cloudflare Worker env vars (`CINESTORY_CLOUDFLARE_API_KEY`, `CINESTORY_CLOUDFLARE_WORKER_URL`).
