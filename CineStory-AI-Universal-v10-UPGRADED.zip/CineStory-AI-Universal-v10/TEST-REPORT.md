# CineStory AI Universal v10 — Test & QA Report

## Summary
- **Unit & Integration Test Suite:** 77 / 77 tests PASSED (`python3 -m unittest discover -s tests -v`).
- **Python Syntax Compilation:** PASSED (`python3 -m compileall -q scripts tests adapters`).
- **JavaScript Syntax Check:** PASSED (`node --check cloudflare/CINESTORY-WORKER-PATCH.js` and `engines/remotion-template/gen-sfx.mjs`).
- **Sample Story Plan Validation:** PASSED (`examples/kabir_night_school/story_plan.json` — 8 scenes, 9:16, 24 fps).
- **Offline End-to-End Smoke Render:** PASSED (`build_approved_short.py` with real Hindi narration audio and scene frames, zero paid API credits consumed).

## Verified v10 Capabilities
1. **Master Narration Timeline & Alignment (`scripts/align_narration.py`, `scripts/voice_generation.py`)**
   - Verified official ElevenLabs `/v1/text-to-dialogue/with-timestamps` and `/v1/text-to-speech/{voice_id}/with-timestamps` character-to-word aggregation (mocked HTTP, Devanagari-safe).
   - Verified `audio_alignment.json` generation, monotonic word timestamps, 2–3 word phrase grouping with 100% word preservation, and variable narration-driven scene boundaries (smoke render aligned 12.0s planned scenes to actual 9.528s voice duration: 4.35s, 1.81s, 3.37s).
   - Verified explicit fallback reporting (`is_fallback: true` + warning) when neither provider timestamps nor local Whisper aligners are available.
2. **Devanagari-Safe CineStory Subtitle Cards (`scripts/generate_styled_subtitles.py`, `scripts/render_video.py`)**
   - Verified Pillow `libraqm` (HarfBuzz + FriBidi) rendering with bundled `NotoSansDevanagari-Bold.ttf`.
   - Visually inspected rendered Hindi Subtitle Cards (`एक गरीब घड़ीसाज़`, `जिसका नाम`, `संतोष था।`, `वह दिन-रात मेहनत`) confirming proper `ि` matra reordering, soft-cream rounded cards, dark charcoal typography, warm amber keyword emphasis, and 130ms ease-out scale+lift+fade overlay animation.
3. **Music Engine & Distinct Fallback Library (`scripts/generate_audio_assets.py`, `assets/audio-library/music/`)**
   - Rebuilt all 3 bundled fallback music tracks with distinct keys, tempos, hooks, and instrumentation (`light_cinematic_motivation`, `warm_acoustic_storytelling`, `emotional_uplifting_score`).
   - Verified distinct SHA-256 hashes, 16-band spectral/envelope fingerprint non-duplication (`distinct: true`), audibility (`-21.55 dB` RMS), intro/outro fades, and honest `music_manifest.json` provenance.
4. **Cinematic Procedural Motion & Layer Quality Gate (`scripts/prepare_parallax_layers.py`, `scripts/animate_scenes.py`)**
   - Verified automated layer quality gate rejects oversized/smeared inpainted plates and accepts clean cutouts.
   - Verified live frame-accurate `lamp_glow`, `dust_particles`, `atmospheric_rays`, `clock_motion`, and `steam` in smoke render (`mean_frame_diff_avg: 3.506`, zero static scenes) and visual `qa-contact-sheet.png`.

## Tests Not Run (External / Live APIs)
- Live paid calls to Cloudflare Workers AI, ElevenLabs TTS/Music/SFX/Forced-Alignment APIs, and live `rembg`/U2Net model download were intentionally NOT executed during offline packaging to avoid consuming paid quota or requiring outbound sandbox internet. All API request/response contracts are covered by unit tests with mocks.
