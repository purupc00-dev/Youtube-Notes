# Visual style presets

## Default: Warm cinematic 3D
Use in every image prompt unless the user selects another preset:

"Cinematic high-end 3D animated feature-film still, original stylized-realistic character design, emotionally expressive natural eyes, subtle believable facial expression, anatomically plausible hands and body, detailed lived-in environment, physically motivated warm amber/golden key light and soft rim light, gentle warm bounce on faces, atmospheric volumetric dust where appropriate, shallow depth of field, cinematic composition, rich restrained earthy color palette (warm browns, ochre, muted teal), nuanced soft shadows, polished global illumination, subtle film grain, vertical 9:16 composition, intentional foreground/midground/background depth, clear subject silhouette, no text, no subtitles, no watermark, no logo."

Mood adaptation:
- hardship: low warm practical light with gentle cool window fill, muted earth tones; preserve dignity and avoid caricature.
- tenderness: warm practical light, intimate close-up, soft falloff, eye catchlights.
- hope: warm golden backlight and subtle face bounce, not oversaturated.
- resolution: fuller warm light, emotionally earned composition.

Negative prompt baseline:
"text, captions, watermark, logo, extra fingers, fused fingers, malformed hands, duplicate people, duplicate limbs, inconsistent face, inconsistent clothes, changing age, plastic skin, uncanny eyes, distorted anatomy, low resolution, oversharpening, extreme expression, oversaturated colors, cropped head, cropped hands."

## Optional variants
- Moody cinematic 3D: preserve the same character realism and camera grammar; deeper shadows, cooler ambient fill, warm practical highlights, restrained saturation.
- Golden fairytale 3D: preserve realism and anatomy; honey-gold sunlight, softer bloom, airy atmosphere, luminous warmth.
- Soft storybook 3D: preserve cinematic depth and expressive characters; tactile cloth/wood/paper materials, slightly illustrated surface finish, soft warm light.

## Continuity rules
1. Generate character reference portrait(s) before scene images.
2. Reuse reference images when the image model supports them.
3. Repeat exact character bible descriptions in every relevant scene prompt.
4. Keep face, age, hair, clothing, body proportions and signature props identical unless the script explicitly changes them.
5. Use shot variety: wide establishing, medium two-shot, close-up, extreme detail, over-shoulder, low-angle payoff.
6. Show the actual narrated action, not generic character portraits.
