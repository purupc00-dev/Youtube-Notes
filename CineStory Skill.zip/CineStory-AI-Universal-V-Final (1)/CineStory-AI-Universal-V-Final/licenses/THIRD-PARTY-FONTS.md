# Third-party font notices

This project redistributes fonts inside the preserved Faceless Shorts reference
engine. Their original font metadata remains embedded in each font file.

## Inter

- Files: `Inter-Black.otf`, `Inter-ExtraBold.otf` in the style example folders.
- Copyright: Copyright 2016 The Inter Project Authors.
- License: SIL Open Font License 1.1.
- Full license: `OFL-1.1.txt`.
- Font metadata identifies Inter as a trademark of rsms.

## Caladea

- Files: `Caladea-Bold.ttf` in the `paper-atlas` and `tall-tale` style examples.
- Copyright: Copyright 2012 The Caladea Project Authors.
- License: SIL Open Font License 1.1.
- Full license: `OFL-1.1.txt`.
- The font metadata identifies Caladea as a trademark of Carolina Giovagnoli & Andres Torresi.

## GNU FreeFont FreeMono Bold

- File: `FreeMonoBold.ttf` in the `night-file` style example.
- Copyright: GNU FreeFont contributors, 2002–2020 (as embedded in the font metadata).
- License: GNU General Public License version 3 or (at your option) any later version, with the font-embedding exception reproduced in `FreeMono-Font-Exception.txt`.
- Full GPL text: `GPL-3-FreeMono.txt`.

## Three.js

The retained reference styles include vendored Three.js files. Their upstream
license notices are preserved beside the vendored files at each applicable
`vendor/LICENSE-three.txt` path.

## Noto Sans Devanagari

- Files: `assets/fonts/NotoSansDevanagari-Regular.ttf` and `assets/fonts/NotoSansDevanagari-Bold.ttf`.
- Copyright: Copyright 2022 The Noto Project Authors (https://github.com/notofonts/devanagari).
- License: SIL Open Font License 1.1.
- Full license: `OFL-1.1.txt`.
- Bundled to make Hindi/Devanagari subtitle rendering consistent on hosts that do not have an Indic font installed. The renderer loads this directory through FFmpeg's `fontsdir` option.
