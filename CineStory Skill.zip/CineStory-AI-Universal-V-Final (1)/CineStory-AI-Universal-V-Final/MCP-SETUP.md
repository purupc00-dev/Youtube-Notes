# CineStory remote MCP setup

## REST is the default and does not require MCP

The deployed CineStory Cloudflare Worker v2 supports prompt-to-image and multi-reference image generation over REST. The Python image adapter calls `POST https://imagegen.mramazifier.workers.dev/generate` with Bearer authentication and receives raw image bytes. Shell-capable agents should use REST; it is simpler and has fewer moving parts.

## Optional remote MCP endpoint

The Worker is not an MCP server until the optional add-on is deployed. `cloudflare/CINESTORY-WORKER-PATCH.js` adds a stateless Streamable HTTP endpoint at `/mcp`, exposing `generate_cinestory_scene_image` and `generate_cinestory_storyboard_images`. It reuses the existing Workers AI binding `AI` and secret `API_KEY`. It is only an alternate tool interface; it does not replace the REST path.

### Deploy safely

1. Back up the current Worker source before editing.
2. In the Worker `fetch(request, env)` handler, immediately after `const url = new URL(request.url);`, add:
   `if (url.pathname === "/mcp") return handleCineStoryMcp(request, env);`
3. Append the complete contents of `cloudflare/CINESTORY-WORKER-PATCH.js` to the Worker source.
4. Keep the existing `/`, `/generate` and other REST handlers unchanged. Keep the Workers AI binding `AI` and the rotated `API_KEY` secret.
5. For browser-based MCP clients that send an `Origin` header, add a Worker variable named `CINESTORY_MCP_ALLOWED_ORIGINS` with a comma-separated list of exact allowed origins, e.g. `https://your-agent.example`. Do not use `*`. Server-to-server clients that send no `Origin` are allowed through this CORS gate, but still require Bearer authentication.
6. Deploy. The MCP endpoint is `https://imagegen.mramazifier.workers.dev/mcp`.

### Protocol and security behaviour

- POST is used for JSON-RPC; OPTIONS is available for browser preflight. GET is not implemented by this stateless add-on.
- The add-on accepts MCP protocol revisions `2026-07-28`, `2025-11-25`, `2025-06-18` and `2025-03-26`. The `2026-07-28` path requires matching `MCP-Protocol-Version`, `params._meta["io.modelcontextprotocol/protocolVersion"]`, and `Mcp-Method`; `tools/call` also requires `Mcp-Name` to match the tool name.
- Bearer authentication is always required. If an `Origin` header is present, it must match `CINESTORY_MCP_ALLOWED_ORIGINS` exactly. Wildcard CORS is deliberately disabled.
- The storyboard batch tool accepts up to four images per request. Larger storyboards should be split into smaller batches by the calling agent to avoid Worker request timeouts.
- Each scene generation consumes Workers AI allowance. A partial batch can return successful images and explicit failed scene IDs; the caller must not silently treat a partial batch as complete.

The endpoint has been syntax-checked and tested with mocked Cloudflare Workers AI responses. It has not been live-deployed or handshake-tested against every MCP client. Confirm `tools/list` in the selected host before using image-generation calls. A test generation consumes quota.

## Client setup

Use the official setup instructions for the exact product/version you use; do not assume identical MCP UI or plan support:

- Claude Code: https://code.claude.com/docs/en/mcp
- Codex: https://developers.openai.com/codex/mcp
- Grok/xAI remote MCP: https://docs.x.ai/developers/tools/remote-mcp
- Manus connectors: https://manus.im/features/connectors
- ChatGPT custom MCP: https://help.openai.com/en/articles/12584461-connecting-custom-mcp-servers-in-chatgpt

Configure the URL and rotated Bearer secret in the host's private MCP header/secret setting. Do not put the key in a prompt, skill file, source file, terminal screenshot or ZIP.

## Local REST mode

For a runtime with Python, shell and HTTPS access, set `CINESTORY_CLOUDFLARE_API_KEY` privately and run `scripts/generate_cloudflare_images.py`. This avoids the MCP patch entirely.
