# CineStory AI Universal v10

A portable, interactive skill and automated production toolkit for warm cinematic 9:16 Hindi/Hinglish/English storytelling shorts.

## What's New in v10

1. **Narration-Master Timeline (`scripts/align_narration.py`):** Final narration audio drives every scene cut and subtitle timestamp — never arbitrary 4–5s storyboard guesses. Uses official ElevenLabs `/with-timestamps` for generated narration, ElevenLabs `/v1/forced-alignment` or local `faster-whisper`/`whisperx` for uploaded narration, and an explicitly flagged `vad_speech_envelope_fallback` when neither is available. Writes `audio/audio_alignment.json`.
2. **Devanagari-Safe CineStory Subtitle Cards (`scripts/generate_styled_subtitles.py`):** Renders 2–3 word rounded soft-cream cards (`#FAF6EE`) with dark charcoal text (`#1C1917`), soft drop shadow, single-word amber emphasis (`#B8660E`), and a smooth 130ms ease-out entrance (fade + 94%→100% scale + upward lift) using Pillow + `libraqm` (HarfBuzz/FriBidi) and bundled `NotoSansDevanagari-Bold.ttf` — fixing broken Hindi `ि` matras permanently.
3. **Three Genuinely Distinct Musical Identities (`scripts/generate_audio_assets.py`):** `light_cinematic_motivation`, `warm_acoustic_storytelling`, and `emotional_uplifting_score` — each with distinct keys, tempos, opening hooks, instrumentation, and rhythms in both AI prompts and the rebuilt procedural fallback library. Includes `--auditions`, SHA-256 + spectral fingerprint duplicate checks, voice ducking, and honest `music_manifest.json` provenance.
4. **Quality-Gated Cinematic Motion (`scripts/prepare_parallax_layers.py`, `scripts/animate_scenes.py`):** Automatically rejects smeared/oversized inpainted backgrounds (preserving the complete original image) and renders frame-accurate localized `lamp_glow`, `candle_flicker`, 3-depth `dust_particles`, `atmospheric_rays`, rising `steam`, `clock_motion`, safe-masked `gentle_sway`, and subtle foreground breathing with `motion_manifest.json` motion proof.
5. **Real Automated QA (`scripts/verify_qa.py`) & Kabir Sample Story (`examples/kabir_night_school/`):** Generates `review/sync_report.json` and visual `review/qa-contact-sheet.png` verifying narration sync, Hindi card integrity, music audibility/distinctness, and frame-to-frame motion delta.

## Simple OpenCode Web / GitHub Codespaces Installation

Replacing v9 with v10 keeps your existing `.env` file completely intact:

1. Unzip `CineStory-AI-Universal-v10-UPGRADED.zip` into your OpenCode skills folder (for example `.opencode/skills/cine-story-ai/`), replacing the previous `CineStory-AI-Universal-v9` folder.
2. Keep your existing `.env` file in place — all v9 environment variable names remain 100% compatible:
   - `CINESTORY_CLOUDFLARE_API_KEY`
   - `CINESTORY_CLOUDFLARE_WORKER_URL` (default `https://imagegen.mramazifier.workers.dev/`)
   - `ELEVENLABS_API_KEY`
   - Optional: `CINESTORY_ALIGNER_PROVIDER` (`auto`, `elevenlabs_tts`, `elevenlabs_forced`, `faster_whisper`, `whisperx`, `vad_fallback`)
3. Verify the installation and run the offline test suite (uses zero paid API credits):
   ```bash
   cd .opencode/skills/cine-story-ai/CineStory-AI-Universal-v10
   python3 -m unittest discover -s tests -v
   ```
4. Optional local Hindi forced alignment for uploaded audio (only needed if you do not use ElevenLabs Forced Alignment):
   ```bash
   pip install -r requirements-alignment.txt
   ```

## Default One-Command Production

After story, script, voice, style, and storyboard approval:

```bash
python3 scripts/build_approved_short.py PROJECT \
  --style warm_cinematic_3d \
  --music-style warm_acoustic_storytelling \
  --audio-provider auto \
  --parallax auto \
  --subtitle-mode cards
```

Outputs:
- `renders/CineStory-Final.mp4` (1080×1920, 24 fps, H.264 + stereo 48 kHz AAC)
- `audio/audio_alignment.json` (word timestamps, 2–3 word phrases, scene mapping)
- `audio/music_manifest.json` & `audio/audio_manifest.json` (honest AI vs fallback provenance + hashes)
- `assets/video/motion_manifest.json` (actual layers, effects, motion delta proof)
- `review/sync_report.json`, `review/production-report.json`, and `review/qa-contact-sheet.png`

## Preserved v9 Features

All v9 capabilities remain intact: 3 story concepts, 3 script versions, voice auditions, user-uploaded voice support (`scripts/import_voice.py`), character bible & reference conditioning, Warm Cinematic 3D default style, Cloudflare FLUX.2 Klein 4B Worker integration, storyboard approval gate, timed SFX, vertical 1080×1920 24 fps export, and `scripts/workflow.py` state/resume checkpoints.
