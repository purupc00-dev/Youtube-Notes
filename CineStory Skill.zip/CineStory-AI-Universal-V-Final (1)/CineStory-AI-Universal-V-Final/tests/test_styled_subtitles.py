import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import generate_styled_subtitles as subtitles


class StyledSubtitleTests(unittest.TestCase):
    def test_srt_to_ass_has_valid_fade_override_and_amber_highlight(self):
        with tempfile.TemporaryDirectory() as td:
            source = Path(td) / "captions.srt"
            output = Path(td) / "captions.ass"
            source.write_text("1\n00:00:00,000 --> 00:00:02,000\nमाँ ने उम्मीद नहीं छोड़ी।\n", encoding="utf-8")
            with patch.object(sys, "argv", ["generate_styled_subtitles.py", str(source), "--out", str(output)]):
                subtitles.main()
            value = output.read_text(encoding="utf-8-sig")
            self.assertIn(r"{\fad(100,130)}", value)
            self.assertIn(r"{\c&H0080BEFF&\b1}उम्मीद", value)
            self.assertIn(r"{\c&H0080BEFF&\b1}माँ", value)
            self.assertNotIn(r"{\\fad", value)

    def test_bundled_noto_font_is_selected_for_hindi_even_without_fontconfig(self):
        with patch.object(subtitles.shutil, "which", return_value=None):
            self.assertEqual(subtitles.resolve_font("Arial", "हिंदी कहानी"), "Noto Sans Devanagari")

    def test_timestamp_centiseconds_round_down(self):
        self.assertEqual(subtitles.ass_time("00:00:01,239"), "0:00:01.23")

    def test_multiline_srt_is_preserved_as_ass_newline_not_escaped_text(self):
        value = subtitles.highlight("पहली पंक्ति\\Nदूसरी पंक्ति")
        self.assertIn(r"पहली पंक्ति\Nदूसरी पंक्ति", value)
        self.assertNotIn(r"\\N", value)

    def test_long_hindi_caption_wraps_to_two_lines_without_dropping_words(self):
        text = "एक छोटी बच्ची अंधेरे गलियारे में अपने पड़ोसी के साथ धीरे धीरे आगे बढ़ती रही"
        wrapped = subtitles.wrap_caption_text(text)
        self.assertLessEqual(len(wrapped.split(r"\N")), 2)
        self.assertEqual(" ".join(wrapped.replace(r"\N", " ").split()), text)

    def test_caption_braces_are_escaped_before_ass_rendering(self):
        value = subtitles.highlight("यह {टेस्ट} है")
        self.assertIn(r"\{टेस्ट\}", value)


if __name__ == "__main__":
    unittest.main()
