import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import generate_audio_assets as audio


class AudioGenerationTests(unittest.TestCase):
    def test_music_uses_music_v25_instrumental_and_duration(self):
        captured = {}
        def fake_request(url, key, payload, timeout=180):
            captured.update(url=url, payload=payload, timeout=timeout)
            return b"fake-mp3", {"song-id": "test-song"}
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "music.mp3"
            with patch.object(audio, "api_request", side_effect=fake_request), patch.object(audio, "validate_generated_audio", return_value={"duration_seconds": 34.5}):
                result = audio.generate_ai_music("test-key", "warm cinematic piano score", 34.5, out)
            self.assertEqual(captured["url"], "https://api.elevenlabs.io/v1/music?output_format=mp3_48000_192")
            self.assertEqual(captured["payload"]["model_id"], "music_v2_5")
            self.assertTrue(captured["payload"]["force_instrumental"])
            self.assertEqual(captured["payload"]["music_length_ms"], 34500)
            self.assertEqual(out.read_bytes(), b"fake-mp3")
            self.assertEqual(result["song_id"], "test-song")

    def test_sfx_v3_lets_model_choose_duration(self):
        captured = {}
        def fake_request(url, key, payload, timeout=180):
            captured.update(url=url, payload=payload, timeout=timeout)
            return b"fake-sfx", {"character-cost": "test"}
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "door.mp3"
            with patch.object(audio, "api_request", side_effect=fake_request), patch.object(audio, "validate_generated_audio", return_value={"duration_seconds": 1.8}):
                result = audio.generate_ai_sfx("test-key", "A soft wooden door creaks open", 1.8, out)
            self.assertEqual(captured["url"], "https://api.elevenlabs.io/v1/sound-generation?output_format=mp3_44100_128")
            self.assertEqual(captured["payload"]["model_id"], "eleven_text_to_sound_v3")
            self.assertNotIn("duration_seconds", captured["payload"])
            self.assertEqual(result["mix_window_seconds"], 1.8)
            self.assertEqual(out.read_bytes(), b"fake-sfx")

    def test_default_sfx_limit_scales_to_cover_all_scenes(self):
        self.assertEqual(audio.resolve_max_sfx(None, "16", 8), 16)
        self.assertEqual(audio.resolve_max_sfx(None, "16", 28), 28)
        self.assertEqual(audio.resolve_max_sfx(30, "16", 28), 30)

    def test_sfx_limit_rejects_unbounded_or_negative_values(self):
        with self.assertRaisesRegex(ValueError, "between 0 and 100"):
            audio.resolve_max_sfx(101, "16", 8)
        with self.assertRaisesRegex(ValueError, "between 0 and 100"):
            audio.resolve_max_sfx(-1, "16", 8)

    def test_identical_sfx_prompts_are_kept_for_each_scene(self):
        plan = {"scenes": [
            {"id": "scene_01", "start": 0, "end": 3, "sfx_events": [{"prompt": "soft room tone", "start": 0.5}]},
            {"id": "scene_02", "start": 3, "end": 6, "sfx_events": [{"prompt": "soft room tone", "start": 3.5}]},
        ]}
        cues = audio.build_cues(plan, 2)
        self.assertEqual([cue["scene"] for cue in cues], ["scene_01", "scene_02"])

    def test_invalid_custom_cues_fall_back_to_scene_ambience(self):
        plan = {"scenes": [
            {"id": "scene_01", "start": 0, "end": 3, "sfx_events": [{"prompt": "   "}], "action": "quiet room"},
        ]}
        cues = audio.build_cues(plan, 1)
        self.assertEqual(len(cues), 1)
        self.assertEqual(cues[0]["scene"], "scene_01")
        self.assertTrue(cues[0]["prompt"])

    def test_custom_sfx_timing_is_clamped_to_scene(self):
        plan = {"scenes": [
            {"id": "scene_01", "start": 10, "end": 12, "sfx_events": [
                {"prompt": "door closes", "start": 99, "duration": 60, "volume": 3}
            ]},
        ]}
        cue = audio.build_cues(plan, 1)[0]
        self.assertLessEqual(cue["start"], 11.98)
        self.assertLessEqual(cue["duration"], 0.10 + 1e-9)
        self.assertLessEqual(cue["volume"], 0.5)

    def test_invalid_generated_audio_is_not_committed(self):
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "music.mp3"
            out.write_bytes(b"previous-good-asset")
            with patch.object(audio, "validate_generated_audio", side_effect=RuntimeError("not audio")):
                with self.assertRaisesRegex(RuntimeError, "not audio"):
                    audio.write_and_validate_audio(b"provider-html-error", out)
            self.assertEqual(out.read_bytes(), b"previous-good-asset")
            self.assertFalse(out.with_suffix(".mp3.tmp").exists())

    def test_non_idempotent_generation_request_is_not_retried(self):
        import urllib.request
        calls = {"count": 0}
        def fail(*args, **kwargs):
            calls["count"] += 1
            raise TimeoutError("simulated timeout")
        with patch.object(urllib.request, "urlopen", side_effect=fail):
            with self.assertRaisesRegex(RuntimeError, "without retry"):
                audio.api_request("https://example.test/generate", "k", {"x": 1})
        self.assertEqual(calls["count"], 1)


if __name__ == "__main__":
    unittest.main()
