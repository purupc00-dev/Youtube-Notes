"""Mocked contract tests for the optional Cloudflare remote MCP patch."""
from __future__ import annotations

import base64
import json
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATCH = ROOT / "cloudflare" / "CINESTORY-WORKER-PATCH.js"

NODE_HARNESS = r'''const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(process.argv[1], 'utf8') + '\n;globalThis.__handle = handleCineStoryMcp;';
const sandbox = {
  Request, Response, Headers, FormData, Blob, URL, Uint8Array, ArrayBuffer,
  TextEncoder, TextDecoder, atob, btoa, Buffer, console, setTimeout, clearTimeout
};
vm.createContext(sandbox);
vm.runInContext(source, sandbox);
const handler = sandbox.__handle;
const PROTOCOL = '2026-07-28';
const META = { 'io.modelcontextprotocol/protocolVersion': PROTOCOL,
  'io.modelcontextprotocol/clientInfo': { name: 'CineStory test', version: '1.0' },
  'io.modelcontextprotocol/clientCapabilities': {} };
function makeRequest(method, params, options={}) {
  const jsonMethod = options.jsonMethod || method;
  const headers = {
    'Authorization': options.authorization || 'Bearer test-secret',
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/event-stream',
  };
  if (options.protocol !== 'legacy') {
    headers['MCP-Protocol-Version'] = PROTOCOL;
    headers['Mcp-Method'] = options.mcpMethod || jsonMethod;
    if (jsonMethod === 'tools/call') headers['Mcp-Name'] = params.name || '';
  }
  if (options.origin) headers['Origin'] = options.origin;
  const body = { jsonrpc: '2.0', id: options.noId ? undefined : 7,
    method: jsonMethod, params: options.protocol === 'legacy' ? params : { ...params, _meta: META } };
  if (options.noId) delete body.id;
  return new Request('https://worker.test/mcp', { method: 'POST', headers, body: JSON.stringify(body) });
}
async function call(req, env={API_KEY:'test-secret', CINESTORY_MCP_ALLOWED_ORIGINS:'https://allowed.example', AI:{run: async()=>({image:Buffer.from([137,80,78,71,13,10,26,10]).toString('base64')})}}) {
  const response = await handler(req, env);
  const text = await response.text();
  let json = null; try { json = text ? JSON.parse(text) : null; } catch {}
  return { status: response.status, headers: Object.fromEntries(response.headers), json, text };
}
(async()=>{
  const results = {};
  results.discover = await call(makeRequest('server/discover', {}));
  results.toolsList = await call(makeRequest('tools/list', {}));
  results.originDenied = await call(makeRequest('tools/list', {}, {origin:'https://evil.example'}));
  results.unauthorized = await call(makeRequest('tools/list', {}, {authorization:'Bearer wrong'}));
  results.headerMismatch = await call(makeRequest('tools/list', {}, {mcpMethod:'tools/call'}));
  const unknownBody={jsonrpc:'2.0',id:9,method:'tools/list',params:{_meta:{'io.modelcontextprotocol/protocolVersion':'2099-01-01'}}};
  const unknownReq=new Request('https://worker.test/mcp',{method:'POST',headers:{Authorization:'Bearer test-secret','Content-Type':'application/json','Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2099-01-01','Mcp-Method':'tools/list'},body:JSON.stringify(unknownBody)});
  results.unsupportedVersion = await call(unknownReq);
  const ref = Buffer.from([137,80,78,71,13,10,26,10]).toString('base64');
  let mockMultipart = null;
  const aiEnv = { API_KEY:'test-secret', AI:{ run: async(model, opts)=>{
    const req = new Request('https://worker.test/', {method:'POST', headers:{'Content-Type':opts.multipart.contentType}, body:opts.multipart.body, duplex:'half'});
    const form = await req.formData();
    mockMultipart = {model, prompt:form.get('prompt'), width:form.get('width'), height:form.get('height'), refType:form.get('input_image_0')?.type || null};
    return {image:ref};
  }}};
  results.imageCall = await call(makeRequest('tools/call', {name:'generate_cinestory_scene_image', arguments:{scene_id:'scene_01',prompt:'Warm cinematic test scene',reference_images:[{mime_type:'image/png',data:ref}]}}), aiEnv);
  results.multipart = mockMultipart;
  results.notification = await call(makeRequest('tools/list', {}, {noId:true}));
  const legacyBody = {jsonrpc:'2.0',id:8,method:'initialize',params:{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'legacy test',version:'1'}}};
  const legacyReq = new Request('https://worker.test/mcp',{method:'POST',headers:{Authorization:'Bearer test-secret','Content-Type':'application/json','Accept':'application/json, text/event-stream'},body:JSON.stringify(legacyBody)});
  results.legacyInitialize = await call(legacyReq);
  console.log(JSON.stringify(results));
})().catch(e=>{console.error(e.stack||String(e));process.exit(1);});
'''

class CloudflareMcpPatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        result = subprocess.run(
            ["node", "-e", NODE_HARNESS, str(PATCH)],
            capture_output=True, text=True, timeout=20,
        )
        if result.returncode:
            raise RuntimeError(result.stderr or result.stdout)
        cls.results = json.loads(result.stdout.strip().splitlines()[-1])

    def test_discovery_implements_2026_protocol(self):
        result = self.results["discover"]
        self.assertEqual(result["status"], 200)
        body = result["json"]["result"]
        self.assertEqual(body["resultType"], "complete")
        self.assertIn("io.modelcontextprotocol/serverInfo", body["_meta"])
        self.assertEqual(body["supportedVersions"], ["2026-07-28"])
        self.assertEqual(body["cacheScope"], "private")
        self.assertEqual(body["ttlMs"], 3600000)

    def test_tools_list_is_cacheable_and_has_result_type(self):
        body = self.results["toolsList"]["json"]["result"]
        self.assertEqual(body["resultType"], "complete")
        self.assertEqual(body["cacheScope"], "private")
        self.assertGreaterEqual(body["ttlMs"], 0)
        self.assertEqual(len(body["tools"]), 2)

    def test_origin_allowlist_and_authentication(self):
        self.assertEqual(self.results["originDenied"]["status"], 403)
        self.assertEqual(self.results["unauthorized"]["status"], 401)

    def test_mirrored_method_header_mismatch_is_rejected(self):
        self.assertEqual(self.results["headerMismatch"]["status"], 400)
        self.assertEqual(self.results["headerMismatch"]["json"]["error"]["code"], -32020)

    def test_unsupported_protocol_returns_negotiation_error(self):
        result = self.results["unsupportedVersion"]
        self.assertEqual(result["status"], 400)
        error = result["json"]["error"]
        self.assertEqual(error["code"], -32022)
        self.assertIn("2026-07-28", error["data"]["supported"])
        self.assertEqual(error["data"]["requested"], "2099-01-01")

    def test_reference_image_is_forwarded_to_workers_ai(self):
        result = self.results["imageCall"]
        self.assertEqual(result["status"], 200)
        content = result["json"]["result"]["content"]
        self.assertTrue(any(item.get("type") == "image" for item in content))
        multipart = self.results["multipart"]
        self.assertEqual(multipart["model"], "@cf/black-forest-labs/flux-2-klein-4b")
        self.assertEqual(multipart["width"], "720")
        self.assertEqual(multipart["height"], "1280")
        self.assertEqual(multipart["refType"], "image/png")

    def test_2026_notifications_are_rejected(self):
        self.assertEqual(self.results["notification"]["status"], 400)

    def test_legacy_initialize_remains_available(self):
        result = self.results["legacyInitialize"]
        self.assertEqual(result["status"], 200)
        self.assertEqual(result["json"]["result"]["protocolVersion"], "2025-11-25")


if __name__ == "__main__":
    unittest.main()
