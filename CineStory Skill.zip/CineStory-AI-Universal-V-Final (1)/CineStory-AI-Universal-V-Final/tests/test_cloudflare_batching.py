import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import io

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import generate_cloudflare_images as images


class CloudflareBatchingTests(unittest.TestCase):
    def make_plan(self, project: Path, count: int = 3) -> Path:
        scenes = []
        for index in range(1, count + 1):
            scenes.append({
                "id": f"scene_{index:02d}", "start": (index - 1) * 3.0, "end": index * 3.0,
                "image_prompt": f"warm cinematic 3D scene {index}", "negative_prompt": "text, logo",
                "image_file": f"scene_{index:02d}.png",
            })
        plan = project / "story_plan.json"
        plan.write_text(json.dumps({"title": "Test", "scenes": scenes}, ensure_ascii=False), encoding="utf-8")
        return plan

    def test_relative_output_is_project_relative_and_images_are_batched(self):
        with tempfile.TemporaryDirectory() as td:
            project = Path(td)
            plan = self.make_plan(project, 3)
            out = project / "assets" / "images"
            buffer = io.BytesIO()
            Image.new("RGB", (720, 1280), (120, 80, 40)).save(buffer, format="PNG")
            fake_bytes = buffer.getvalue()
            calls = []
            def fake_request(opener, worker_url, key, prompt, refs=None, reference_mode="character"):
                calls.append(prompt)
                return fake_bytes, ".png", None
            with patch.object(sys, "argv", ["generate_cloudflare_images.py", str(plan), "--max-images", "1"]), \
                 patch.dict(os.environ, {"CINESTORY_CLOUDFLARE_API_KEY": "test-secret", "CINESTORY_CLOUDFLARE_WORKER_URL": images.DEFAULT_WORKER_URL}, clear=False), \
                 patch.object(images, "request_image", side_effect=fake_request):
                result = images.main()
            self.assertEqual(result, 0)
            self.assertEqual(len(calls), 3)
            self.assertTrue((out / "manifest.json").is_file())
            saved_plan = json.loads(plan.read_text(encoding="utf-8"))
            self.assertTrue(all((out / scene["image_file"]).is_file() for scene in saved_plan["scenes"]))

    def test_unknown_selected_scene_is_rejected_before_generation(self):
        with tempfile.TemporaryDirectory() as td:
            plan = self.make_plan(Path(td), 2)
            with patch.object(sys, "argv", ["generate_cloudflare_images.py", str(plan), "--scene-ids", "scene_99"]), \
                 patch.dict(os.environ, {"CINESTORY_CLOUDFLARE_API_KEY": "test-secret"}, clear=False):
                with self.assertRaises(SystemExit) as caught:
                    images.main()
            self.assertIn("unknown --scene-ids", str(caught.exception))

    def test_rejects_more_than_four_character_refs_before_request(self):
        import json, tempfile, subprocess
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); plan = root / "story_plan.json"; out = root / "images"
            refs = [{"id": f"c{i}", "image_prompt": "a consistent character"} for i in range(5)]
            plan.write_text(json.dumps({"scenes": [{"id": "scene_01", "image_prompt": "a scene"}], "character_references": refs}), encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts" / "generate_cloudflare_images.py"), str(plan), "--out", str(out), "--dry-run"], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("at most four", result.stderr)


if __name__ == "__main__":
    unittest.main()
