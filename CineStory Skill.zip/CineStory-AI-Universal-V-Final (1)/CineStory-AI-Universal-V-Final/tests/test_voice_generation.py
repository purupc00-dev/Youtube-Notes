import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import voice_generation as voice


class VoiceGenerationTests(unittest.TestCase):
    def test_speech_endpoint_uses_selected_voice_and_zero_retention(self):
        captured = {}
        def fake_audio(url, key, body, timeout=180):
            captured.update(url=url, body=body)
            return b"fake-mp3"
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "voice.mp3"
            with patch.object(voice, "request_audio", side_effect=fake_audio):
                result = voice.synthesize("नमस्ते दुनिया।", "voice-id-123", "key", out)
            self.assertIn("/text-to-dialogue?", captured["url"])
            self.assertNotIn("enable_logging=false", captured["url"])
            self.assertEqual(captured["body"]["model_id"], "eleven_v4")
            self.assertEqual(captured["body"]["inputs"][0]["text"], "नमस्ते दुनिया।")
            self.assertEqual(captured["body"]["inputs"][0]["voice_id"], "voice-id-123")
            self.assertEqual(out.read_bytes(), b"fake-mp3")
            self.assertEqual(result["voice_id"], "voice-id-123")
            self.assertFalse(result["zero_retention_requested"])

    def test_env_files_merge_missing_keys_from_parent_runtime(self):
        import os
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); project = root / "project"; cwd = root / "cwd"
            project.mkdir(); cwd.mkdir()
            (project / ".env").write_text("CINESTORY_PROJECT_KEY=project-value\n", encoding="utf-8")
            (cwd / ".env").write_text("CINESTORY_RUNTIME_KEY=runtime-value\n", encoding="utf-8")
            keys = ("CINESTORY_PROJECT_KEY", "CINESTORY_RUNTIME_KEY")
            old = {key: os.environ.pop(key, None) for key in keys}
            previous = Path.cwd()
            try:
                os.chdir(cwd)
                voice.load_env(project)
                self.assertEqual(os.environ.get(keys[0]), "project-value")
                self.assertEqual(os.environ.get(keys[1]), "runtime-value")
            finally:
                os.chdir(previous)
                for key in keys:
                    os.environ.pop(key, None)
                    if old[key] is not None:
                        os.environ[key] = old[key]

    def test_tts_model_uses_environment_default_and_cli_override(self):
        with patch.dict(voice.os.environ, {"ELEVENLABS_TTS_MODEL": "eleven_multilingual_v2"}, clear=False):
            self.assertEqual(voice.configured_model(), "eleven_multilingual_v2")
            self.assertEqual(voice.configured_model("eleven_v4"), "eleven_v4")
        with patch.dict(voice.os.environ, {"ELEVENLABS_TTS_MODEL": "invalid-model"}, clear=False):
            with self.assertRaisesRegex(ValueError, "supported ELEVENLABS_TTS_MODEL"):
                voice.configured_model()

    def test_preview_text_ends_at_sentence_boundary(self):
        text = ("यह पहला वाक्य है। " * 30).strip()
        preview = voice.make_preview_text(text, 100)
        self.assertTrue(preview.endswith("।"))
        self.assertLessEqual(len(preview), 100)

    def test_tts_billable_post_is_not_retried(self):
        import urllib.request
        calls = {"n": 0}
        def timeout(*args, **kwargs):
            calls["n"] += 1
            raise TimeoutError("simulated timeout")
        with patch.object(urllib.request, "urlopen", side_effect=timeout):
            with self.assertRaisesRegex(RuntimeError, "not retried"):
                voice.request_audio("https://example.invalid", "key", {"text": "hello"})
        self.assertEqual(calls["n"], 1)


if __name__ == "__main__":
    unittest.main()
