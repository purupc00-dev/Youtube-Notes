import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import render_video


class RenderValidationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.project = Path(self.tmp.name)
        self.plan = self.project / "story_plan.json"
        self.images = self.project / "assets" / "images"
        self.clips = self.project / "assets" / "video"
        self.audio = self.project / "audio"
        self.images.mkdir(parents=True)
        self.clips.mkdir(parents=True)
        self.audio.mkdir(parents=True)
        self.data = {
            "duration_seconds": 5.0,
            "scenes": [{"id": "scene_01", "start": 0.0, "end": 5.0,
                        "image_file": "scene_01.png", "video_file": "scene_01.mp4"}],
        }
        self.plan.write_text(json.dumps(self.data), encoding="utf-8")
        (self.clips / "scene_01.mp4").write_bytes(b"clip")
        (self.images / "scene_01.png").write_bytes(b"image")
        (self.audio / "voice.mp3").write_bytes(b"voice")
        (self.audio / "music.mp3").write_bytes(b"music")
        (self.audio / "sfx.mp3").write_bytes(b"sfx")
        self.srt = self.project / "captions.srt"
        self.srt.write_text("1\n00:00:00,000 --> 00:00:05,000\nनमस्ते।\n", encoding="utf-8")
        self.manifest = self.audio / "audio_manifest.json"
        self.manifest.write_text(json.dumps({
            "music": str(self.audio / "music.mp3"),
            "sfx_events": [{"scene": "scene_01", "file": str(self.audio / "sfx.mp3"),
                            "start": 1.0, "duration": 1.0, "volume": 0.16}],
        }), encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def validate(self, **overrides):
        values = dict(
            data=self.data, plan_path=self.plan, images=self.images, clips=self.clips,
            voice_value=str(self.audio / "voice.mp3"), music_value=None,
            sfx_map_value=str(self.manifest), ass_value=None, srt_value=str(self.srt),
            allow_no_voice=False, allow_still_fallback=False,
        )
        values.update(overrides)
        return render_video.validate_inputs(**values)

    def test_complete_asset_set_passes(self):
        voice, music, manifest, sfx, subtitles = self.validate()
        self.assertEqual(voice, self.audio / "voice.mp3")
        self.assertEqual(music, self.audio / "music.mp3")
        self.assertEqual(len(sfx), 1)
        self.assertEqual(subtitles, self.srt)

    def test_missing_music_is_blocked(self):
        manifest = json.loads(self.manifest.read_text())
        manifest["music"] = None
        self.manifest.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(RuntimeError, "music track is required"):
            self.validate()

    def test_missing_sfx_is_blocked(self):
        manifest = json.loads(self.manifest.read_text())
        manifest["sfx_events"] = []
        self.manifest.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(RuntimeError, "At least one timed SFX"):
            self.validate()

    def test_missing_sfx_file_is_blocked(self):
        manifest = json.loads(self.manifest.read_text())
        manifest["sfx_events"][0]["file"] = str(self.audio / "missing.mp3")
        self.manifest.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(RuntimeError, "SFX file listed"):
            self.validate()

    def test_missing_voice_is_blocked_unless_explicitly_allowed(self):
        with self.assertRaisesRegex(RuntimeError, "Narration is required"):
            self.validate(voice_value=None)
        result = self.validate(voice_value=None, allow_no_voice=True)
        self.assertIsNone(result[0])

    def test_missing_subtitle_file_is_blocked(self):
        with self.assertRaisesRegex(RuntimeError, "SRT subtitle file does not exist"):
            self.validate(srt_value=str(self.project / "missing.srt"))

    def test_missing_motion_clip_is_blocked(self):
        (self.clips / "scene_01.mp4").unlink()
        with self.assertRaisesRegex(RuntimeError, "Missing required motion clip"):
            self.validate()

    def test_subtitle_filter_includes_bundled_fonts_directory(self):
        ass = self.project / "captions.ass"
        fonts = ROOT / "assets" / "fonts"
        value = render_video.build_subtitle_filter(ass, fonts)
        self.assertIn("subtitles=", value)
        self.assertIn("fontsdir=", value)
        self.assertIn("NotoSansDevanagari-Regular.ttf", [p.name for p in fonts.iterdir()])

    def test_short_sfx_duration_is_not_artificially_extended(self):
        duration = render_video.bounded_sfx_duration(
            {"scene": "scene_01", "start": 1.0, "duration": 0.12},
            {"scene_01": (0.0, 5.0)}, 5.0
        )
        self.assertAlmostEqual(duration, 0.12)

    def test_sfx_duration_is_clamped_to_owning_scene(self):
        duration = render_video.bounded_sfx_duration(
            {"scene": "scene_01", "start": 4.7, "duration": 2.0},
            {"scene_01": (0.0, 5.0)}, 10.0
        )
        self.assertAlmostEqual(duration, 0.3)

    def test_sfx_duration_is_clamped_to_final_timeline(self):
        duration = render_video.bounded_sfx_duration(
            {"scene": "scene_01", "start": 4.7, "duration": 2.0},
            {"scene_01": (0.0, 8.0)}, 5.0
        )
        self.assertAlmostEqual(duration, 0.3)

    def test_unknown_scene_sfx_fails(self):
        with self.assertRaisesRegex(RuntimeError, "unknown scene"):
            render_video.bounded_sfx_duration(
                {"scene": "scene_99", "start": 1.0, "duration": 1.0},
                {"scene_01": (0.0, 5.0)}, 5.0
            )

    def test_every_scene_must_have_an_sfx_or_ambience_cue(self):
        second_scene = {"id": "scene_02", "start": 5.0, "end": 10.0,
                        "image_file": "scene_02.png", "video_file": "scene_02.mp4"}
        self.data["duration_seconds"] = 10.0
        self.data["scenes"].append(second_scene)
        (self.clips / "scene_02.mp4").write_bytes(b"clip")
        (self.images / "scene_02.png").write_bytes(b"image")
        with self.assertRaisesRegex(RuntimeError, "Every scene must have at least one timed SFX/ambience cue"):
            self.validate()


if __name__ == "__main__":
    unittest.main()
