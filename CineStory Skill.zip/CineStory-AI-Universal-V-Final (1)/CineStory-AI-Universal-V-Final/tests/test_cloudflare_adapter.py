import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import generate_cloudflare_images as cloudflare


class FakeResponse:
    def __init__(self, body, headers):
        self.body = body
        self.headers = headers
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def read(self): return self.body


class FakeOpener:
    def __init__(self, response):
        self.response = response
        self.requests = []
    def open(self, request, timeout=0):
        self.requests.append((request, timeout))
        return self.response


def png_bytes(size=(720, 1280)):
    buffer = io.BytesIO()
    Image.new("RGB", size, (80, 120, 160)).save(buffer, format="PNG")
    return buffer.getvalue()


class CloudflareAdapterTests(unittest.TestCase):
    def test_worker_v2_contract_uses_references_and_dimensions(self):
        raw = png_bytes()
        opener = FakeOpener(FakeResponse(raw, {
            "Content-Type": "image/png",
            "X-CineStory-Reference-Count": "1",
            "X-CineStory-Width": "720",
            "X-CineStory-Height": "1280",
        }))
        refs = [{"mimeType": "image/jpeg", "data": "ZmFrZQ=="}]
        result, ext, used = cloudflare.request_image(opener, cloudflare.DEFAULT_WORKER_URL, "secret", "scene prompt", refs)
        payload = json.loads(opener.requests[0][0].data.decode())
        self.assertEqual(payload["width"], 720)
        self.assertEqual(payload["height"], 1280)
        self.assertEqual(payload["referenceMode"], "character")
        self.assertEqual(payload["references"], refs)
        self.assertNotIn("reference_images", payload)
        self.assertEqual(result, raw)
        self.assertEqual(ext, ".png")
        self.assertEqual(used, 1)

    def test_generation_request_is_not_retried_on_timeout(self):
        class TimeoutOpener:
            def __init__(self): self.calls = 0
            def open(self, request, timeout=0):
                self.calls += 1
                raise TimeoutError("simulated timeout")
        opener = TimeoutOpener()
        with self.assertRaisesRegex(RuntimeError, "without retry"):
            cloudflare.request_image(opener, cloudflare.DEFAULT_WORKER_URL, "secret", "scene prompt")
        self.assertEqual(opener.calls, 1)

    def test_reference_conditioning_must_be_confirmed(self):
        opener = FakeOpener(FakeResponse(png_bytes(), {"Content-Type": "image/png", "X-CineStory-Reference-Count": "0"}))
        with self.assertRaisesRegex(RuntimeError, "not confirmed"):
            cloudflare.request_image(opener, cloudflare.DEFAULT_WORKER_URL, "secret", "scene prompt", [{"mimeType": "image/jpeg", "data": "x"}])

    def test_rejects_wrong_image_dimensions(self):
        opener = FakeOpener(FakeResponse(png_bytes((512, 512)), {"Content-Type": "image/png", "X-CineStory-Reference-Count": "0"}))
        with self.assertRaisesRegex(RuntimeError, "expected 720x1280"):
            cloudflare.request_image(opener, cloudflare.DEFAULT_WORKER_URL, "secret", "scene prompt")


if __name__ == "__main__":
    unittest.main()
