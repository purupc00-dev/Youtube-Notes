import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
class WorkflowTests(unittest.TestCase):
    def run_cli(self, *args):
        return subprocess.run([sys.executable, str(ROOT/"scripts"/"workflow.py"), *map(str,args)], capture_output=True, text=True)
    def test_approval_cannot_skip_stage(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(self.run_cli("init", td).returncode, 0)
            result=self.run_cli("approve", td, "storyboard")
            self.assertEqual(result.returncode, 2)
            state=json.loads((Path(td)/"workflow.json").read_text())
            self.assertEqual(state["current_stage"], "concepts")
            self.assertEqual(state["approved"], [])
    def test_sequential_approval_advances_once(self):
        with tempfile.TemporaryDirectory() as td:
            self.run_cli("init", td)
            result=self.run_cli("approve", td, "concepts")
            self.assertEqual(result.returncode, 0, result.stderr)
            state=json.loads((Path(td)/"workflow.json").read_text())
            self.assertEqual(state["current_stage"], "script")
            self.assertEqual(state["approved"], ["concepts"])
    def test_script_mode_can_skip_concept_ideation(self):
        with tempfile.TemporaryDirectory() as td:
            result = self.run_cli("init", td, "--start-at", "script")
            self.assertEqual(result.returncode, 0, result.stderr)
            state = json.loads((Path(td) / "workflow.json").read_text(encoding="utf-8"))
            self.assertEqual(state["current_stage"], "script")
            self.assertEqual(state["approved"], ["concepts"])

if __name__ == "__main__": unittest.main()
