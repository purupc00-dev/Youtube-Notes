import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ValidationAndSetupTests(unittest.TestCase):
    def test_example_plan_passes_strict_validator(self):
        result = subprocess.run([sys.executable, str(ROOT / "scripts" / "validate_plan.py"), str(ROOT / "examples" / "story_plan.json")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_validator_rejects_duplicate_scene_ids_and_gaps(self):
        import json
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.json"
            data = json.loads((ROOT / "examples" / "story_plan.json").read_text(encoding="utf-8"))
            data["scenes"][1]["id"] = data["scenes"][0]["id"]
            data["scenes"][1]["start"] += 1.0
            path.write_text(json.dumps(data), encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts" / "validate_plan.py"), str(path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 1)
            self.assertIn("duplicate id", result.stdout)
            self.assertIn("gap", result.stdout)

    def test_validator_rejects_more_than_four_character_references(self):
        import json, tempfile, subprocess
        data = json.loads((ROOT / "examples" / "story_plan.json").read_text(encoding="utf-8"))
        data["character_references"] = [{"id": f"c{i}", "image_prompt": "reference"} for i in range(5)]
        with tempfile.TemporaryDirectory() as td:
            plan = Path(td) / "plan.json"
            plan.write_text(json.dumps(data), encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts" / "validate_plan.py"), str(plan)], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("at most four", result.stdout)

    def test_validator_rejects_unknown_character_reference_ids(self):
        import json, tempfile, subprocess
        data = json.loads((ROOT / "examples" / "story_plan.json").read_text(encoding="utf-8"))
        data["scenes"][0]["reference_character_ids"] = ["missing-character"]
        with tempfile.TemporaryDirectory() as td:
            plan = Path(td) / "plan.json"
            plan.write_text(json.dumps(data), encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "scripts" / "validate_plan.py"), str(plan)], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("unknown character reference", result.stdout)

    def test_setup_help_does_not_install_or_download(self):
        result = subprocess.run([sys.executable, str(ROOT / "scripts" / "setup_motion.py"), "--help"], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("--install", result.stdout)
        self.assertIn("--download-model", result.stdout)


if __name__ == "__main__":
    unittest.main()
