import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import build_approved_short as build


class ApprovedShortHelperTests(unittest.TestCase):
    def test_empty_starter_srt_is_not_treated_as_valid(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "captions.srt"
            path.write_text("", encoding="utf-8")
            self.assertFalse(build.has_valid_srt_events(path))

    def test_valid_srt_cue_is_detected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "captions.srt"
            path.write_text("1\n00:00:00,000 --> 00:00:02,500\nनमस्ते\n", encoding="utf-8")
            self.assertTrue(build.has_valid_srt_events(path))

    def test_malformed_srt_is_not_treated_as_valid(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "captions.srt"
            path.write_text("not a caption file", encoding="utf-8")
            self.assertFalse(build.has_valid_srt_events(path))

    def test_default_audio_command_leaves_sfx_limit_dynamic(self):
        command = build.make_audio_command(Path("plan.json"), Path("audio"), "warm_emotional", "auto")
        self.assertNotIn("--max-sfx", command)

    def test_explicit_audio_command_max_sfx_is_forwarded(self):
        command = build.make_audio_command(Path("plan.json"), Path("audio"), "warm_emotional", "auto", 22)
        self.assertEqual(command[command.index("--max-sfx") + 1], "22")


if __name__ == "__main__":
    unittest.main()
