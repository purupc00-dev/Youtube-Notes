import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import prepare_parallax_layers as parallax
import animate_scenes


class ParallaxLayerTests(unittest.TestCase):
    def test_strict_parallax_rejects_failed_segmentation(self):
        scenes = [{"id": "scene_01"}, {"id": "scene_02"}]
        results = {"scene_01": {"ok": True}, "scene_02": {"ok": False, "reason": "empty mask"}}
        with self.assertRaisesRegex(RuntimeError, "Strict 2.5D parallax"):
            animate_scenes.require_parallax_results(results, scenes, "on")

    def test_strict_parallax_accepts_all_valid_layers(self):
        scenes = [{"id": "scene_01"}, {"id": "scene_02"}]
        results = {"scene_01": {"ok": True}, "scene_02": {"ok": True}}
        animate_scenes.require_parallax_results(results, scenes, "on")

    def test_auto_mode_can_accept_camera_only_fallback(self):
        scenes = [{"id": "scene_01"}]
        results = {"scene_01": {"ok": False, "reason": "empty mask"}}
        animate_scenes.require_parallax_results(results, scenes, "auto")

    def test_existing_layers_are_reused_without_rembg_runtime(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            images = root / "assets" / "images"
            layers = root / "assets" / "layers"
            images.mkdir(parents=True)
            layers.mkdir(parents=True)
            (images / "scene_01.png").write_bytes(b"placeholder-image")
            (layers / "scene_01_background.jpg").write_bytes(b"placeholder-background")
            (layers / "scene_01_foreground.png").write_bytes(b"placeholder-foreground")
            plan = {
                "scenes": [{
                    "id": "scene_01",
                    "image_file": "scene_01.png",
                    "layers": {
                        "background": "assets/layers/scene_01_background.jpg",
                        "foreground": "assets/layers/scene_01_foreground.png"
                    }
                }]
            }
            plan_path = root / "story_plan.json"
            plan_path.write_text(json.dumps(plan), encoding="utf-8")
            result = parallax.prepare_project(plan_path, images, layers)
            self.assertTrue(result["scene_01"]["ok"])
            self.assertEqual(result["scene_01"]["method"], "existing layers")


if __name__ == "__main__":
    unittest.main()
