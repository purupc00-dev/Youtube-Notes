import fs from 'fs';
fs.mkdirSync('public/sfx',{recursive:true});
const SR=44100;
function wav(name,samples){const n=samples.length;const b=Buffer.alloc(44+n*2);
 b.write('RIFF',0);b.writeUInt32LE(36+n*2,4);b.write('WAVEfmt ',8);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);
 b.writeUInt32LE(SR,24);b.writeUInt32LE(SR*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(n*2,40);
 for(let i=0;i<n;i++){b.writeInt16LE(Math.max(-1,Math.min(1,samples[i]))*32767|0,44+i*2);} fs.writeFileSync('public/sfx/'+name+'.wav',b);}
let seed=7;const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647*2-1;};
// tick: short soft blip
{const n=SR*0.07|0;const s=new Float32Array(n);for(let i=0;i<n;i++){const t=i/SR;s[i]=Math.sin(2*Math.PI*1400*t)*Math.exp(-t*60)*0.5;}wav('tick',s);}
// pop: pitch drop
{const n=SR*0.18|0;const s=new Float32Array(n);let ph=0;for(let i=0;i<n;i++){const t=i/SR;const f=520*Math.exp(-t*14)+120;ph+=2*Math.PI*f/SR;s[i]=Math.sin(ph)*Math.exp(-t*22)*0.7;}wav('pop',s);}
// stamp: thud + click
{const n=SR*0.5|0;const s=new Float32Array(n);let ph=0;for(let i=0;i<n;i++){const t=i/SR;const f=95*Math.exp(-t*6)+45;ph+=2*Math.PI*f/SR;s[i]=Math.sin(ph)*Math.exp(-t*9)*0.9+rnd()*Math.exp(-t*90)*0.5;}wav('stamp',s);}
// printer: rapid noise bursts
{const n=SR*1.3|0;const s=new Float32Array(n);for(let i=0;i<n;i++){const t=i/SR;const g=(Math.floor(t*38)%2===0)?1:0.25;const env=Math.min(1,t*20)*Math.min(1,(1.3-t)*12);s[i]=rnd()*0.35*g*env+Math.sin(2*Math.PI*(900+60*Math.sin(t*38*6.28))*t)*0.06*env;}wav('printer',s);}
// whoosh: filtered noise swell
{const n=SR*0.35|0;const s=new Float32Array(n);let lp=0;for(let i=0;i<n;i++){const t=i/SR;const a=0.05+0.4*Math.sin(Math.PI*t/0.35);lp+=a*(rnd()-lp);s[i]=lp*Math.sin(Math.PI*t/0.35)*1.2;}wav('whoosh',s);}
// pad: warm ambient, 66 s
{const dur=66;const n=SR*dur|0;const s=new Float32Array(n);const notes=[110,164.81,220,277.18];for(let i=0;i<n;i++){const t=i/SR;let v=0;notes.forEach((f,k)=>{v+=Math.sin(2*Math.PI*f*t+Math.sin(t*0.3+k))*0.12+Math.sin(2*Math.PI*f*1.003*t)*0.08;});const lfo=0.75+0.25*Math.sin(2*Math.PI*t/9);const fade=Math.min(1,t/3)*Math.min(1,(dur-t)/3);s[i]=v*lfo*fade*0.5;}wav('pad',s);}

// ===== सिनेमैटिक/वायरल SFX (सब प्रोसीजरल, कॉपीराइट-मुक्त) =====
const mk=(sec)=>new Float32Array(SR*sec|0);
// boom: गहरा इम्पैक्ट (क्लाइमैक्स/हुक की चोट)
{const s=mk(1.6);let ph=0;for(let i=0;i<s.length;i++){const t=i/SR;const f=70*Math.exp(-t*3.2)+32;ph+=2*Math.PI*f/SR;s[i]=(Math.sin(ph)*Math.exp(-t*2.6)*0.95+rnd()*Math.exp(-t*25)*0.5);}wav('boom',s);}
// hit: छोटा तेज़ इम्पैक्ट (शब्द/कट पर)
{const s=mk(0.45);let ph=0;for(let i=0;i<s.length;i++){const t=i/SR;ph+=2*Math.PI*(120*Math.exp(-t*18)+55)/SR;s[i]=Math.sin(ph)*Math.exp(-t*9)*0.9+rnd()*Math.exp(-t*60)*0.4;}wav('hit',s);}
// riser: 2.5 s तनाव बढ़ाने वाली चढ़ती आवाज़ (क्लाइमैक्स से पहले)
{const d=2.5,s=mk(d);let ph=0,lp=0;for(let i=0;i<s.length;i++){const t=i/SR,p=t/d;ph+=2*Math.PI*(180+1400*p*p)/SR;lp+=(0.04+0.5*p)*(rnd()-lp);s[i]=(Math.sin(ph)*0.35+lp*0.9)*Math.pow(p,1.6)*0.8;}wav('riser',s);}
// rev: उल्टी स्वेल (टाइम-जंप / रिवाइंड / dip ट्रांज़िशन)
{const d=0.9,s=mk(d);let lp=0;for(let i=0;i<s.length;i++){const t=i/SR,p=t/d;lp+=(0.03+0.6*p)*(rnd()-lp);s[i]=lp*Math.pow(p,2.2)*1.3;}wav('rev',s);}
// heartbeat: दो धड़कनें (दुख/डर/तनाव)
{const s=mk(1.6);const beat=(t0,a)=>{for(let i=0;i<s.length;i++){const t=i/SR-t0;if(t<0)continue;s[i]+=Math.sin(2*Math.PI*(60-20*t)*t)*Math.exp(-t*16)*a;}};beat(0.0,0.9);beat(0.28,0.65);beat(0.8,0.9);beat(1.08,0.65);wav('heartbeat',s);}
// chime: नरम घंटी (उम्मीद/अच्छाई)
{const s=mk(2.2);[880,1320,1760,2640].forEach((f,k)=>{for(let i=0;i<s.length;i++){const t=i/SR;s[i]+=Math.sin(2*Math.PI*f*t)*Math.exp(-t*(2.2+k))*0.28/(k+1)*2;}});wav('chime',s);}
// sparkle: चमकती टिमटिम (जादुई/खुशी का पल)
{const s=mk(1.2);for(let k=0;k<9;k++){const t0=k*0.07,f=1800+k*310;for(let i=0;i<s.length;i++){const t=i/SR-t0;if(t<0)continue;s[i]+=Math.sin(2*Math.PI*f*t)*Math.exp(-t*20)*0.18;}}wav('sparkle',s);}
// coin: धातु की टन (पर्स/पैसा/सिक्का)
{const s=mk(0.9);[2100,3150,4700].forEach((f,k)=>{for(let i=0;i<s.length;i++){const t=i/SR;s[i]+=Math.sin(2*Math.PI*f*t)*Math.exp(-t*(7+k*3))*0.3;}});wav('coin',s);}
// click: कैमरा/बटन क्लिक
{const s=mk(0.08);for(let i=0;i<s.length;i++){const t=i/SR;s[i]=rnd()*Math.exp(-t*220)*0.7+Math.sin(2*Math.PI*900*t)*Math.exp(-t*160)*0.3;}wav('click',s);}
// steps: 4 कदमों की आहट
{const s=mk(2.0);let lp=0;for(let k=0;k<4;k++){const t0=0.1+k*0.48;for(let i=0;i<s.length;i++){const t=i/SR-t0;if(t<0||t>0.2)continue;lp+=0.25*(rnd()-lp);s[i]+=lp*Math.exp(-t*28)*0.9;}}wav('steps',s);}
// wind: 20 s हवा का बैकग्राउंड (दुख/सूनापन)
{const d=20,s=mk(d);let lp=0;for(let i=0;i<s.length;i++){const t=i/SR;const a=0.012+0.012*(1+Math.sin(t*0.7))/2;lp+=a*(rnd()-lp);s[i]=lp*3.0*Math.min(1,t/2)*Math.min(1,(d-t)/2);}wav('wind',s);}
// rain: 20 s बारिश
{const d=20,s=mk(d);let lp=0;for(let i=0;i<s.length;i++){const t=i/SR;lp+=0.55*(rnd()-lp);s[i]=(rnd()*0.5+lp*0.3)*0.28*Math.min(1,t/2)*Math.min(1,(d-t)/2);}wav('rain',s);}
// drone: 20 s गहरी तनाव वाली गूंज
{const d=20,s=mk(d);for(let i=0;i<s.length;i++){const t=i/SR;s[i]=(Math.sin(2*Math.PI*55*t)*0.4+Math.sin(2*Math.PI*82.4*t+Math.sin(t))*0.25+Math.sin(2*Math.PI*110.5*t)*0.12)*(0.7+0.3*Math.sin(t*0.9))*Math.min(1,t/3)*Math.min(1,(d-t)/3)*0.6;}wav('drone',s);}
