# Retained Remotion template status

This folder is preserved from the earlier Cine Story Video Builder project as a reusable reference/template. It is **not** the default CineStory v9 renderer and is not a standalone ready-to-render project as packaged. It expects a project-specific public asset folder (fonts, voice, music, SFX and media) and Node dependencies to be installed.

The supported default production path is the Python + FFmpeg pipeline in `scripts/`. Do not route normal CineStory production through this Remotion scaffold unless you first supply its expected assets, install dependencies and run its own build checks.
