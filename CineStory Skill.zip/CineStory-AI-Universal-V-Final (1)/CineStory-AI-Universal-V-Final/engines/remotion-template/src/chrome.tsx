import React, { useEffect, useState } from 'react';
import { AbsoluteFill, Sequence, delayRender, continueRender, interpolate, spring, staticFile, useCurrentFrame } from 'remotion';
import { C, FPS, SPRING, T, clamp } from './theme';
import { CAPS, TOTAL, Cap, SHOTS } from './data';
import { PAGE_NAME, END_LINE, HOOK, SHOW_CAPS, FONT_FILE, CAP_STYLE, CAP_BOTTOM, CAP_BOTTOM_VEC } from './brand';
const capBottom = (t: number) => (SHOTS.find((x) => t >= x.s && t < x.e)?.vec ? CAP_BOTTOM_VEC : CAP_BOTTOM);
const LAT = 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2212,U+FEFF';

// 'Cap' = प्रीमियम सेरिफ कैप्शन फॉन्ट (देवनागरी + लैटिन), 'Mark' = वॉटरमार्क फॉन्ट
const DEV = 'U+0900-097F,U+1CD0-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FF';
const FONTS: [string, string, string?][] = FONT_FILE
  ? [['Cap', FONT_FILE], ['Bold', FONT_FILE], ['Sub', FONT_FILE], ['Mark', 'hind-devanagari-700-normal.woff2']]
  : [['Cap', 'tiro-devanagari-hindi-devanagari-400-normal.woff2', DEV], ['Cap', 'tiro-devanagari-hindi-latin-400-normal.woff2'], ['Sub', 'montserrat-latin-600-normal.woff2', LAT], ['Sub', 'mukta-devanagari-700-normal.woff2', DEV], ['Bold', 'mukta-devanagari-800-normal.woff2', DEV], ['Bold', 'mukta-latin-800-normal.woff2'], ['Mark', 'hind-devanagari-700-normal.woff2']];
export const useFonts = () => {
  const [h] = useState(() => delayRender('fonts'));
  useEffect(() => {
    Promise.all(FONTS.map(([f, u, r]) => new FontFace(f, `url(${staticFile('fonts/' + u)})`, r ? { unicodeRange: r } : {}).load().then((ff) => document.fonts.add(ff))))
      .then(() => continueRender(h))
      .catch(() => continueRender(h));
  }, [h]);
};


// कोड से बने सीन का मंच: 540x960 डिज़ाइन-स्पेस → 1080x1920 (children SVG तत्व होने चाहिए)
export const Stage: React.FC<{ dur: number; push?: number; children: React.ReactNode; bg?: string }> = ({ dur, push = 0, children, bg }) => {
  const f = useCurrentFrame();
  const sc = 1 + push * (f / dur);
  return (
    <AbsoluteFill style={{ background: bg ?? C.beige }}>
      <div style={{ position: 'absolute', inset: 0, transform: `scale(${sc})`, transformOrigin: '50% 58%' }}>
        <div style={{ width: 540, height: 960, transform: 'scale(2)', transformOrigin: '0 0', position: 'relative', overflow: 'hidden' }}>
          <svg width={540} height={960} viewBox="0 0 540 960" style={{ position: 'absolute', left: 0, top: 0 }}>{children}</svg>
        </div>
      </div>
    </AbsoluteFill>
  );
};

const parse = (t: string) =>
  t.split('\n').map((line, i) => (
    <div key={i}>
      {line.split(/(\{[^}]+\})/).map((p, j) =>
        p.startsWith('{') ? <b key={j} style={{ color: C.gold, WebkitTextStroke: '1.6px #FFC857' }}>{p.slice(1, -1)}</b> : <span key={j}>{p}</span>
      )}
    </div>
  ));

// कैप्शन: कार्ड नहीं, सिनेमा-स्टाइल सफेद मोटा टेक्स्ट + गहरी छाया (नीचे से ~340px ऊपर: Shorts बटनों से दूर)
const Caption: React.FC<{ cap: Cap; len: number }> = ({ cap, len }) => {
  const f = useCurrentFrame();
  const sp = spring({ frame: f, fps: FPS, config: SPRING });
  const out = interpolate(f, [len - 5, len], [1, 0], clamp);
  return (
    <div style={{ position: 'absolute', left: 40, right: 40, bottom: capBottom(cap.s) - 60, display: 'flex', justifyContent: 'center', opacity: Math.min(1, sp) * out, transform: `translateY(${(1 - sp) * 18}px) scale(${0.94 + 0.06 * sp})` }}>
      <div style={{ fontFamily: 'Cap, serif', fontSize: 68, lineHeight: 1.38, letterSpacing: 0.5, color: C.white, textAlign: 'center', textShadow: '0 2px 2px #000d, 0 0 14px #000c, 0 0 34px #000a', WebkitTextStroke: '1.6px #FFF8EC' }}>
        {parse(cap.t)}
      </div>
    </div>
  );
};


// ===== वायरल कैप्शन: 2-3 शब्द एक साथ, बोला जा रहा शब्द पीला + पॉप, मोटा काला आउटलाइन =====
type W = { w: string; key: boolean; s: number; e: number };
const words = (cap: Cap): W[] => {
  const raw: { w: string; key: boolean }[] = [];
  cap.t.replace(/\n/g, ' ').split(/\s+/).filter(Boolean).forEach((tok) => {
    const key = tok.includes('{') || tok.includes('}');
    raw.push({ w: tok.replace(/[{}]/g, ''), key });
  });
  // समय हर शब्द की लंबाई के अनुपात में बाँटा जाता है
  const wt = raw.map((r) => Math.max(2, r.w.length) + 1.5);
  const tot = wt.reduce((a, b) => a + b, 0);
  let t = cap.s; const dur = cap.e - cap.s;
  return raw.map((r, i) => { const d = (wt[i] / tot) * dur; const o = { ...r, s: t, e: t + d }; t += d; return o; });
};
const chunk = (ws: W[]): W[][] => {
  const out: W[][] = []; let cur: W[] = [];
  ws.forEach((w) => {
    const len = cur.reduce((a, x) => a + x.w.length + 1, 0) + w.w.length;
    if (cur.length >= 3 || (cur.length >= 1 && len > 17)) { out.push(cur); cur = []; }
    cur.push(w);
  });
  if (cur.length) out.push(cur);
  return out;
};

// ===== क्लीन प्रीमियम कैप्शन: सफेद, तेज़ काली ड्रॉप-शैडो, 2-3 शब्द, सिर्फ धीमा फेड-इन (कोई पॉप/रंग-बदल नहीं) =====
const Clean: React.FC<{ cap: Cap }> = ({ cap }) => {
  const lf = useCurrentFrame(); const f = lf + T(cap.s); const t = f / FPS;
  const chunks = chunk(words(cap));
  const ci = chunks.findIndex((c, i) => t < (chunks[i + 1] ? chunks[i + 1][0].s : cap.e + 0.15));
  const k = ci < 0 ? chunks.length - 1 : ci;
  const ch = chunks[k];
  const st = ch[0].s, en = chunks[k + 1] ? chunks[k + 1][0].s : cap.e + 0.15;
  const op = interpolate(t, [st, st + 0.18, en - 0.1, en], [0, 1, 1, k === chunks.length - 1 ? 0 : 1], clamp);
  return (
    <div style={{ position: 'absolute', left: 60, right: 60, bottom: capBottom(cap.s), display: 'flex', justifyContent: 'center', opacity: op }}>
      <div style={{ fontFamily: 'Sub, sans-serif', fontWeight: 600, fontSize: 70, lineHeight: 1.3, letterSpacing: 0.5, color: '#FFFFFF', textAlign: 'center', textShadow: '3px 3px 0 #000, 4px 4px 0 #000' }}>{ch.map((w) => w.w).join(' ')}</div>
    </div>
  );
};
const OUT = '0 0 0 #000, 0 6px 0 #000, 0 0 22px #000c';
const Karaoke: React.FC<{ cap: Cap }> = ({ cap }) => {
  const lf = useCurrentFrame(); const f = lf + T(cap.s); const t = f / FPS; // Sequence के अंदर lf स्थानीय है; f = पूरे वीडियो का फ्रेम
  const chunks = chunk(words(cap));
  const ci = chunks.findIndex((c, i) => t < (chunks[i + 1] ? chunks[i + 1][0].s : cap.e + 0.25));
  const ch = chunks[ci < 0 ? chunks.length - 1 : ci];
  const pop = spring({ frame: f - T(ch[0].s), fps: FPS, config: { damping: 11, stiffness: 220, mass: 0.6 } });
  return (
    <div style={{ position: 'absolute', left: 30, right: 30, bottom: capBottom(cap.s), display: 'flex', justifyContent: 'center', gap: 22, flexWrap: 'wrap', transform: `scale(${0.82 + 0.18 * Math.min(1.12, pop)})`, opacity: Math.min(1, pop * 1.5) }}>
      {ch.map((w, i) => {
        const on = t >= w.s && t < w.e + 0.02;
        const wp = on ? spring({ frame: f - T(w.s), fps: FPS, config: { damping: 9, stiffness: 260, mass: 0.5 } }) : 1;
        const color = on ? '#FFE03A' : w.key ? '#FF8A3D' : '#FFFFFF';
        return (
          <span key={i} style={{ fontFamily: 'Bold, sans-serif', fontWeight: 800, fontSize: 92, lineHeight: 1.25, color, textShadow: OUT, WebkitTextStroke: '11px #000', paintOrder: 'stroke fill', display: 'inline-block', transform: `scale(${on ? 1 + 0.13 * Math.min(1, wp) : 1}) translateY(${on ? -4 : 0}px)` }}>{w.w}</span>
        );
      })}
    </div>
  );
};

export const Overlay: React.FC = () => {
  const f = useCurrentFrame();
  const endF = T(TOTAL);
  const fadeOut = interpolate(f, [endF - 14, endF], [0, 1], clamp);
  return (
    <AbsoluteFill>
      {/* नीचे की गहरी पट्टी ताकि कैप्शन साफ पढ़ें */}
      <AbsoluteFill style={{ background: 'linear-gradient(to top, rgba(10,5,0,0.55) 0%, rgba(10,5,0,0.0) 38%)' }} />
      {/* गर्म कलर-ग्रेड */}
      <AbsoluteFill style={{ background: 'linear-gradient(160deg, rgba(255,170,70,0.14), rgba(40,20,60,0.10))', mixBlendMode: 'soft-light' }} />
      {/* विनेट */}
      <AbsoluteFill style={{ background: 'radial-gradient(ellipse at center, transparent 55%, rgba(15,8,2,0.42) 100%)' }} />
      {/* हल्के धूल कण */}
      {Array.from({ length: 16 }).map((_, i) => {
        const x = (i * 137 + (f * (0.3 + (i % 4) * 0.15))) % 1080;
        const y = 1920 - ((i * 211 + f * (0.8 + (i % 3) * 0.4)) % 1920);
        const o = 0.14 + 0.1 * Math.sin((f + i * 9) / 17);
        return <div key={i} style={{ position: 'absolute', left: x, top: y, width: 5 + (i % 3) * 2, height: 5 + (i % 3) * 2, borderRadius: '50%', background: '#FFE2A8', opacity: o, filter: 'blur(1.5px)' }} />;
      })}
      {/* फिल्म ग्रेन */}
      <AbsoluteFill style={{ opacity: 0.07, mixBlendMode: 'overlay', backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='${(f % 3) + 1}'/><feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0.9 0 0'/></filter><rect width='300' height='300' filter='url(%23n)'/></svg>")` }} />
      {/* चलती सुनहरी रोशनी (light leak) */}
      <AbsoluteFill style={{ mixBlendMode: 'screen', opacity: 0.16, background: `radial-gradient(ellipse 55% 38% at ${20 + 60 * ((f / 260) % 1)}% ${12 + 8 * Math.sin(f / 70)}%, #FFB347 0%, transparent 70%)` }} />
      {/* हुक लाइन: पहले 2.5 सेकंड */}
      {HOOK !== '' && f < T(2.2) && (
        <div style={{ position: 'absolute', left: 60, right: 60, top: 330, textAlign: 'center', fontFamily: 'Sub, sans-serif', fontWeight: 600, fontSize: 88, lineHeight: 1.3, color: '#FFFFFF', textShadow: '4px 4px 0 #000, 5px 5px 0 #000', opacity: interpolate(f, [0, 12, T(1.9), T(2.2)], [0, 1, 1, 0], clamp) }}>{HOOK}</div>
      )}
      {/* वॉटरमार्क: नीचे-बीच में, पारदर्शी */}
      {PAGE_NAME !== '' && (
        <div style={{ position: 'absolute', top: 1640, left: 0, right: 0, textAlign: 'center', fontFamily: 'Mark, sans-serif', fontWeight: 700, fontSize: 40, letterSpacing: 1, color: '#FFE7D6', opacity: 0.5, textShadow: '0 2px 8px #0008' }}>{PAGE_NAME}</div>
      )}
      {SHOW_CAPS && CAPS.map((c, i) => {
        const len = T(c.e + 0.3) - T(c.s);
        return (
          <Sequence key={i} from={T(c.s)} durationInFrames={len}>
            {CAP_STYLE === 'clean' ? <Clean cap={c} /> : CAP_STYLE === 'karaoke' ? <Karaoke cap={c} /> : <Caption cap={c} len={len} />}
          </Sequence>
        );
      })}
      {END_LINE !== '' && f > endF - T(1.6) && (
        <div style={{ position: 'absolute', left: 60, right: 60, top: 820, textAlign: 'center', fontFamily: 'Hind, sans-serif', fontWeight: 700, fontSize: 72, color: C.gold, textShadow: '0 4px 20px #000', opacity: interpolate(f, [endF - T(1.6), endF - T(1.2)], [0, 1], clamp) }}>{END_LINE}</div>
      )}
      <AbsoluteFill style={{ background: '#000', opacity: fadeOut }} />
    </AbsoluteFill>
  );
};
