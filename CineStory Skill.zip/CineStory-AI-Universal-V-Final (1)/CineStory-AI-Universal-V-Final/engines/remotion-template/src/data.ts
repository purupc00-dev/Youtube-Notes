import rms from './rms.json';
export const RMS: number[] = rms as number[];
// SPEAK: किरदार के बोलने के समय (सिर्फ संवाद वाले किरदार का मुँह हिलाने के लिए): { boy: [[1.0, 2.5]] }
export const SPEAK: Record<string, [number, number][]> = {};

// ===== उदाहरण डेटा: हर नई वीडियो में इसे पूरा बदलें =====
export const TOTAL = 14.0; // आवाज़ + 1.5 सेकंड | बिना आवाज़: सभी शॉट की लंबाई का जोड़

export type Move = 'in' | 'out' | 'panL' | 'panR' | 'up' | 'down' | 'still';
export type Trans = 'fade' | 'zoom' | 'dip' | 'flash'; // इस शॉट में प्रवेश कैसे हो
// sfx: इस शॉट के सापेक्ष [फाइल, सेकंड-ऑफ़सेट, वॉल्यूम]। फाइल .wav के बिना (जनरेटेड) या पूरा नाम public/sfx/ से (अपनी SFX)
// file = AI फोटो/क्लिप (public/media/), vec = कोड से बना सीन (scenes.tsx के VEC में नाम)। दोनों में से एक दें।
export type Shot = { s: number; e: number; file?: string; vec?: string; move: Move; fx?: [number, number]; tr?: Trans; sfx?: [string, number, number][] };
export const SHOTS: Shot[] = [
  // कोल्ड-ओपन हुक: कहानी का सबसे भावुक पल 1.8 सेकंड (सिर्फ स्थानीय फ्रेम वाला सीन: VHook), तेज़ ज़ूम + boom
  { s: 0, e: 1.8, vec: 'VHook', move: 'in', sfx: [['boom', 0.0, 0.7], ['heartbeat', 0.2, 0.4]] },
  { s: 1.8, e: 6.0, vec: 'VLane', move: 'in', tr: 'dip', sfx: [['rev', -0.6, 0.35]] },
  { s: 6.0, e: 10.0, vec: 'VFind', move: 'still', tr: 'zoom', sfx: [['coin', 1.2, 0.35], ['steps', 0.2, 0.25]] },
  { s: 10.0, e: 14.0, vec: 'VReturn', move: 'panR', tr: 'flash', sfx: [['riser', -2.2, 0.35], ['boom', 0, 0.55], ['chime', 0.3, 0.3]] },
];

// कैप्शन: SRT के शब्द; {शब्द} = मुख्य शब्द (नारंगी)। \n की ज़रूरत नहीं (karaoke अपने आप 2-3 शब्द दिखाता है)
export type Cap = { s: number; e: number; t: string };
export const CAPS: Cap[] = [
  { s: 2.0, e: 5.6, t: 'एक छोटे से {गांव} में एक {गरीब} लड़का रहता था।' },
  { s: 6.4, e: 9.6, t: 'उसे रास्ते में एक {पर्स} मिला।' },
  { s: 10.4, e: 13.0, t: 'उसने उसे {लौटा} दिया।' },
];

/** पूरी वीडियो के SFX/एम्बिएंस: [फाइल, सेकंड, वॉल्यूम] (बारिश/हवा 20 s लंबी हैं) */
export const SFX: [string, number, number][] = [['wind', 0, 0.12]];
