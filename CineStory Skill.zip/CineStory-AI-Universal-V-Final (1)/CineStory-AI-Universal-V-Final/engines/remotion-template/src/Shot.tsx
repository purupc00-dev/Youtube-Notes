import React from 'react';
import { AbsoluteFill, Img, OffthreadVideo, interpolate, staticFile, useCurrentFrame } from 'remotion';
import { clamp, ease } from './theme';
import type { Shot as ShotT } from './data';
import { VEC } from './scenes';

// एक शॉट: फोटो/क्लिप + नरम (ease) कैमरा चाल + हल्का हैंडहेल्ड कंपन + ट्रांज़िशन
export const ShotView: React.FC<{ shot: ShotT; len: number; first: boolean; idx: number; dur: number }> = ({ shot, len, first, idx, dur }) => {
  const f = useCurrentFrame();
  const p = ease(Math.min(1, f / Math.max(1, len)));
  const [fx, fy] = shot.fx ?? [50, 50];
  let scale = 1.12, tx = 0, ty = 0;
  switch (shot.move) {
    case 'in': scale = 1.05 + 0.16 * p; break;
    case 'out': scale = 1.21 - 0.16 * p; break;
    case 'panL': scale = 1.18; tx = (0.5 - p) * 90; break;
    case 'panR': scale = 1.18; tx = (p - 0.5) * 90; break;
    case 'up': scale = 1.18; ty = (0.5 - p) * 90; break;
    case 'down': scale = 1.18; ty = (p - 0.5) * 90; break;
    case 'still': scale = 1.04 + 0.04 * p; break;
  }
  // हैंडहेल्ड: बहुत हल्का, धीमा कंपन (हर शॉट में अलग फेज़)
  tx += Math.sin(f / 23 + idx * 2) * 3.5;
  ty += Math.cos(f / 29 + idx * 3) * 3.5;
  const rot = Math.sin(f / 41 + idx) * 0.12;

  const tr = shot.tr ?? 'fade';
  const fade = first ? 1 : interpolate(f, [0, tr === 'dip' ? 12 : 9], [0, 1], clamp);
  if (!first && tr === 'zoom') scale *= 1 + 0.22 * (1 - ease(Math.min(1, f / 14)));          // अंदर से ज़ूम-आउट होकर आना
  const flash = !first && tr === 'flash' ? interpolate(f, [0, 3, 12], [0, 0.55, 0], clamp) : 0; // सुनहरी चमक
  const dip = !first && tr === 'dip' ? interpolate(f, [0, 10], [0.85, 0], clamp) : 0;          // काले से उभरना

  const style: React.CSSProperties = { width: '100%', height: '100%', objectFit: 'cover', transform: `translate(${tx}px, ${ty}px) rotate(${rot}deg) scale(${scale})`, transformOrigin: `${fx}% ${fy}%` };
  const Vec = shot.vec ? VEC[shot.vec] : null;
  const src = shot.file ? staticFile('media/' + shot.file) : '';
  const isVideo = !!shot.file && /\.(mp4|mov|webm)$/i.test(shot.file);
  return (
    <AbsoluteFill style={{ opacity: fade, overflow: 'hidden', background: '#000' }}>
      {Vec ? (
        <div style={{ position: 'absolute', inset: 0, transform: style.transform, transformOrigin: style.transformOrigin }}><Vec t0={shot.s} dur={dur} /></div>
      ) : isVideo ? <OffthreadVideo src={src} muted style={style} /> : <Img src={src} style={style} />}
      {flash > 0 && <AbsoluteFill style={{ background: '#FFD9A0', opacity: flash, mixBlendMode: 'screen' }} />}
      {dip > 0 && <AbsoluteFill style={{ background: '#000', opacity: dip }} />}
    </AbsoluteFill>
  );
};
