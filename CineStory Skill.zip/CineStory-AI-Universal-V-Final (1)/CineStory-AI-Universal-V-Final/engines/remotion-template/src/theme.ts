export const FPS = 30;
export const C = {
  gold: '#FFC857', white: '#FFF8EC', warm: '#FFB45A',
  cream: '#E6DDCB', beige: '#DDCFB7', ink: '#2B1D14', red: '#C8451E', card: '#F6EFE8',
  night: '#1C1917', navy: '#22284A', maroon: '#3B1B22', teal: '#2C483B', outline: '#2A1A12', tan: '#B9A07C',
};
export const T = (s: number) => Math.round(s * FPS);
export const dn = (n: number | string) => String(n).replace(/\d/g, (d) => '०१२३४५६७८९'[Number(d)]); // देवनागरी अंक
export const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
export const SPRING = { damping: 14, stiffness: 150, mass: 0.8 };
export const ease = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2); // नरम शुरू-अंत
