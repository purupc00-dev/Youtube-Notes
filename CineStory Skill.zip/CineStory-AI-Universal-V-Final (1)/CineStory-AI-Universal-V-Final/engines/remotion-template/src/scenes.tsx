import React from 'react';
import { C } from './theme';
import { Stage } from './chrome';
import { Person, Mini, Bubble } from './figures';
import * as K from './kit';
const { BOY, MOTHER, UNCLE, useT, sp, breathe, blinkAt } = K;
type SP = K.SP;
const O = K.O;

// ===== उदाहरण सीन (हिंदी कहानी: गरीब लड़का + पर्स)। हर नई वीडियो में अपनी कहानी के सीन लिखें, ये सिर्फ नमूने हैं =====
// डिज़ाइन-स्पेस 540x960। किरदार y≈115-720 के बीच रखें (नीचे 725-795 कैप्शन की जगह)।
// सीन = ({t0, dur}) => <Stage dur={dur}>…SVG…</Stage>; समय के लिए useT(t0): f = स्थानीय फ्रेम, t = पूरे वीडियो का सेकंड, lf(sec)

/** गाँव का बैकग्राउंड: mood = 'day' | 'dusk' | 'sad' (धुंधला/ठंडा) */
export const VillageBG: React.FC<{ f: number; mood?: 'day' | 'dusk' | 'sad' }> = ({ f, mood = 'day' }) => {
  const m = {
    day: { sky1: '#8EC5E8', sky2: '#F6E3B4', ground: '#C9A66B', hut: '#B88B5A', roof: '#7a5a34', sun: '#FFE08A', hill: '#9DB78A' },
    dusk: { sky1: '#E58A4B', sky2: '#FFD58A', ground: '#B98A57', hut: '#A9743F', roof: '#6b4527', sun: '#FFF1B8', hill: '#8a7a4a' },
    sad: { sky1: '#7C8794', sky2: '#C9C3B5', ground: '#A89677', hut: '#8d7656', roof: '#5f4a33', sun: '#E6E0CC', hill: '#7f8a78' },
  }[mood];
  return (
    <>
      <defs>
        <linearGradient id={`sky${mood}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.sky1} /><stop offset="1" stopColor={m.sky2} /></linearGradient>
        <radialGradient id={`sun${mood}`}><stop offset="0" stopColor={m.sun} stopOpacity="0.9" /><stop offset="1" stopColor={m.sun} stopOpacity="0" /></radialGradient>
      </defs>
      <rect width={540} height={960} fill={`url(#sky${mood})`} />
      <circle cx={400} cy={250} r={170} fill={`url(#sun${mood})`} opacity={0.8 + 0.1 * Math.sin(f / 18)} />
      <circle cx={400} cy={250} r={46} fill={m.sun} />
      {[0, 1, 2].map((i) => (
        <ellipse key={i} cx={((i * 230 + f * (0.25 + i * 0.1)) % 700) - 80} cy={150 + i * 55} rx={70 - i * 10} ry={16} fill="#fff" opacity={0.45} />
      ))}
      <path d="M0 520 Q120 440 250 500 T540 480 V620 H0Z" fill={m.hill} />
      {/* झोपड़ियाँ */}
      {[[40, 470, 1], [330, 480, 0.85]].map(([x, y, k], i) => (
        <g key={i} transform={`translate(${x},${y}) scale(${k})`}>
          <rect width={140} height={100} fill={m.hut} stroke={O} strokeWidth={3} />
          <path d="M-14 4 L70 -56 L154 4Z" fill={m.roof} stroke={O} strokeWidth={3} strokeLinejoin="round" />
          <rect x={52} y={36} width={36} height={64} fill="#4a3322" stroke={O} strokeWidth={3} />
        </g>
      ))}
      <rect y={600} width={540} height={360} fill={m.ground} />
      <path d="M0 640 Q270 600 540 650 V700 Q270 650 0 700Z" fill="#00000012" />
      {[60, 180, 300, 420].map((x, i) => <ellipse key={i} cx={x} cy={760 + (i % 2) * 40} rx={22} ry={6} fill="#00000014" />)}
    </>
  );
};

/** हुक (कोल्ड-ओपन): सिर्फ स्थानीय फ्रेम f का इस्तेमाल करें, ताकि किसी भी समय पर लगाया जा सके */
export const VHook: React.FC<SP> = ({ t0, dur }) => {
  const { f } = useT(t0);
  const tear = (f % 40) / 40;
  return (
    <Stage dur={dur}>
      <VillageBG f={f} mood="sad" />
      <rect width={540} height={960} fill="#1b100a" opacity={0.35} />
      <Person x={250} y={900} s={1.5} pose="stand" {...BOY} sad blink={blinkAt(f)} hand={[40, -120]} elbow={[10, -90]} />
      <circle cx={262 + 22} cy={470 + tear * 120} r={6} fill="#bfe3ff" opacity={1 - tear} />
      <g transform="translate(330,640)"><rect width={96} height={64} rx={10} fill="#5b3a22" stroke={O} strokeWidth={3} /><rect x={6} y={6} width={84} height={14} rx={4} fill="#d8c9a0" /></g>
    </Stage>
  );
};

export const VLane: React.FC<SP> = ({ t0, dur }) => {
  const { f } = useT(t0);
  return (
    <Stage dur={dur}>
      <VillageBG f={f} mood="day" />
      <Person x={270} y={560 + breathe(f)} s={0.72} pose="stand" {...BOY} sad blink={blinkAt(f)} />
      <Mini x={90} y={700} s={1.3} color="#B5543A" bob={breathe(f, 2, 9)} />
    </Stage>
  );
};

export const VFind: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const k = sp(lf(t0 + 0.8) + 0);
  const glint = 0.5 + 0.5 * Math.sin(f / 5);
  return (
    <Stage dur={dur}>
      <VillageBG f={f} mood="day" />
      <Person x={190} y={560 + breathe(f)} s={0.72} pose="stand" {...BOY} blink={blinkAt(f)} />
      <g transform="translate(300,690)">
        <rect width={96} height={58} rx={10} fill="#5b3a22" stroke={O} strokeWidth={3} />
        <rect x={6} y={6} width={84} height={12} rx={4} fill="#d8c9a0" />
        <g opacity={glint}><path d="M110 -10 l6 14 l14 6 l-14 6 l-6 14 l-6 -14 l-14 -6 l14 -6z" fill="#fff" /></g>
      </g>
      <Bubble x={190} y={270} text="!" w={56} delay={10} tail="l" />
    </Stage>
  );
};

export const VReturn: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <VillageBG f={f} mood="dusk" />
      <Person x={150} y={575 + breathe(f)} s={0.62} pose="stand" {...BOY} smile arm="raise" blink={blinkAt(f)} />
      <Person x={400} y={575 + breathe(f + 20)} s={0.7} pose="stand" flip {...UNCLE} smile blink={blinkAt(f + 40)} />
      <Bubble x={330} y={300} text="धन्यवाद!" w={140} delay={lf(t0 + 1.2) > 0 ? 8 : 8} tail="r" />
      {[0, 1, 2, 3, 4].map((i) => (
        <path key={i} d="M0 -10 l3 7 l7 3 l-7 3 l-3 7 l-3 -7 l-7 -3 l7 -3z" transform={`translate(${200 + i * 36},${420 - ((f + i * 9) % 60)})`} fill="#FFE08A" opacity={0.5 + 0.4 * Math.sin(f / 6 + i)} />
      ))}
    </Stage>
  );
};

// रजिस्ट्री: data.ts के SHOTS में vec: 'नाम'
export const VEC: Record<string, React.FC<SP>> = { VHook, VLane, VFind, VReturn };
