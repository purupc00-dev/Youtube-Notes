// ===== चैनल सेटिंग =====
export const PAGE_NAME: string = 'Inspired Tales AI'; // वॉटरमार्क ('' = नहीं; फोटो में पहले से जला हो तो '')
export const END_LINE: string = '';   // अंत की बड़ी लाइन, जैसे 'आप होते तो क्या करते?' ('' = नहीं)
export const HOOK: string = '';       // पहली 2.2 सेकंड की हुक लाइन ('' = नहीं)
export const HAS_VOICE: boolean = true;   // true = public/voice.mp3 है
export const HAS_MUSIC: boolean = false;  // true = public/music.mp3 है (अपना/रॉयल्टी-फ्री म्यूज़िक)
export const SHOW_CAPS: boolean = true;   // true = CAPS के कैप्शन दिखें
// कैप्शन स्टाइल: 'clean'   = सफेद + तेज़ काली ड्रॉप-शैडो, 2-3 शब्द, सिर्फ फेड-इन (प्रीमियम, शांत) [डिफ़ॉल्ट]
//               'karaoke' = शब्द-दर-शब्द पॉप, बोला शब्द पीला  |  'premium' = पूरा वाक्य, बड़ा सेरिफ
export const CAP_STYLE: 'clean' | 'karaoke' | 'premium' = 'clean';
// कैप्शन की ऊँचाई: नीचे से कितने px ऊपर। 880 ≈ स्क्रीन के बीच (रेफरेंस जैसा); 560 = थोड़ा नीचे (चेहरा न ढके)
export const CAP_BOTTOM = 880;      // AI फोटो/क्लिप वाले शॉट के लिए
export const CAP_BOTTOM_VEC = 330;  // कोड-सीन (vec) वाले शॉट के लिए (किरदार ऊपर 115-720 में रहते हैं)
// अपना फॉन्ट: public/fonts/ में फाइल रखें और नाम यहाँ लिखें (लाइसेंस आपकी ज़िम्मेदारी; Seramonde निजी-उपयोग-केवल है)
export const FONT_FILE: string | null = null;
