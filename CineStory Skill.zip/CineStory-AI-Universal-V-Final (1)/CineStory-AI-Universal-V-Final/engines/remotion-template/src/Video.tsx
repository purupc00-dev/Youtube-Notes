import React from 'react';
import { AbsoluteFill, Audio, Sequence, staticFile } from 'remotion';
import { T } from './theme';
import { SHOTS, SFX, TOTAL } from './data';
import { Overlay, useFonts } from './chrome';
import { HAS_VOICE, HAS_MUSIC } from './brand';
import { ShotView } from './Shot';

const sfx = (n: string) => staticFile('sfx/' + (n.includes('.') ? n : n + '.wav'));

export const Video: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{ background: '#000' }}>
      {SHOTS.map((sh, i) => {
        const last = i === SHOTS.length - 1;
        const len = (last ? T(TOTAL) - T(sh.s) : T(sh.e) - T(sh.s) + T(0.3)); // अगला शॉट आने तक नीचे रहे
        return (
          <Sequence key={i} from={T(sh.s)} durationInFrames={len}>
            <ShotView shot={sh} len={T(sh.e) - T(sh.s)} first={i === 0} idx={i} dur={len} />
          </Sequence>
        );
      })}
      <Overlay />
      {HAS_VOICE && <Audio src={staticFile('voice.mp3')} volume={1} />}
      {HAS_MUSIC && <Audio src={staticFile('music.mp3')} volume={HAS_VOICE ? 0.12 : 0.55} />}
      {!HAS_MUSIC && <Audio src={staticFile('sfx/pad.wav')} volume={HAS_VOICE ? 0.12 : 0.3} />}
      {/* ट्रांज़िशन के हिसाब से अपने-आप SFX (हर कट पर आवाज़) */}
      {SHOTS.slice(1).map((sh, i) => {
        const v = HAS_VOICE ? 0.55 : 1;
        const cues: [string, number, number][] =
          sh.tr === 'flash' ? [['boom', 0, 0.45 * v], ['sparkle', 0.05, 0.18 * v]] :
          sh.tr === 'dip' ? [['rev', -0.7, 0.28 * v], ['hit', 0, 0.2 * v]] :
          sh.tr === 'zoom' ? [['whoosh', -0.05, 0.22 * v], ['hit', 0.12, 0.14 * v]] :
          [['whoosh', -0.05, 0.13 * v]];
        return cues.map(([n, o, vol], j) => <Sequence key={`a${i}_${j}`} from={Math.max(0, T(sh.s + o))}><Audio src={sfx(n)} volume={vol} /></Sequence>);
      })}
      {/* हर शॉट में हाथ से लिखे SFX */}
      {SHOTS.map((sh, i) => (sh.sfx ?? []).map(([n, o, vol], j) => (
        <Sequence key={`b${i}_${j}`} from={Math.max(0, T(sh.s + o))}><Audio src={sfx(n)} volume={vol} /></Sequence>
      )))}
      {SFX.map(([n, s, v], i) => (
        <Sequence key={`x${i}`} from={T(s)}>
          <Audio src={sfx(n)} volume={v} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
