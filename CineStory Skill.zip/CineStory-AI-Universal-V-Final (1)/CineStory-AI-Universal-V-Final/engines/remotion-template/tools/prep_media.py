# उपयोग: python3 tools/prep_media.py <इनपुट_फोल्डर> public/media
# हर फोटो/क्लिप को 1080x1920 (9:16) में बदलता है। क्लिप: 30fps, बिना आवाज़, आख़िरी फ्रेम 8 सेकंड तक रुका हुआ।
import sys, os, subprocess, re
src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
VF = 'scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920'
for n in sorted(os.listdir(src)):
    p = os.path.join(src, n); base, ext = os.path.splitext(n); ext = ext.lower()
    if ext in ('.png', '.jpg', '.jpeg', '.webp'):
        subprocess.run(['ffmpeg','-v','error','-y','-i',p,'-vf',VF+',scale=1296:2304:flags=lanczos','-frames:v','1',os.path.join(dst,base+'.png')],check=True)
    elif ext in ('.mp4', '.mov', '.webm', '.mkv'):
        subprocess.run(['ffmpeg','-v','error','-y','-i',p,'-an','-vf',VF+',fps=30,tpad=stop_mode=clone:stop_duration=8','-t','10','-c:v','libx264','-crf','17','-pix_fmt','yuv420p',os.path.join(dst,base+'.mp4')],check=True)
    else: continue
    print('ok', n)
