# उपयोग: python3 tools/pauses.py public/voice.mp3 [subtitles.srt]
# आवाज़ की चुप्पियाँ (वाक्य की सीमाएँ) और SRT ब्लॉक एक साथ छापता है, ताकि सही टाइमिंग बने।
import sys, re, subprocess
mp3 = sys.argv[1]
r = subprocess.run(['ffmpeg','-i',mp3,'-af','silencedetect=noise=-35dB:d=0.12','-f','null','-'],capture_output=True,text=True).stderr
dur = re.search(r'Duration: (\d+):(\d+):([\d.]+)', r); d = int(dur[1])*3600+int(dur[2])*60+float(dur[3])
print(f'आवाज़ की लंबाई: {d:.2f}s  -> TOTAL = {d+1.5:.1f}')
st = re.findall(r'silence_start: ([\d.]+)', r); en = re.findall(r'silence_end: ([\d.]+) \| silence_duration: ([\d.]+)', r)
print('चुप्पियाँ (>=0.4s = वाक्य/कॉमा की सीमा):')
for (a,(b,l)) in zip(st,en):
    if float(l)>=0.4: print(f'  {float(a):.2f} -> {float(b):.2f}  ({float(l):.2f}s)')
if len(sys.argv)>2:
    print('\nSRT:'); print(open(sys.argv[2],encoding='utf-8-sig').read())
