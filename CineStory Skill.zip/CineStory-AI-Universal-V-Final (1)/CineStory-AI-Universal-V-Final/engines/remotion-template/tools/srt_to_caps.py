# उपयोग: python3 tools/srt_to_caps.py subtitles.srt  -> data.ts के लिए CAPS लाइनें छापता है
# (SRT का समय आधार है; ज़रूरत हो तो pauses.py की चुप्पियों से s/e ठीक करें और मुख्य शब्द {…} में डालें)
import re, sys
txt = open(sys.argv[1], encoding='utf-8-sig').read().replace('\r', '')
ts = lambda h, m, s, ms: int(h)*3600 + int(m)*60 + int(s) + int(ms)/1000
for blk in re.split(r'\n\s*\n', txt.strip()):
    L = blk.split('\n')
    m = re.search(r'(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)', blk)
    if not m: continue
    s, e = ts(*m.groups()[:4]), ts(*m.groups()[4:])
    body = ' '.join(l.strip() for l in L[L.index(next(x for x in L if '-->' in x))+1:]).replace("'", "\\'")
    print(f"  {{ s: {s:.2f}, e: {e:.2f}, t: '{body}' }},")
