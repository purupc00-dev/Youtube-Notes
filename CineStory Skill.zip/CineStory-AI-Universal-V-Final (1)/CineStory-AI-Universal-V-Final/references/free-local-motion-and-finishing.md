# Free-local motion and finishing

Use this reference after storyboard approval and before full rendering. The goal is to make still-based shorts feel intentionally edited without consuming image-to-video credits or promising body animation that the source frames cannot provide.

## Free-first decision

- Reuse approved scene images and local tools first. Prefer the retained Remotion composition for layered overlays when its dependencies are available; use FFmpeg for encoding, mixing, and simple camera moves.
- Check the actual renderer and current platform quota before proposing any generative image, speech, music, or video call. State the expected calls and any credit use; get explicit approval before paid services or a limited video-model call. Never hard-code a remembered daily credit limit.
- A local proof clip and code-driven effects do not require an AI video-model call. Music/TTS/image generation may still use platform credits, so do not describe the entire production as zero-credit unless that is true for the host.

## Per-scene motion plan

For each approved scene record: duration, camera move, focal point, any visible practical light source, optional ambient effect, transition, and caption-safe region. Choose effects from what is actually visible:

- Use a slow push, pull, lateral drift, or restrained tilt with eased starts/stops. Do not combine several competing camera moves in one still.
- The production default is now `scripts/animate_scenes.py`: when usable foreground/background plates exist it renders independent image planes with restrained parallax and subject-plane sway. In strict `--parallax on` mode, a missing layer blocks final production; in explicit `--parallax auto` mode only, the manifest marks the scene as camera/atmosphere-only.
- The renderer also adds a motivated, low-amplitude practical-light pulse, warm grade, vignette, fine grain and optional dust overlay. Inspect the shot so overlays do not cover faces, hands, captions or important props.
- If a lamp, candle, window, or other light source is visible, a small localized radial glow with a slow low-amplitude pulse can reinforce it. Anchor the glow to that source; keep it off faces, hands, captions, and unrelated areas. Use a light sweep only when it has a story or lighting motivation.
- Use sparse dust/rain only when it belongs in the setting. Keep it subtle and avoid making every scene look the same.
- Use parallax only when foreground/background layers or a suitable depth map exist and edge fill can be handled. Do not stretch or warp faces, hands, or props to simulate depth.
- A single still cannot provide natural new body action. Code can animate camera framing, light, overlays, and separately layered elements; real new character motion requires a different source or an explicitly approved video/rigging method.

The retained Remotion template is an optional reference scaffold, not the default scene renderer. The default animation engine is `scripts/animate_scenes.py`; final assembly, subtitle burn-in, audio mixing and encoding are performed by `scripts/render_video.py`. A camera-only fallback is explicitly labelled in `motion_manifest.json`; it is not reported as parallax. Do not infer true 3D or articulated body movement from a 2.5D image-plane effect.

## Internal motion proof

Before a full render, produce a 2–4 second local proof from an approved image. It should include the planned camera move, a motivated light/atmosphere accent if applicable, and the caption treatment. Inspect it internally after the storyboard has already been approved; do not add a separate technical approval gate. If the current environment cannot render the selected effect, remove that effect or explain the genuine blocker. Do not make an expensive model call for this proof.

## Captions and sound finish

- Align captions to the approved voice recording; use word timing when available. For Hindi, use a shaping-safe Devanagari font such as Noto Sans Devanagari or Mukta.
- At 1080×1920, begin around 36–42 px, normally one or two lines, with a strong but not oversized outline/shadow. Position in the lower safe area and keep clear of faces/hands and platform controls. These are starting values, not a rigid rule; verify a full-resolution frame.
- Use explicit subtitle alignment/positioning where the format supports it. Inspect real rendered frames for clipping, line wraps, timing, and face overlap; automated analysis is not a substitute for this check. Keep a separate timed SRT when practical.
- Keep narration intelligible and forward. Generate an original AI warm-emotional music bed and story-specific AI SFX automatically when the configured provider is available; otherwise use the bundled original procedural fallback assets. Keep effects below the voice and place them only at motivated events. Listen to the final mix and verify there is no clipping. Use no-music/no-SFX only when requested.

## Final QA and delivery

Inspect a time-spread contact sheet plus at least one full-resolution captioned frame. Verify that the approved motion/effects are visible, captions do not cover the subject, scene order and duration match the narration, and audio and export streams are correct. State what was actually applied (for example, “slow push-in + localized candle-glow pulse”) and any limitation (for example, “still-image movement; no natural body animation”).
