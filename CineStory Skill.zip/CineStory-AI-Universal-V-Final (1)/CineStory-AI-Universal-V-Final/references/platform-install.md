# Install the portable skill in different AI tools

The portable unit is this folder: `cine-story-ai/`. Keep `SKILL.md` at its root and retain the scripts/references folders beside it.

## Claude Code

Copy the folder into a project or user skills directory, for example:

```text
.claude/skills/cine-story-ai/SKILL.md
.claude/skills/cine-story-ai/scripts/...
```

For a personal skill, use the Claude Code user skills directory supported by the installed version. Restart/reload the session if the skill is not discovered. Claude product features and skill discovery can change; consult current Anthropic documentation.

## OpenAI Codex

Place the folder under the repository's `.agents/skills/` directory:

```text
.agents/skills/cine-story-ai/SKILL.md
.agents/skills/cine-story-ai/scripts/...
```

Codex may also support user-level skills depending on version. Keep scripts in the same folder so relative paths resolve. Consult current Codex documentation for user-level locations and approval behavior.

## ChatGPT

If the user's ChatGPT environment supports custom skills or uploaded skill bundles, upload/import this folder or its ZIP there. Otherwise upload `SKILL.md` plus the relevant references to the conversation or paste the workflow into project instructions. A normal chat cannot automatically execute local Python/FFmpeg scripts on the user's PC; use a connected execution environment, ChatGPT Work where supported, or run the scripts locally.

## Grok

If the current Grok product/account supports custom agents, knowledge files or workflow instructions, create a custom agent and attach `SKILL.md` and the references. If it does not support executable skill folders, paste the skill instructions and use its file/code execution capabilities where available. The local scripts still run separately on the user's computer.

## Important portability limits

- `SKILL.md` is a common emerging format, not a guarantee that every AI product supports one-click installation.
- Tool names, file access, terminal access, API connections, custom agent features and upload limits differ by product and change over time.
- Do not expose API keys in skill text, prompts, screenshots or shared project files. Use environment variables or the provider's secret manager.
- A skill provides instructions and scripts; it does not grant image/video generation entitlements or provider API access.

## Interactive approval flow

After installing, start with a message such as: `Create a 35-second Hindi emotional story about a poor boy and his mother.` The skill should show 3 concepts first and wait. After selection it shows 3 scripts and waits, then offers voice auditions or the user's own recording, character/style approval, and a scene storyboard for review. The user approves or requests scene-specific regeneration before final assembly. The default look remains Warm Cinematic 3D.
