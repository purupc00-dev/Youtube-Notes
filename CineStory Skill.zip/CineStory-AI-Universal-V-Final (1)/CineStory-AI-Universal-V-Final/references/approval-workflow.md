# CineStory interactive approval workflow

This is a mostly automatic production pipeline with a small number of creative decision gates. The user should not perform file handling, run commands, find music/SFX, add captions, or manually assemble a video. After the approved storyboard, the agent completes all technical production steps without additional interruptions.

## Creative approval gates

1. **Concept:** in idea mode, show exactly three distinct story concepts and wait for 1/2/3. In script mode, skip this gate.
2. **Script:** show exactly three complete script treatments and wait for A/B/C.
3. **Voice:** create a short audition with the available host TTS; the user may approve it, choose another audition, or provide their own recording. If the host cannot create audio, clearly disclose the missing TTS capability and offer the supported alternative.
4. **Characters and visual style:** show the character bible and the visual presets. Warm Cinematic 3D is the default. User may approve, edit, or choose another style.
5. **Storyboard:** generate all approved scene stills automatically, show the contact sheet and individual images, then wait for approve-all or specific changes.

After gate 5, do not ask for more technical approval. Automatically animate each scene, verify every scene clip and the motion review, then create the soundtrack and SFX, style subtitles, render, inspect and deliver. Do not start billable audio-generation calls until motion clips and the motion review pass preflight. If a genuine failure or missing credential prevents production, explain the exact blocker instead of pretending it is complete.

## Default visual identity

Warm amber/golden practical light, soft rim light, earthy browns/ochre/muted teal, emotionally expressive original stylized-realistic characters, believable proportions and hands, shallow depth of field, lived-in environments, atmospheric dust where appropriate, subtle grain and vertical 9:16 framing. Do not copy protected character designs, studio trademarks or logos.

## Stage details

### 1. Concept choices

For idea mode, give three genuinely different concepts, each with title, premise, hook, central character, emotional turn, payoff and target runtime. Do not generate assets yet.

### 2. Script choices

Provide three full treatments: heartfelt/simple, cinematic/suspenseful, and fast social hook. Target 30–40 seconds unless requested otherwise. Preserve supplied script facts and ending.

### 3. Voice

Use host-native or already-connected TTS to create a playable audition. Offer up to three distinct voices if available. Allow an uploaded audio file. Do not call a paid voice API unless the user has configured and approved it. If no TTS is available, say so; do not imply a universal voice provider exists.

### 4. Character and style

Lock face, age, hair, clothing, body shape, accessories and props for each character. Offer: Warm Cinematic 3D (default), Moody Cinematic 3D, Golden Fairytale 3D, Soft Storybook 3D, or a custom reference. The complete style and character descriptions must be repeated in each relevant image prompt.

### 5. Scene stills and storyboard

Create 6–10 scenes for a 30–40 second short. Include timecodes, exact narration chunk, shot, action, expression, location, lighting, image prompt, negative prompt, motion plan, SFX cue and subtitle chunk. Generate the character reference (if planned) and all scene stills automatically through the user's Cloudflare Worker. Reuse existing images. After image generation, create a storyboard contact sheet and provide full-resolution images. This is the last required creative approval gate.

### 6. Automatic 2.5D cinematic motion

After storyboard approval, use `scripts/prepare_parallax_layers.py` and `scripts/animate_scenes.py` to segment the subject into a foreground layer, inpaint the clean background and render one moving MP4 clip per scene. The subject and background receive different easing/transform values, the extracted subject gets a subtle whole-layer sway/settle, and the background receives a restrained focus simulation. Add motivated candle/lamp glow and flicker, floating dust, warm grading, vignette and fine grain. This is 2.5D image-plane motion, not articulated body animation. Do not distort faces, hands or props. The default strict `--parallax on` mode stops the production before billable audio generation if any required scene cannot be segmented. Camera-only fallback is allowed only when the user has explicitly selected `--parallax auto`; every affected scene must be labelled in the motion manifest and production report.

### 7. Automatic AI music and SFX

Use `scripts/generate_audio_assets.py` with `ELEVENLABS_API_KEY` configured. The default score uses Music v2.5 and is composed from the story's emotional arc. Scene SFX are generated through Sound Effects v3 from the actual actions, props and environment, with up to 16 cues by default, prioritizing one cue for each scene before adding secondary accents. The final mixer trims effects to their cue windows, places them against scene timestamps, keeps them under the voice and automatically ducks music during narration. Do not make duplicate generation calls after ambiguous timeouts; generation requests are not automatically retried.

If the key is missing or the provider is unavailable, automatically use the bundled CineStory Original Audio Fallback Library. These fallback assets are original procedural audio, not third-party stock recordings and not equal in realism to AI-generated audio. The manifest must identify AI vs fallback sources. The user does not search for or manually place tracks.

### 7a. One-time audio provider setup

Store an ElevenLabs API key once as `ELEVENLABS_API_KEY` in the project `.env` or the agent host's secret store. Music API access is limited to eligible paid subscribers; SFX availability/usage depends on the account plan and quota. If provider failure occurs, use the library fallback without asking the user to manually source assets. Never purchase credits or upgrade the plan without explicit approval.

### 8. Automatic subtitles

Default is **CineStory Warm Captions**: bold white text, dark outline/soft shadow, selective amber emphasis on meaningful words, two-line maximum and safe lower-third placement. Convert SRT to ASS with `scripts/generate_styled_subtitles.py`. For Hindi use a Devanagari-capable font (Noto Sans Devanagari, Mukta, or system fallback). Other options: clean white, minimal, or no subtitles. Default automatically; only ask if the user explicitly wants to customize it.

### 9. Render and QA

Render 1080×1920, 24fps, H.264/AAC. Mix narration as foreground, music low underneath, and SFX at scene-specific timestamps. Inspect duration, scene order, captions, audio balance, black frames, crop, image identity and codecs. Re-render automatically if a correctable defect is found. Deliver final MP4, cover, storyboard, script, audio assets and a short report.

## Interaction rule

Ask one clear question at each of the five creative gates. Do not ask the user to approve every image individually unless requested, and do not ask for technical confirmation after storyboard approval. Persist decisions in `workflow.json` and resume from the next missing creative decision.
