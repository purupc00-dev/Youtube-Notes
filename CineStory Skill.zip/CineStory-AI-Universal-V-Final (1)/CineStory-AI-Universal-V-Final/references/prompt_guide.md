# Prompt guide (Phase A) – for the user's own AI image/video tool

Goal (used only when the user asks for prompts): every scene looks like the same cinematic 3D story. Reproduce the *style*, not any other channel's characters.

## 1. Style block (paste at the end of EVERY image prompt)
"cinematic 3D animated film still, Pixar-like realistic stylized characters, warm golden-hour sunlight with soft rim light and volumetric dust, shallow depth of field, rich earthy colors (browns, ochre, muted teal), detailed Indian village environment, emotional storytelling, 9:16 vertical, ultra detailed, no text, no watermark, no logo"

## 2. Character sheet (write once at the top of scene_plan.md, then copy into every prompt that has the character)
Give each recurring character ONE fixed line: age, face, hair, clothes (colour + fabric), body build. Example format (invent your own, do not reuse another page's characters):
- `<NAME>`: 7-year-old Indian boy, round face, big dark eyes, short messy black-brown hair, faded sky-blue kurta with frayed hem, brown shorts, barefoot.
- `<NAME>`: young mother, tired kind face, small bindi, olive-green saree, hair in a bun.
Keep names/ages/clothes identical in all scenes. If the tool supports a reference image, say "use the first image as the character reference".

## 2b. Hook shot (scene_00)
Extreme close-up of the story's climax (tearful face, trembling hands holding the key object), shallow depth of field, strong rim light, same character lines + style block. Motion prompt: "tear rolls down, slow push-in, heartbeat feel". Also list 2 alternative HOOK lines (≤ 6 words, taken from the user's own story).

## 3. Shot variety (assign one per scene, alternate)
Wide establishing (house, lane, village) → medium two-shot (two people, eye level) → close-up of face (emotion) → extreme close-up of a key object/hands (purse, food, coin) → over-the-shoulder → low-angle hero shot. Climax = close-up; ending = warm wide or glowing close-up.

## 4. Light = emotion
Sad/poor: dim, dusty, low-key, cool window light. Hope/kindness: golden backlight. Resolution: glowing warm light on faces/food.

## 5. Motion prompt (for image-to-video, 3-5 s, one simple action)
Format: "<one action>, <camera move>, subtle natural motion". Examples: "boy slowly bends down and picks up the purse, slow push-in", "old man smiles and hands over the bag, gentle handheld, dust floating in light". Keep one action per clip; no fast cuts, no text.

## 6. scene_plan.md layout (per scene)
```
### scene_03  (8.4s – 12.6s)
Narration: <exact SRT line(s)>
Shot: close-up, move: in
Image prompt: <what we see> + <character lines> + <style block>
Motion prompt: <one action, camera move>
File name: scene_03.png (or scene_03.mp4)
```
Scenes follow the story's beats (place/time/speaker/idea change); 3-5 s each; show what the sentence says (object, action, emotion), not just a talking face.
