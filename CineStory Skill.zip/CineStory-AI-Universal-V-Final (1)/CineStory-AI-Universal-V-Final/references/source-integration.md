# Source integration notes

## What the supplied Faceless Shorts package does

The uploaded `faceless-shorts-skill.zip` is a code-rendered video production system, not an image-to-video AI wrapper.

Its documented pipeline is:
1. The agent writes a `script.json` with one narration line per visual cut.
2. Kokoro-82M runs locally through `kokoro-onnx` to produce narration audio.
3. `words.py` uses local faster-whisper to produce word timing data.
4. A style-specific Three.js scene (`src/shots.js`, `src/core/*`) draws and animates the visuals.
5. Headless Chrome captures rendered frames.
6. `tools/mix.py` combines voice, generated cues, procedural sound and music.
7. FFmpeg assembles the MP4.
8. The agent inspects a contact sheet and key frames before delivery.

The six supplied styles are Deep Dive 3D, Night File 3D, Inside Out, Stick Story, Paper Atlas and Tall Tale 3D. The package's own SKILL.md explicitly says not to generate images or video with AI. Preserve that boundary when running the original engine.

## Why its code-made visuals can still feel polished

The styles are not generic blank slides. Each has a visual bible, palette, reusable character/prop components, lighting rules, shot grammar, and a complete example project. The 3D examples use Three.js geometry, poses, lights and camera paths, with filmic tone mapping, shadows, depth of field, bloom, vignette and grain. The 2D styles use deliberately constrained shapes, silhouettes, maps, labels and transitions. Each shot is timed to narration words, and captions, sound cues and scene changes land on planned beats. A contact sheet and full-size key-frame review catch collisions or story mismatches before export.

The visual quality comes from authored scene design, consistent limits, motion curves, lighting/post-processing, pacing, voice/caption timing and QA. It is a designed procedural look rather than an image model's detailed organic realism. Its 3D styles can take significant time to render without hardware acceleration; check the local machine's GPU/Chrome support and self-test before promising a quick export.

## How CineStory combines it with cinematic AI stills

The requested reference look is a different visual target: cinematic, realistic/stylized 3D character stills with detailed faces, lighting and environments. Reproducing that look with Three.js primitives alone would require building a different renderer and would not automatically match an image model's realism.

Therefore CineStory keeps two distinct engines:
- **Cinematic image engine:** generated still images + optional generative video + FFmpeg/Remotion composition.
- **Faceless Shorts engine:** original procedural 2D/3D scenes + local voice/timing + FFmpeg.

Route to Faceless Shorts when the user explicitly prioritizes no image/video-model calls or no API spending. Route to the cinematic engine when realistic detailed stills are central and the user has an available, approved image source. A local open-weight image model may avoid per-image API cost, but it still needs suitable hardware, disk space and time; never imply that it runs automatically or at zero resource cost.

The engines can be combined in a hybrid edit, but their style rules should not be mixed accidentally. For example, do not put procedural flat cartoon characters into a photoreal cinematic scene unless the user deliberately chooses a mixed-media look.

## Reused Remotion template

The earlier Cine Story Video Builder template is retained under `engines/remotion-template/` for advanced shot composition, overlays, camera moves, captions, sound cues and final rendering. Read its package.json and source files before making changes; do not assume its dependencies are installed.
