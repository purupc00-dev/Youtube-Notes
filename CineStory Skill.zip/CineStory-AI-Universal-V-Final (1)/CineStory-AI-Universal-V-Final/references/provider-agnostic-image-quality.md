# Provider-agnostic cinematic image quality

A strong image comes from the image model, its usable reference/editing features, and a well-directed prompt. A text model can plan the visual and write the prompt, but it does not create a photographic illustration unless an image-generation tool is connected.

Anthropic says Claude does not natively generate photos or illustrations; it can create diagrams, charts, and interactive visuals with HTML/SVG, and analyze uploaded images. If a Claude workflow returns a realistic still, identify the connected image tool rather than attributing it to Claude's text model. Seedream 5.5 emphasizes multi-turn edits that preserve untouched regions, transparent RGBA output, and fine texture/lighting. OpenAI documents image generation and editing, including multi-turn use through its Responses API. These are capability examples, not a ranking: access, quality settings, and cost depend on the current app/account. FLUX.1-schnell is an open-weight local option under Apache 2.0; it is a 12B-parameter model, so check hardware, disk space, and realistic render time before choosing it. Local inference avoids per-image API charges but still uses the user's compute and time.

Official references: [Seedream 5.5](https://seed.bytedance.com/en/seedream5_5), [Claude image capability](https://support.claude.com/en/articles/9002504-can-claude-produce-images), [OpenAI image generation guide](https://developers.openai.com/api/docs/guides/image-generation), [FLUX.1-schnell model card](https://huggingface.co/black-forest-labs/FLUX.1-schnell), and [Black Forest Labs' inference repository](https://github.com/black-forest-labs/flux).

## Google Gemini image API: a key is not a free quota

As checked on 2026-11-23, Google's official Gemini API pricing page lists **no free API tier** for the documented Nano Banana image models. The listed 1K output price is approximately **$0.0336/image** for Nano Banana 2 Lite and Nano Banana 2.1; the larger Nano Banana 2.1 options are listed at approximately $0.0504 for 2K and $0.113 for 4K. Prices and model availability can change, so re-check the current official pricing page immediately before enabling a provider. Google's rate-limit page says quotas vary by model, project, and tier; a key does not itself grant free usage.

Google AI Studio's UI and the Gemini Developer API are different access paths. A model being available to try in the Studio interface does not establish a reusable, free API quota for an automated skill. For a cross-platform skill that makes repeatable calls, treat Gemini API image generation as billable unless the current official pricing page explicitly says otherwise for that exact model and account. The documented free-tier data-use terms also differ from paid-tier terms; check them before sending private reference images.

This CineStory package does **not** ship a Google API adapter or call Gemini automatically. Its existing OpenAI Images script is optional and separately guarded as billable. A future provider adapter must use a user-approved provider/model, show a preflight count, cap the number of outputs, and read its key from an environment variable such as `GEMINI_API_KEY`; never commit a `.env`, key, or credential to the skill or its ZIP.

Official Google sources: [Nano Banana image generation](https://aistudio.google.com/docs/image-generation), [Gemini API pricing](https://aistudio.google.com/docs/pricing), [Gemini API rate limits](https://aistudio.google.com/docs/rate-limits), and [API-key guide](https://aistudio.google.com/docs/api-key).

## Build quality without locking the skill to one model

First write a short visual bible: character age and identity, face/hair/outfit anchors, palette, materials, lighting, environment, and camera language. Generate and inspect one character anchor image. Reuse that image as a reference wherever the active model supports references or edits. Do not rely on names like “cinematic 3D” alone; restate concrete visual traits in every scene prompt.

For each scene, give the model one clear action and one composition. State the vertical aspect ratio, shot size and angle, subject placement, visible expression, background depth, key/fill/rim light, material texture, and the exact elements to preserve from the character reference. Leave a clean lower area for captions. Prohibit baked-in words, subtitles, logos, watermarks, extra people, duplicate limbs, and unintended costume/age changes.

Use targeted editing to repair a specific defect while preserving everything else. Do not regenerate an approved scene set just because one image needs a hand, prop, framing, or lighting correction. Make a time-stamped contact sheet and reject frames that contradict the story or drift from the approved character/style.

## Model and budget routing

Check which image tools are genuinely available in the current host; do not assume Claude, a chat model, or an API key includes image generation. Prefer the user's already-included image tool only when its current quota is adequate and the user has approved using it. If no suitable included tool exists, offer a local open-weight model only after checking hardware, or ask the user to provide/generate the image elsewhere. Never silently switch to a paid API or consume a limited quota. If the user's priority is no image/video-model calls, use the separate code-rendered Faceless Shorts engine instead of promising photoreal AI stills for free.

If the user asks to compare models, use the same character reference and one representative scene prompt for each candidate. Tell them which calls may use credits first, and do not make more comparison generations than they approve. Judge outputs on story accuracy, character identity, anatomy, framing, lighting, texture, and whether a small edit can fix defects. Do not promise a free model will match Seedream 5.5; validate one sample before scaling to all scenes.

A reusable prompt shape is:

> Create one vertical 9:16 cinematic story still. Match the approved character reference exactly: [identity, face, hair, age, outfit, colors]. Show [one visible action and emotion]. Frame as [shot size, angle, subject placement, focal point], with [foreground/midground/background]. Light with [motivated source, direction, softness, warm/cool balance]; render [materials, texture, depth of field, restrained film finish]. Preserve [continuity anchors]. Keep [caption-safe area] uncluttered. No text, subtitles, logos, watermark, extra characters, duplicate limbs, or changes to the approved identity.
