# Viral Shorts playbook (apply in every video; no result is guaranteed)

## 1. Hook = first 2 seconds
- **Cold open:** shot 1 (1.5-2 s) = the story's most emotional/shocking moment (tightest close-up of the climax, reuse the climax file), with `boom` + `heartbeat` and a `HOOK` line on screen. At ~1.8 s cut with `dip` + `rev` to the real beginning. The viewer now wants to know how we got there.
- **HOOK line formulas (Hindi, ≤ 6 words, from the user's own story; do not invent facts):** question ("क्या उसने सही किया?"), shock ("उसने पर्स लौटा दिया…"), cliffhanger ("आगे जो हुआ…"), challenge ("आप होते तो?"). Offer 2 alternatives to the user in the final message.
- Voice mode: the voice must start within 0.2 s (trim leading silence); first caption word appears at once. Never open with a logo, title card, black or a wide empty landscape.

## 2. Pacing / pattern interrupt
New shot or camera move/transition every 2.5-4 s; never > 5 s. Alternate wide → medium → close-up → detail. Use a different transition (`zoom`/`dip`/`flash`) at beats, `fade` in between. Slow push-in on emotion, pull-out for reveal. Cut on the voice pause or on the caption change.

## 3. Story shape (user's story; you only arrange the shots)
Problem (0-8 s) → escalation (8-25 s) → turning point (kindness/choice) → payoff (warm glowing frame) → last shot echoes the first frame (loop feel). Climax shot = tightest close-up + `riser` before + `boom`/`chime` on the cut.

## 4. Captions (voice mode)
Default `clean`: white text, sharp black drop-shadow, 2-3 words at a time, soft fade-in, no pop/colour change (premium and calm; matches the user's reference). `CAP_BOTTOM` 880 = middle; lower to 560 if a face is hidden. Captions must not overlap in time; one idea per caption. `karaoke` (word pop, yellow) and `premium` (serif sentence) only if the user asks.

## 5. SFX layer (heavy, but under the voice)
Automatic per cut (see `Video.tsx`): fade → soft whoosh; zoom → whoosh + hit; dip → rev + hit; flash → boom + sparkle. Add by hand per shot in `sfx`:
| Moment | SFX |
|---|---|
| Hook / shocking reveal | `boom`, `heartbeat` |
| Sadness, hunger, fear | `heartbeat`, `wind`, `drone`, `rain` (ambience in global `SFX`, volume ≈ 0.1-0.15) |
| Before the climax | `riser` (starts ~2.2 s before the cut: offset −2.2) |
| Object moments (purse, coin, food, door) | `coin`, `click`, `hit`, `steps` |
| Kindness / hope / happy ending | `chime`, `sparkle` |
| Time jump / flashback | `rev` + `dip` |
Mix: voice 1.0; SFX 0.15-0.5; ambience 0.1; pad/music 0.12 (voice mode) or 0.3-0.55 (no voice). Max 2 loud hits in a row; leave air around the climax. User's own SFX/music: put in `public/sfx/` and use the full file name (e.g. `['door.mp3',1.2,0.4]`); they must have the right to use them.

## 6. End
Warm payoff frame, then a short `END_LINE` that invites a comment (e.g. "आप होते तो क्या करते?") — optional, ask the user. Fade to black 0.5 s.

## 7. Packaging advice (say briefly when asked)
Title = emotion + curiosity (no false claims); first-frame = best close-up; post consistently; compare videos by *Viewed vs swiped away* and average view duration; change one thing at a time (voice vs no voice, hook A vs B).
