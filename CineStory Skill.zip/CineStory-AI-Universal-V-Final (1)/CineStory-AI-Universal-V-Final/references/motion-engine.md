# CineStory 2.5D Motion Engine

## Pipeline

1. Read each approved scene image.
2. Segment the main foreground subject with U2Net through `rembg[cpu]`.
3. Dilate the matte to avoid edge halos and inpaint the removed subject region in the original image with OpenCV Telea, producing a clean background plate.
4. Save `scene_id_foreground.png` (transparent subject) and `scene_id_background.jpg` (clean background) under `PROJECT/assets/layers/`.
5. Render the two image planes with separate eased camera transforms. The subject plane gets a restrained independent sway/settle offset; the background receives a very soft blur simulation. Both are combined with a warm grade, optional practical-light glow/flicker, dust, vignette and fine grain. The segmentation coverage guard defaults to 1.5%–92% so ordinary close-ups are not rejected simply because the subject occupies more than half of the frame; ambiguous masks still fail the strict gate.

## What this is and is not

This is 2.5D image-plane compositing. It gives the viewer depth through relative foreground/background motion. The subject-plane sway moves the extracted subject as one layer. It does not create articulated limbs, natural walking, facial expression, blinking or true 3D geometry. Do not deform faces, hands or important props to simulate those actions.

## Failure policy

The default `--parallax on` mode is strict: if the mask is missing/ambiguous or the runtime cannot be installed, stop before billable audio generation and final export. Do not silently downgrade. Camera-only movement is available only when the user explicitly opts into `--parallax auto`; each downgraded scene must be labelled in `motion_manifest.json` and `production-report.json`. Never state that a scene used parallax unless both layer files were present and composited.

## One-time setup

`scripts/setup_motion.py` installs `rembg[cpu]`, OpenCV and Pillow and initializes the U2Net model. The host needs Python and network access for first-time package/model download. Existing layer plates can be rerendered without downloading U2Net again.
