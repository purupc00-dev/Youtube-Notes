# Image-to-video provider adapter contract

There is no single standard image-to-video API shared by all vendors. Kling, Runway, Luma, Veo and other providers can differ in authentication, request schema, image upload method, polling, duration limits, aspect-ratio handling and model access. Check the provider's official current API documentation before implementing an adapter.

The skill expects a tiny Python module exposing:

```python
def generate(image_path: str, prompt: str, output_path: str,
             duration: float, aspect_ratio: str) -> None:
    """Generate a video and write it to output_path, or raise a useful error."""
```

Use `adapters/video_adapter_example.py` as a stub. Implement the provider's documented flow inside the function:
1. Read its API key from an environment variable, never from a checked-in file.
2. Upload the source image if required.
3. Submit the motion prompt, duration and aspect ratio using documented fields.
4. Poll the job until complete, respecting provider rate limits.
5. Download the resulting video to `output_path`.
6. Validate that the output exists and is a playable video.

Run:

```bash
python scripts/animate_scenes.py project/story_plan.json \
  --images project/assets/images \
  --out project/assets/video \
  --adapter adapters/my_provider_adapter.py
```

A local CLI can also be used with a command template. Example only, if the installed CLI supports these arguments:

```bash
export CINESTORY_VIDEO_COMMAND='my-video-cli --input {image} --prompt-file {prompt_file} --duration {duration} --output {output}'
```

The command is split into arguments and placeholders are substituted. Do not use shell metacharacters or rely on shell expansion. If a provider requires a different schema, write a Python adapter instead.
