# Voice auditions and narration generation

CineStory can create voice auditions and final narration with the user's configured ElevenLabs API key. It lists available voices using `GET /v2/voices`.

## Model and endpoint pairing

- Default high-expression model: `eleven_v4` through `POST /v1/text-to-dialogue`, with one `inputs` entry containing the narration text and selected `voice_id`. This is the documented v4 route. Keep each v4/v3 request at or below 2,000 total input characters.
- Compatibility fallback: `eleven_multilingual_v2` through `POST /v1/text-to-speech/{voice_id}`. It supports Hindi and is suitable for longer single-speaker narration.
- Do not call `eleven_v4` on the classic `/text-to-speech/{voice_id}` endpoint.

Official docs: [Text to Dialogue](https://elevenlabs.io/docs/api-reference/text-to-dialogue/convert), [Create speech](https://elevenlabs.io/docs/api-reference/text-to-speech/convert), [models](https://elevenlabs.io/docs/overview/models/), [voice list](https://elevenlabs.io/docs/api-reference/voices/search).

## Interactive voice stage

1. Run `python scripts/voice_generation.py list --project PROJECT --language hi --out audio/voice-catalog.json`.
2. Inspect available voice metadata. Select up to three suitable Hindi narrator voices; never invent a voice ID.
3. Run `python scripts/voice_generation.py audition PROJECT/story_plan.json --voice-ids ID1 ID2 ID3 --out audio/auditions --language hi`.
4. Present the playable auditions and wait for the user's choice.
5. Run `python scripts/voice_generation.py synthesize PROJECT/story_plan.json --voice-id SELECTED_ID --out audio/voice-final.mp3`.
6. Verify that the file exists and FFmpeg can decode it.

Audition and synthesis are billable requests; they are not replayed after uncertain timeouts. Do not regenerate automatically following an ambiguous timeout. The `ELEVENLABS_ZERO_RETENTION=1` option adds `enable_logging=false`, but ElevenLabs documents zero-retention mode as Enterprise-only. Leave it unset on ordinary plans. This package omits the parameter by default.

If the API key is missing or the account cannot access the selected model, use a connected host-native TTS tool or accept the user's audio. If neither exists, offer captions-only and pass `--captions-only` to the production orchestrator. Do not claim voice generation unless a decodable audio file exists.
