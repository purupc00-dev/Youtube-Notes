"""Example adapter contract. Replace with a provider's documented API/CLI integration.

Required function:
    generate(image_path: str, prompt: str, output_path: str,
             duration: float, aspect_ratio: str) -> None

The function must write a playable video file to output_path or raise an exception.
Do not hard-code API keys; read them from environment variables or a secret manager.
"""
def generate(image_path, prompt, output_path, duration, aspect_ratio):
    raise RuntimeError(
        'No video provider is configured. Implement this adapter using your provider\'s '
        'current official API, or use CINESTORY_VIDEO_COMMAND. See references/provider-adapters.md.'
    )
