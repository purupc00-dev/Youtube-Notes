"""Comprehensive unit & integration tests for CineStory AI v10 upgrades (zero paid API calls)."""
import base64
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import align_narration as align
import animate_scenes as anim
import generate_audio_assets as audio
import generate_styled_subtitles as subs
import prepare_parallax_layers as parallax
import verify_qa as qa
import voice_generation as voice


class V10VoiceAndAlignmentTests(unittest.TestCase):
    def test_elevenlabs_dialogue_with_timestamps_builds_devanagari_words(self):
        text = "भूखा कबीर किताब पढ़ता था।"
        chars = list(text)
        starts = [round(i * 0.08, 3) for i in range(len(chars))]
        ends = [round((i + 1) * 0.08, 3) for i in range(len(chars))]
        fake_payload = {
            "audio_base64": base64.b64encode(b"ID3fake-mp3-bytes").decode("ascii"),
            "alignment": {
                "characters": chars,
                "character_start_times_seconds": starts,
                "character_end_times_seconds": ends,
            },
        }
        captured = {}

        def fake_post(url, key, body, timeout=180):
            captured["url"] = url
            captured["body"] = body
            return fake_payload

        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "voice-final.mp3"
            with patch.object(voice, "request_audio_with_timestamps", side_effect=fake_post):
                res = voice.synthesize(text, "voice-abc", "k", out, model="eleven_v4", with_timestamps=True)
            self.assertIn("/text-to-dialogue/with-timestamps?", captured["url"])
            self.assertEqual(res["alignment_words_count"], 5)
            raw_align = Path(res["alignment_file"])
            self.assertTrue(raw_align.is_file())
            doc = json.loads(raw_align.read_text(encoding="utf-8"))
            self.assertEqual([w["word"] for w in doc["words"]], ["भूखा", "कबीर", "किताब", "पढ़ता", "था।"])

    def test_elevenlabs_multilingual_v2_with_timestamps_endpoint(self):
        fake_payload = {
            "audio_base64": base64.b64encode(b"ID3fake").decode("ascii"),
            "alignment": {
                "characters": list("कबीर"),
                "character_start_times_seconds": [0.0, 0.1, 0.2, 0.3],
                "character_end_times_seconds": [0.1, 0.2, 0.3, 0.4],
            },
        }
        captured = {}

        def fake_post(url, key, body, timeout=180):
            captured["url"] = url
            return fake_payload

        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "v.mp3"
            with patch.object(voice, "request_audio_with_timestamps", side_effect=fake_post):
                res = voice.synthesize("कबीर", "vid-99", "k", out, model="eleven_multilingual_v2", with_timestamps=True)
            self.assertIn("/text-to-speech/vid-99/with-timestamps?", captured["url"])
            self.assertEqual(res["alignment_words_count"], 1)

    def test_phrase_grouping_creates_2_to_3_word_hindi_cards_without_dropping_words(self):
        text = "भूखा कबीर रोज़ होटल के बाहर खड़ा रहता था। लालटेन में किताब पढ़ते देखा।"
        tokens = align.tokenize_transcript(text)
        words = [{"word": tok, "start": round(i * 0.35, 3), "end": round((i + 1) * 0.35, 3), "confidence": 0.95}
                 for i, tok in enumerate(tokens)]
        phrases = align.group_words_into_phrases(words)
        self.assertTrue(len(phrases) >= 5)
        for p in phrases:
            self.assertLessEqual(p["word_count"], 3)
            self.assertGreater(p["end"], p["start"])
        reconstructed = " ".join(p["text"] for p in phrases)
        self.assertEqual(reconstructed, text)

    def test_kabir_sample_plan_maps_to_variable_narration_driven_scene_durations(self):
        plan_path = ROOT / "examples" / "kabir_night_school" / "story_plan.json"
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        self.assertEqual(len(plan["scenes"]), 8)
        tokens = align.tokenize_transcript(plan["narration"])
        words = [{"word": tok, "start": round(i * 0.42, 3), "end": round((i + 1) * 0.42, 3), "confidence": 0.94}
                 for i, tok in enumerate(tokens)]
        voice_dur = words[-1]["end"] + 0.3
        mapping, updated = align.map_scenes_to_alignment(plan, words, voice_dur)
        self.assertEqual(len(mapping), 8)
        self.assertEqual(updated[0]["start"], 0.0)
        self.assertAlmostEqual(updated[-1]["end"], voice_dur, places=2)
        durations = [round(s["end"] - s["start"], 2) for s in updated]
        # Verify durations are variable (not all identical 4-5s blocks)
        self.assertGreater(len(set(durations)), 3)
        for i in range(1, len(updated)):
            self.assertAlmostEqual(updated[i]["start"], updated[i - 1]["end"], places=3)


class V10SubtitleCardTests(unittest.TestCase):
    def test_hindi_subtitle_card_renders_visible_cream_card_with_raqm_shaping(self):
        font_path = subs.resolve_font_file("जिसका नाम संतोष था")
        img, metrics = subs.render_subtitle_card_image(
            "जिसका नाम संतोष था", font_path=font_path, font_size=54, highlight_word="संतोष"
        )
        self.assertGreater(metrics["card_width"], 200)
        self.assertGreater(metrics["card_height"], 70)
        with tempfile.TemporaryDirectory() as td:
            card_png = Path(td) / "card_test.png"
            img.save(card_png)
            self.assertTrue(qa.check_subtitle_card_visibility(card_png))

    def test_split_long_sentence_into_short_2_to_3_word_cards(self):
        cues = [{"index": 1, "text": "एक घड़ीसाज़ था, उसका नाम संतोष था।", "start": 0.0, "end": 4.0}]
        short_cues = subs.split_cues_to_short_cards(cues, max_words=3)
        self.assertGreaterEqual(len(short_cues), 2)
        for c in short_cues:
            self.assertLessEqual(len(c["text"].split()), 3)


class V10MusicDistinctnessTests(unittest.TestCase):
    def test_bundled_library_has_three_genuinely_distinct_scores(self):
        root = ROOT / "assets" / "audio-library"
        records = []
        for style_key, fname in audio.CANONICAL_TO_FILENAME.items():
            p = root / "music" / fname
            self.assertTrue(p.is_file(), f"Missing bundled score: {p}")
            records.append({
                "style": style_key,
                "file": str(p),
                "sha256": audio.sha256_file(p),
                "spectral_fingerprint": audio.compute_audio_fingerprint(p),
            })
        check = audio.verify_distinct_tracks(records)
        self.assertTrue(check["distinct"], f"Bundled scores are too similar or duplicated: {check}")

    def test_duplicate_track_guard_catches_renamed_copy(self):
        fake = [
            {"style": "a", "sha256": "abc123", "spectral_fingerprint": [0.5, 0.5]},
            {"style": "b", "sha256": "abc123", "spectral_fingerprint": [0.5, 0.5]},
        ]
        check = audio.verify_distinct_tracks(fake)
        self.assertFalse(check["distinct"])
        self.assertEqual(len(check["duplicate_hashes"]), 1)

    def test_music_auditions_offline_creates_three_distinct_fallback_files(self):
        plan = {"title": "Kabir Test", "duration_seconds": 36.0, "scenes": [{"id": "scene_01", "start": 0, "end": 4}]}
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            res = audio.generate_music_auditions(plan, out, ROOT / "assets" / "audio-library", "library", "", 15.0)
            self.assertEqual(len(res["auditions"]), 3)
            self.assertTrue(res["distinctness_check"]["distinct"])
            for opt in res["auditions"]:
                self.assertEqual(opt["source"], "library_fallback")
                self.assertTrue(Path(opt["file"]).is_file())


class V10MotionAndLayerQualityTests(unittest.TestCase):
    def test_layer_quality_gate_rejects_oversized_smeared_inpainting(self):
        import numpy as np
        h, w = 400, 225
        rng = np.random.default_rng(7)
        # Detailed textured room background
        orig = rng.integers(40, 200, (h, w, 3), dtype=np.uint8)
        # Giant central subject mask (like a close-up portrait covering >35% with large radius)
        alpha = np.zeros((h, w), dtype=np.uint8)
        alpha[40:360, 20:205] = 255
        # Smeared flat inpainted interior
        bg = orig.copy()
        bg[40:360, 20:205] = 110
        res = parallax.evaluate_layer_quality(orig, bg, alpha)
        self.assertFalse(res["ok"])
        self.assertTrue(res["reason"])

    def test_layer_quality_gate_accepts_clean_small_subject_cutout(self):
        import numpy as np
        h, w = 400, 225
        rng = np.random.default_rng(11)
        orig = rng.integers(80, 150, (h, w, 3), dtype=np.uint8)
        alpha = np.zeros((h, w), dtype=np.uint8)
        alpha[160:220, 85:135] = 255  # compact subject (~3.3% area, small hole radius)
        bg = orig.copy()
        res = parallax.evaluate_layer_quality(orig, bg, alpha)
        self.assertTrue(res["ok"], f"Expected clean layer to pass: {res}")
        self.assertGreaterEqual(res["quality_score"], 0.5)

    def test_scene_effect_inference_matches_scene_objects(self):
        tea_scene = {"action": "Old tea seller reads under a kerosene lantern with steam rising from brass tea kettle"}
        fx = anim.infer_scene_effects(tea_scene, has_detected_light=True)
        self.assertTrue(fx["lamp_glow"])
        self.assertTrue(fx["steam"])
        self.assertTrue(fx["dust_particles"])
        self.assertFalse(fx["clock_motion"])

        clock_scene = {"action": "Close-up of brass watch gears ticking on table"}
        fx2 = anim.infer_scene_effects(clock_scene, has_detected_light=False)
        self.assertTrue(fx2["clock_motion"])
        self.assertFalse(fx2["steam"])




class V10FinalPolishTests(unittest.TestCase):
    def test_word_by_word_fade_in_timings_and_partial_card_render(self):
        cue = {"index": 1, "text": "हर सुबह बाबा", "words": ["हर", "सुबह", "बाबा"], "start": 0.0, "end": 1.5}
        wt = subs.ensure_word_timings(cue)
        self.assertEqual(len(wt), 3)
        self.assertLess(wt[0]["start"], wt[1]["start"])
        self.assertLess(wt[1]["start"], wt[2]["start"])
        font_path = subs.resolve_font_file(cue["text"])
        # Render partial state (only word 1 visible, words 2-3 still alpha 0)
        img_partial, _ = subs.render_subtitle_card_image(
            cue["text"], font_path=font_path, font_size=48, word_alphas=[1.0, 0.0, 0.0], card_alpha=1.0
        )
        img_full, _ = subs.render_subtitle_card_image(
            cue["text"], font_path=font_path, font_size=48, word_alphas=[1.0, 1.0, 1.0], card_alpha=1.0
        )
        # Same fixed card width so words fade in cleanly without jumping horizontally!
        self.assertEqual(img_partial.size, img_full.size)

    def test_watermark_png_renders_translucent_below_subtitles(self):
        import render_video as rv
        import numpy as np
        from PIL import Image
        with tempfile.TemporaryDirectory() as td:
            wm = rv.render_watermark_png("Inspired Tales AI", Path(td) / "wm.png", 540, 960, opacity=0.35)
            self.assertTrue(wm.is_file())
            arr = np.asarray(Image.open(wm).convert("RGBA"))
            # Top 80% should be completely transparent; bottom band has subtle translucent pixels
            self.assertEqual(int(arr[:760, :, 3].max()), 0)
            self.assertGreater(int(arr[820:, :, 3].max()), 30)
            self.assertLessEqual(int(arr[820:, :, 3].max()), 180)

    def test_zero_dependency_depth_mesh_map_shape_and_range(self):
        import numpy as np
        img = np.zeros((320, 180, 3), dtype=np.uint8)
        img[80:240, 45:135] = 200
        dmap = anim.estimate_smooth_depth_map(img, (0.5, 0.5))
        self.assertEqual(dmap.shape, (320, 180))
        self.assertGreaterEqual(float(dmap.min()), 0.0)
        self.assertLessEqual(float(dmap.max()), 1.0)

    def test_new_morning_birds_and_paper_note_sfx_classification_and_library(self):
        self.assertIn("morning_birds", audio.classify_sfx("morning sunrise birds chirping", "dawn", "wide"))
        self.assertIn("paper_note", audio.classify_sfx("handwritten paper note", "holds letter", "close-up"))
        sfx_dir = ROOT / "assets" / "audio-library" / "sfx"
        for required in ("morning_birds_ambience.mp3", "warm_kitchen_tiffin_ambience.mp3", "paper_note_rustle.mp3", "gentle_clock_ticking.mp3"):
            self.assertTrue((sfx_dir / required).is_file(), f"Missing bundled SFX: {required}")

    def test_premium_image_prompt_enhancer_and_provider_routing(self):
        import generate_images as gi
        enhanced = gi.enhance_cinematic_prompt("A young Indian boy smiling in a warm village")
        self.assertIn("85mm f/1.4", enhanced)
        self.assertIn("no text", enhanced.lower())
        with patch.dict(gi.os.environ, {"LEONARDO_API_KEY": "leo-test"}, clear=False):
            with patch.dict(gi.os.environ, {"SEEDREAM_API_KEY": "", "FAL_KEY": "", "CINESTORY_IMAGE_PROVIDER": ""}, clear=False):
                self.assertEqual(gi.resolve_provider("auto"), "leonardo")




class VFinalChoreographyAndFoleyTests(unittest.TestCase):
    def test_silence_pause_snapping_and_word_events_extraction(self):
        pauses = [(1.10, 1.40), (3.80, 4.20)]
        self.assertEqual(align.snap_cut_to_pause(1.32, pauses), 1.25)
        self.assertEqual(align.snap_cut_to_pause(2.50, pauses), 2.50)
        words = [
            {"word": "भूखा", "start": 0.1, "end": 0.5},
            {"word": "कबीर", "start": 0.6, "end": 1.0},
            {"word": "रोशनी", "start": 2.3, "end": 2.8},
        ]
        smap = [{"scene_id": "scene_01", "aligned_start": 0.0, "aligned_end": 3.0}]
        events = align.extract_word_events(words, smap)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["sfx_kind"], "heartbeat")
        self.assertEqual(events[1]["sfx_kind"], "sparkle")

    def test_word_punch_and_3d_perspective_transform(self):
        import numpy as np
        ev = [{"time": 1.0, "camera_punch": 0.05}]
        z0, g0 = anim.compute_word_punch(0.5, ev)
        z1, g1 = anim.compute_word_punch(1.15, ev)
        self.assertEqual(z0, 0.0)
        self.assertGreater(z1, 0.005)
        self.assertGreater(g1, 0.2)
        img = np.zeros((240, 135, 3), dtype=np.uint8)
        out = anim.apply_subtle_3d_perspective(img, 1.5, 0.8)
        self.assertEqual(out.shape, img.shape)

    def test_butterworth_cinema_foley_files_exist_and_cut_whoosh_scheduled(self):
        sfx_dir = ROOT / "assets" / "audio-library" / "sfx"
        for fname in ("cinema_cut_whoosh.mp3", "warm_reveal_sparkle.mp3", "emotional_soft_heartbeat.mp3", "cinematic_soft_thud.mp3", "soft_reveal_pop.mp3"):
            self.assertTrue((sfx_dir / fname).is_file(), f"Missing Butterworth foley: {fname}")
        plan = {"scenes": [
            {"id": "scene_01", "start": 0.0, "end": 2.5, "action": "morning window", "word_events": [{"time": 1.2, "sfx_kind": "sparkle"}]},
            {"id": "scene_02", "start": 2.5, "end": 5.0, "action": "paper note"},
        ]}
        cues = audio.build_cues(plan, 10)
        kinds = [c["kind"] for c in cues]
        self.assertIn("cut_whoosh", kinds)
        self.assertIn("sparkle", kinds)


if __name__ == "__main__":
    unittest.main()
