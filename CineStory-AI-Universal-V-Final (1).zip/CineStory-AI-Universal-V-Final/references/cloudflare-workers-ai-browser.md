# Cloudflare Workers AI integration

CineStory uses the user's deployed Cloudflare Worker as its default still-image backend. The configured model is `@cf/black-forest-labs/flux-2-klein-4b`; it is not Seedream, OpenAI Images or Gemini Images. The Python adapter targets the current Worker v2 REST contract.

## Current Worker v2 contract

- Base URL: `https://imagegen.mramazifier.workers.dev/` (or `POST /generate`).
- Header: `Authorization: Bearer <rotated Worker API_KEY>`.
- JSON body: `{ "prompt": "...", "width": 720, "height": 1280, "referenceMode": "character", "references": [{ "mimeType": "image/jpeg", "data": "<base64>" }] }`.
- Response: raw JPEG/PNG/WebP bytes.
- Response headers: `X-CineStory-Reference-Count`, `X-CineStory-Width`, `X-CineStory-Height`, `X-CineStory-Model`.

The adapter sends up to four references as `references` objects with `mimeType` and base64 `data`. It resizes every reference to at most 511 x 511 pixels, validates the returned image bytes with Pillow, requires the configured 720 x 1280 output and refuses to continue if the Worker does not confirm the reference count. This prevents silent unconditioned character generations.

A generation request is a billable POST and is never automatically retried. If a timeout occurs after the provider has generated an image, the outcome is uncertain; the user can explicitly rerun only the failed scene to avoid accidental duplicate quota charges.

## Secret security

If a real Worker Bearer token was pasted into a chat, screenshot or repository, rotate the Worker secret `API_KEY` before further use. Set the replacement value privately as `CINESTORY_CLOUDFLARE_API_KEY` in the local `.env` or the host's secret store. Never place it in prompts, plans, scripts, skill files, screenshots or ZIPs.

## Local/script mode

If the host can execute Python and make HTTPS requests, no MCP server is needed. It runs `scripts/generate_cloudflare_images.py` directly. The secret is loaded from the process environment or private `.env` file. Existing images are reused. A `--dry-run` preflight lists the number of image requests without consuming Workers AI quota.

```bash
python scripts/generate_cloudflare_images.py PROJECT/story_plan.json --out PROJECT/assets/images --max-images 14 --dry-run
python scripts/generate_cloudflare_images.py PROJECT/story_plan.json --out PROJECT/assets/images --max-images 14
```

The 14-image default permits up to four character references plus ten scene images. The actual plan is still subject to the account's Workers AI allowance. Never run a live package test against the user's Worker because each call consumes account usage.

## MCP mode

The user's Worker v2 REST endpoint already supports reference images. It is not automatically an MCP endpoint. For remote MCP clients, use the optional `/mcp` add-on in `cloudflare/CINESTORY-WORKER-PATCH.js`; this add-on is separate from REST reference conditioning. Do not apply the old REST patch instructions from earlier package versions. See `references/mcp-setup.md`.

## Quota and quality

Workers AI has a limited free daily Neuron allowance and may bill usage above the included amount. Check the current Cloudflare account dashboard before large batches. FLUX.2 Klein 4B is the user's selected low-cost model and should not be claimed to match Seedream 5.5 in every scene. Preserve the user's warm cinematic style, generate references first, and inspect the full storyboard for identity and composition quality.

## Safety and truthful reporting

- Never use a token that may have been exposed; request a rotated secret in the environment, not in chat.
- Never silently fall back to another image model.
- Report planned, generated, reused and failed image counts.
- If reference conditioning was not confirmed, fail the scene rather than claim it was applied.
- Do not claim image quality is identical to Seedream 5.5; assess actual generated results.
