/*
 * Optional remote MCP add-on for the user's deployed CineStory Cloudflare Worker v2.
 *
 * The existing Worker REST routes already support reference-conditioned images.
 * This add-on exposes the same generation function through a stateless MCP
 * Streamable HTTP endpoint at /mcp. The package's Python REST adapter does not
 * require MCP; use this only for hosts that support authenticated remote MCP.
 *
 * ONE-TIME EDITS:
 * 1) In fetch(request, env), immediately after `const url = new URL(request.url);`, add:
 *      if (url.pathname === "/mcp") return handleCineStoryMcp(request, env);
 * 2) Append this file's complete contents to the bottom of the Worker source.
 * 3) Add a Worker variable (not a secret): CINESTORY_MCP_ALLOWED_ORIGINS
 *    containing comma-separated exact browser origins that are allowed to use
 *    the endpoint. Server-to-server MCP clients normally send no Origin header.
 * 4) Keep the existing Workers AI binding `AI` and secret `API_KEY` unchanged.
 *
 * Security: Bearer auth is always required. If Origin is present, it must match
 * the exact allow-list. Wildcard CORS is intentionally not used.
 */

const CINESTORY_MCP_MODEL = "@cf/black-forest-labs/flux-2-klein-4b";
const CINESTORY_MCP_WIDTH = 720;
const CINESTORY_MCP_HEIGHT = 1280;
const CINESTORY_MCP_REF_LIMIT = 4;
const CINESTORY_MCP_REF_BYTES = 512 * 1024;
const CINESTORY_MCP_PROTOCOLS = new Set([
  "2026-07-28",
  "2025-11-25",
  "2025-06-18",
  "2025-03-26"
]);

function cineStoryMcpCorsHeaders(origin) {
  const headers = {
    "Cache-Control": "no-store",
    "Access-Control-Allow-Headers": "Authorization, Content-Type, Accept, MCP-Protocol-Version, Mcp-Method, Mcp-Name, Mcp-Session-Id",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
  if (origin) headers["Access-Control-Allow-Origin"] = origin;
  return headers;
}

function cineStoryMcpJson(data, status = 200, origin = "") {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...cineStoryMcpCorsHeaders(origin),
      "Content-Type": "application/json; charset=UTF-8"
    }
  });
}

function cineStoryMcpResult(id, result, origin = "") {
  // resultType is required by MCP protocol 2026-07-28 and is tolerated by
  // earlier protocol revisions as an additive result field.
  const complete = {
    resultType: "complete",
    _meta: { "io.modelcontextprotocol/serverInfo": { name: "cinestory-cloudflare-imagegen", version: "2.1.0" } },
    ...result
  };
  return cineStoryMcpJson({ jsonrpc: "2.0", id, result: complete }, 200, origin);
}

function cineStoryMcpError(id, code, message, status = 400, data, origin = "") {
  return cineStoryMcpJson({
    jsonrpc: "2.0",
    id: id ?? null,
    error: { code, message, ...(data ? { data } : {}) }
  }, status, origin);
}

function cineStoryMcpAllowedOrigin(request, env) {
  const origin = request.headers.get("Origin");
  if (!origin) return "";
  const configured = String(env.CINESTORY_MCP_ALLOWED_ORIGINS || "")
    .split(",").map((value) => value.trim()).filter(Boolean);
  return configured.includes(origin) ? origin : null;
}

function cineStoryMcpProtocol(request, message) {
  const headerVersion = request.headers.get("MCP-Protocol-Version");
  const metaVersion = message?.params?._meta?.["io.modelcontextprotocol/protocolVersion"];
  const method = String(message?.method || "");
  const supported = ["2026-07-28", "2025-11-25", "2025-06-18", "2025-03-26"];

  if (headerVersion && metaVersion && headerVersion !== metaVersion) {
    return {
      code: -32020,
      error: "MCP-Protocol-Version header does not match params._meta protocolVersion."
    };
  }

  // The 2026 stateless protocol carries the selected version in both the
  // request header and _meta, and mirrors the JSON-RPC method/name in headers.
  if (headerVersion === "2026-07-28" || metaVersion === "2026-07-28") {
    if (headerVersion !== "2026-07-28" || metaVersion !== "2026-07-28") {
      return {
        code: -32020,
        error: "For protocol 2026-07-28, MCP-Protocol-Version and params._meta protocolVersion must both be 2026-07-28."
      };
    }
    if (request.headers.get("Mcp-Method") !== method) {
      return { code: -32020, error: "Mcp-Method header must match the JSON-RPC method." };
    }
    if (method === "tools/call" && request.headers.get("Mcp-Name") !== String(message?.params?.name || "")) {
      return { code: -32020, error: "Mcp-Name header must match params.name for tools/call." };
    }
    return { version: "2026-07-28", modern: true };
  }

  // A matching but unsupported version is a protocol negotiation error, not
  // a header mismatch. Advertise versions the server actually implements.
  const requested = headerVersion || metaVersion || (method === "initialize"
    ? String(message?.params?.protocolVersion || "2025-03-26")
    : "2025-03-26");
  if (!supported.includes(requested)) {
    return {
      code: -32022,
      error: "Unsupported protocol version.",
      data: { supported, requested }
    };
  }
  return { version: requested, modern: false };
}

function appendCineStoryReferenceImages(form, referenceImages = []) {
  if (!Array.isArray(referenceImages) || referenceImages.length > CINESTORY_MCP_REF_LIMIT) {
    throw new Error(`reference_images must be an array of at most ${CINESTORY_MCP_REF_LIMIT} images.`);
  }
  referenceImages.forEach((ref, index) => {
    const mime = String(ref?.mime_type || ref?.mimeType || ref?.type || "image/jpeg").toLowerCase();
    if (!["image/jpeg", "image/png", "image/webp"].includes(mime)) {
      throw new Error(`Unsupported reference image type: ${mime}`);
    }
    let encoded = String(ref?.data || ref?.base64 || ref?.dataUrl || "");
    encoded = encoded.replace(/^data:image\/(?:jpeg|jpg|png|webp);base64,/i, "");
    if (!encoded || encoded.length > Math.ceil(CINESTORY_MCP_REF_BYTES * 4 / 3) + 8 || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) {
      throw new Error(`Reference image ${index + 1} is empty, malformed, or larger than 512 KB.`);
    }
    const binary = atob(encoded);
    if (binary.length > CINESTORY_MCP_REF_BYTES) {
      throw new Error(`Reference image ${index + 1} exceeds 512 KB.`);
    }
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    form.append(`input_image_${index}`, new Blob([bytes], { type: mime }), `reference_${index}.${mime.split("/")[1]}`);
  });
}

async function generateCineStoryImage(env, prompt, referenceImages = []) {
  if (typeof prompt !== "string" || !prompt.trim() || prompt.length > 4096) {
    throw new Error("prompt is required and must contain 1–4096 characters.");
  }
  const form = new FormData();
  form.append("prompt", prompt.trim());
  form.append("width", String(CINESTORY_MCP_WIDTH));
  form.append("height", String(CINESTORY_MCP_HEIGHT));
  appendCineStoryReferenceImages(form, referenceImages);
  const serialized = new Response(form);
  const result = await env.AI.run(CINESTORY_MCP_MODEL, {
    multipart: {
      body: serialized.body,
      contentType: serialized.headers.get("content-type")
    }
  });
  if (!result || typeof result.image !== "string" || !result.image) {
    throw new Error("Workers AI returned no image payload.");
  }
  const binary = atob(result.image);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  if (!bytes.length) throw new Error("Workers AI returned an empty image.");
  const mimeType = bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47
    ? "image/png"
    : "image/jpeg";
  return { data: result.image, mimeType, byteLength: bytes.length };
}

async function handleCineStoryMcp(request, env) {
  const origin = cineStoryMcpAllowedOrigin(request, env);
  if (origin === null) return new Response("Origin is not allowed.", { status: 403, headers: { "Cache-Control": "no-store" } });

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cineStoryMcpCorsHeaders(origin) });
  }
  if (request.method !== "POST") {
    return new Response("Use POST /mcp with an MCP JSON-RPC message.", {
      status: 405,
      headers: { ...cineStoryMcpCorsHeaders(origin), "Allow": "POST, OPTIONS" }
    });
  }
  const contentType = request.headers.get("Content-Type") || "";
  if (!contentType.toLowerCase().includes("application/json")) {
    return cineStoryMcpJson({ error: "Content-Type must be application/json." }, 415, origin);
  }
  const accept = request.headers.get("Accept") || "";
  if (!accept.includes("application/json") || !accept.includes("text/event-stream")) {
    return cineStoryMcpJson({ error: "Accept must include application/json and text/event-stream." }, 406, origin);
  }
  if (!env.API_KEY) return cineStoryMcpJson({ error: "Worker secret API_KEY is not configured." }, 500, origin);
  if (request.headers.get("Authorization") !== `Bearer ${env.API_KEY}`) {
    return cineStoryMcpJson({ error: "Unauthorized. Configure the rotated Worker API key in the MCP client." }, 401, origin);
  }

  let message;
  try { message = await request.json(); }
  catch { return cineStoryMcpJson({ error: "Request body must be valid JSON." }, 400, origin); }
  if (!message || message.jsonrpc !== "2.0" || typeof message.method !== "string") {
    return cineStoryMcpError(message?.id ?? null, -32600, "Invalid JSON-RPC 2.0 request.", 400, undefined, origin);
  }

  const id = Object.prototype.hasOwnProperty.call(message, "id") ? message.id : null;
  const params = message.params || {};
  const protocol = cineStoryMcpProtocol(request, message);
  if (protocol.error) return cineStoryMcpError(id, protocol.code || -32020, protocol.error, 400, protocol.data, origin);

  // The 2026 core protocol defines no client-to-server notifications over
  // Streamable HTTP. Older 2025 clients still send notifications/initialized.
  if (!Object.prototype.hasOwnProperty.call(message, "id")) {
    if (protocol.modern) {
      return cineStoryMcpJson({
        jsonrpc: "2.0",
        error: { code: -32600, message: "Client notifications are not supported by MCP 2026-07-28 Streamable HTTP." }
      }, 400, origin);
    }
    return new Response(null, { status: 202, headers: cineStoryMcpCorsHeaders(origin) });
  }

  if (message.method === "server/discover") {
    if (!protocol.modern) {
      return cineStoryMcpError(id, -32601, "server/discover is only available in protocol 2026-07-28.", 404, undefined, origin);
    }
    return cineStoryMcpResult(id, {
      supportedVersions: ["2026-07-28"],
      capabilities: { tools: {} },
      _meta: { "io.modelcontextprotocol/serverInfo": { name: "cinestory-cloudflare-imagegen", version: "2.1.0" } },
      instructions: "Generate approved CineStory scene images at 720x1280 using Cloudflare Workers AI. Each image consumes the owner's Workers AI quota. Pass up to four resized character/style reference images per scene. Preserve the supplied character descriptions and warm cinematic style. Never render subtitles, text or logos into the image.",
      ttlMs: 3600000,
      cacheScope: "private"
    }, origin);
  }

  if (message.method === "initialize") {
    if (protocol.modern) {
      return cineStoryMcpError(id, -32601, "initialize was removed from MCP protocol 2026-07-28; use server/discover.", 404, undefined, origin);
    }
    return cineStoryMcpResult(id, {
      protocolVersion: protocol.version,
      capabilities: { tools: { listChanged: false } },
      serverInfo: { name: "cinestory-cloudflare-imagegen", version: "2.1.0" },
      instructions: "Generate approved CineStory story stills at 720x1280 through the configured Cloudflare Workers AI binding. Each generated image consumes the owner's Workers AI quota. Preserve approved character descriptions and warm cinematic style. Do not render text or subtitles into images."
    }, origin);
  }

  if (message.method === "ping") {
    if (protocol.modern) return cineStoryMcpError(id, -32601, "ping was removed from MCP protocol 2026-07-28.", 404, undefined, origin);
    return cineStoryMcpResult(id, {}, origin);
  }

  if (message.method === "tools/list") {
    return cineStoryMcpResult(id, {
      tools: [
        {
          name: "generate_cinestory_scene_image",
          description: "Generate one approved CineStory scene image at 720x1280. Optionally pass up to four resized character/style references as base64 JPEG/PNG/WebP images. This consumes Workers AI quota.",
          inputSchema: {
            type: "object",
            properties: {
              scene_id: { type: "string" },
              prompt: { type: "string", minLength: 1, maxLength: 4096 },
              reference_images: {
                type: "array", maxItems: 4,
                items: {
                  type: "object",
                  properties: {
                    mime_type: { type: "string", enum: ["image/jpeg", "image/png", "image/webp"] },
                    data: { type: "string", description: "Base64 image bytes, resized to under 512x512 and no larger than 512 KB." }
                  },
                  required: ["mime_type", "data"]
                }
              }
            },
            required: ["prompt"]
          },
          annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
        },
        {
          name: "generate_cinestory_storyboard_images",
          description: "Generate up to four approved storyboard images in one request. For larger storyboards, call in batches. Each image consumes Workers AI quota.",
          inputSchema: {
            type: "object",
            properties: {
              scenes: {
                type: "array", minItems: 1, maxItems: 4,
                items: {
                  type: "object",
                  properties: {
                    scene_id: { type: "string" },
                    prompt: { type: "string", minLength: 1, maxLength: 4096 },
                    reference_images: {
                      type: "array", maxItems: 4,
                      items: {
                        type: "object",
                        properties: {
                          mime_type: { type: "string", enum: ["image/jpeg", "image/png", "image/webp"] },
                          data: { type: "string" }
                        },
                        required: ["mime_type", "data"]
                      }
                    }
                  },
                  required: ["scene_id", "prompt"]
                }
              }
            },
            required: ["scenes"]
          },
          annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true }
        }
      ],
      ttlMs: 60000,
      cacheScope: "private"
    }, origin);
  }

  if (message.method === "tools/call") {
    const name = params.name;
    const args = params.arguments || {};
    try {
      if (name === "generate_cinestory_scene_image") {
        const prompt = typeof args.prompt === "string" ? args.prompt.trim() : "";
        const image = await generateCineStoryImage(env, prompt, args.reference_images || []);
        const sceneId = String(args.scene_id || "scene");
        return cineStoryMcpResult(id, {
          content: [
            { type: "text", text: `Generated ${sceneId}: ${CINESTORY_MCP_WIDTH}x${CINESTORY_MCP_HEIGHT}, ${image.mimeType}, ${image.byteLength} bytes.` },
            { type: "image", data: image.data, mimeType: image.mimeType }
          ],
          isError: false
        }, origin);
      }

      if (name === "generate_cinestory_storyboard_images") {
        const scenes = args.scenes;
        if (!Array.isArray(scenes) || scenes.length < 1 || scenes.length > 4) {
          return cineStoryMcpError(id, -32602, "scenes must contain between 1 and 4 scene objects.", 400, undefined, origin);
        }
        const content = [];
        const failures = [];
        for (const scene of scenes) {
          const sceneId = String(scene?.scene_id || "scene");
          try {
            const image = await generateCineStoryImage(env, scene?.prompt, scene?.reference_images || []);
            content.push({ type: "text", text: `SCENE ${sceneId} | ${CINESTORY_MCP_WIDTH}x${CINESTORY_MCP_HEIGHT} | ${image.mimeType}` });
            content.push({ type: "image", data: image.data, mimeType: image.mimeType });
          } catch (error) {
            failures.push(sceneId);
            content.push({ type: "text", text: `FAILED ${sceneId}: ${error?.message || String(error)}` });
          }
        }
        return cineStoryMcpResult(id, {
          content,
          isError: failures.length > 0,
          ...(failures.length ? { _meta: { failed_scenes: failures } } : {})
        }, origin);
      }
      return cineStoryMcpError(id, -32602, `Unknown tool: ${String(name)}`, 400, undefined, origin);
    } catch (error) {
      return cineStoryMcpResult(id, {
        content: [{ type: "text", text: `Image generation failed: ${error?.message || String(error)}` }],
        isError: true
      }, origin);
    }
  }

  return cineStoryMcpError(id, -32601, `Method not found: ${message.method}`, 404, undefined, origin);
}
