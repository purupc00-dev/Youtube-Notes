# CineStory Cloudflare Worker setup

Your deployed Cloudflare Worker v2 is the default still-image generator. It uses `@cf/black-forest-labs/flux-2-klein-4b` with a 720 x 1280 portrait output and already supports up to four character/style reference images.

## Contract used by CineStory

- URL: `https://imagegen.mramazifier.workers.dev/` (or `/generate`)
- Method: `POST`
- Header: `Authorization: Bearer <rotated API_KEY>`
- Body: `{ "prompt": "...", "width": 720, "height": 1280, "referenceMode": "character", "references": [{ "mimeType": "image/jpeg", "data": "<base64>" }] }`
- Response: raw image bytes plus `X-CineStory-Reference-Count` and size headers.

The adapter matches this contract and validates actual output image bytes/dimensions. Reference images are resized to 511 x 511 or smaller. Reference conditioning is required for recurring characters; if the Worker does not confirm it applied the references, CineStory stops rather than silently claiming consistency.

## One-time setup

1. Rotate the Worker `API_KEY` if the old value was ever disclosed in chat.
2. Keep the replacement secret in Cloudflare as `API_KEY`.
3. Store the same value privately in your agent/runtime secret store as `CINESTORY_CLOUDFLARE_API_KEY`, or in a private local `.env` based on `.env.example`.
4. The Worker URL is already configured. No image provider key needs to be entered for each story.

## MCP

The deployed Worker v2 supports REST calls but does not include a remote MCP endpoint by default. Shell-capable agents call the REST adapter directly and do not need MCP. Browser-first hosts can use the optional `/mcp` add-on in `cloudflare/CINESTORY-WORKER-PATCH.js`, if that host supports remote MCP and custom Bearer headers. The `/mcp` add-on is not required for REST reference images.

## Quota

Each successful image generation consumes Workers AI allowance. Use `--dry-run` to preflight the request count. Reuse approved scene images and regenerate only defective scenes.
